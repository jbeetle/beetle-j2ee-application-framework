package example.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageClient;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;

public class EchoClient {
	public static void main2(String[] args) throws MessageCommunicateException {
		MessageClient client = new MessageClient();
		boolean f = client.connect("127.0.0.1:8080", "Henry", "888888");
		if (f) {
			MsgReq req = new MsgReq();
			req.put("word", "Hi,I am Henry.");
			client.send(req);
			while (true) {
				MsgRes res = client.receive();
				// MsgRes res = client.invoke(req);
				System.out.println(res);
			}
			//client.disconnect();
		}
		System.exit(0);
	}

	public static void main(String[] args) throws MessageCommunicateException {
		MessageClient client = new MessageClient();
		boolean f = client.connect("10.25.17.68:9090", "Henry", "888888");
		//boolean f = client.connect("127.0.0.1:9090", "Henry", "888888");
		if (f) {
			MsgReq req = new MsgReq();
			req.put("word", "Hi,I am Henry.");
			MsgRes res = client.invoke(req);
			if (res != null) {
				String echo = res.getValueAsString("echo");
				System.out.println(echo);
			}
			//client.disconnect();
		}
		//System.exit(0);
		client.disconnect();
		System.out.println("ok");
	}

}

package example.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageClient;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;
import com.beetle.framework.util.UUIDGenerator;

public class EchoWebTestClient {
	static final MessageClient client = new MessageClient();
	static {
		try {
			client.connect("10.25.17.68:9090", "Henry", "888888");
		} catch (MessageCommunicateException e) {
			e.printStackTrace();
		}
	}

	public static String echoNewClient() {
		MsgReq req = new MsgReq();
		req.put("word",
				"Hi,I am Henry.[" + UUIDGenerator.generate() + "]");
		MsgRes res = null;
		MessageClient c2 = new MessageClient();
		try {
			c2.connect("10.25.17.68:9090", "Henry", "888888");
			long x = System.currentTimeMillis();
			res = c2.invoke(req);
			long x2 = System.currentTimeMillis();
			System.out.println(res);
			if (res != null) {
				String echo = res.getValueAsString("echo");
				return echo + "[" + (x2 - x) + "]ms";
			}
		} catch (MessageCommunicateException e) {
			e.printStackTrace();
		} finally {
			c2.disconnect();
			if (res != null) {
				res.clear();
			}
			if (req != null) {
				req.clear();
			}
		}
		return "";
	}

	public static String echoShare() {
		MsgReq req = new MsgReq();
		req.put("word",
				"Hi,I am Henry.[" + UUIDGenerator.generate() + "]");
		MsgRes res = null;
		try {
			long c = System.currentTimeMillis();
			res = client.invoke(req);
			long c2 = System.currentTimeMillis();
			System.out.println(res);
			if (res != null) {
				String echo = res.getValueAsString("echo");
				return echo + "[" + (c2 - c) + "]ms";
			}
		} catch (MessageCommunicateException e) {
			e.printStackTrace();
		} finally {
			if (res != null) {
				res.clear();
			}
			if (req != null) {
				req.clear();
			}
		}
		return "";
	}
}

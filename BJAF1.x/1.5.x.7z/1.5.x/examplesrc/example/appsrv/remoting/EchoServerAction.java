package example.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MessageServer;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;

public class EchoServerAction extends MessageServer.ServerAction {

	protected void connectionBreakEvent(String sessionId, int breakTypeFlag)
			throws MessageCommunicateException {
		System.out.println("connectionBreakEvent[" + sessionId + ","
				+ breakTypeFlag + "]");
	}

	public boolean authenticate(String username, String password) {
		if (username.equals("Henry") && password.equals("888888")) {
			return true;
		}
		return false;
	}

	public MsgRes requestHandle(MsgReq req) throws MessageCommunicateException {
		System.out.println("--------");
		System.out.println(req);
		System.out.println("--------");
		String word = req.getValueAsString("word");
		System.out.println("[" + System.currentTimeMillis() + "]:" + word);
		MsgRes res = new MsgRes();
		res.put("echo", "echo:" + word);
		return res;
	}

	protected void beforeStopServerEvent() throws MessageCommunicateException {
		System.out.println("beforeStopServerEvent");
	}

	protected void sessionCreatedEvent(String sessionId)
			throws MessageCommunicateException {
		System.out.println("sessionCreatedEvent[" + sessionId + "]");
	}

	protected void sessionBeforeLoseEvent(String sessionId)
			throws MessageCommunicateException {
		System.out.println("sessionBeforeLoseEvent[" + sessionId + "]");
	}
}

package example.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageClient;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;
import com.beetle.framework.log.SysLogger;

public class EchoClientLoop {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws MessageCommunicateException {
		final SysLogger log = SysLogger.getInstance(EchoClientLoop.class);
		final MessageClient client = new MessageClient();
		boolean f = client.connect("10.25.17.68:9090", "Henry", "888888");
		// boolean f = client.connect("127.0.0.1:9090", "Henry", "888888");
		if (f) {
			new Thread(new Runnable() {
				public void run() {
					while (true) {
						MsgReq req = new MsgReq();
						req.put("word", "Hi,I am Henry.");
						MsgRes res;
						try {
							res = client.invoke(req, 1);
							if (res != null) {
								String echo = res.getValueAsString("echo");
								log.debug(echo);
							}
							Thread.sleep(10l);
						} catch (Exception e) {
							log.error(e);
							// client.disconnect();
							// break;
						}
					}
				}
			}).start();
		}
		System.out.println("OK");
	}

}

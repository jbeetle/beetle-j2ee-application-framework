package example.appsrv;

public class TestClient {

	public static void main(String[] args) throws Throwable {
		new SimpleThread(2000).startNow();
		Thread.sleep(10000);
	}

}

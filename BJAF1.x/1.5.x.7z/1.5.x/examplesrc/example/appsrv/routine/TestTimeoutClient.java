package example.appsrv.routine;

import java.util.List;

import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.RoutineRunException;

public class TestTimeoutClient {

	public static void main(String[] args) {
		RoutineExecutor re = new RoutineExecutor();
		re.addSubRoutine(new HardWorkSR());
		try {
			List result = (List) re.runRoutineForTime(15);// 最大允许子程序执行5秒
			System.out.println(result);
		} catch (RoutineRunException e) {
			e.printStackTrace();
		}
		System.out.println("ok");
	}

}

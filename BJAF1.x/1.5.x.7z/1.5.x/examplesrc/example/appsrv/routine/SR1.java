package example.appsrv.routine;

import com.beetle.framework.appsrv.SubRoutine;

public class SR1 extends SubRoutine {

	protected void routine() throws InterruptedException {
		System.out.println("sr1-begin");
		sleep(3000);
		System.out.println("sr1-end");
	}

}

package example.appsrv.routine;

import com.beetle.framework.appsrv.RoutinePool;


public class TestClient {

	public static void main(String[] args) throws Throwable {
		// RoutineExecutor.runRoutineInCommonPool(new DemoRoutine(1));//
		// 最大阻塞时间为5秒

		// RoutineExecutor.runRoutineInCommonPool(new DemoRoutine(15));//
		// 最大阻塞时间为5秒

		DemoRoutine t = new DemoRoutine(5000);
		RoutinePool.getCommonPool().runInPool(t.killThreadWhenTimeout());
		Thread.sleep(20000);
		// RoutinesPool.runRoutineInPool(t);
	}

}

package example.appsrv.routine;

import com.beetle.framework.appsrv.Locker;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.SubRoutine;

public class TestLockClient {

	private static class SR extends SubRoutine {
		private Locker locker;

		public SR(Locker locker) {
			this.locker = locker;
		}

		protected void routine() throws InterruptedException {
			System.out.println("sr-begin");
			sleep(5000);
			System.out.println("sr-end");
			locker.unlock();// 释放锁
		}

	}

	public static void main(String[] args) {
		Locker locker = new Locker();
		try {
			RoutineExecutor.runRoutineInCommonPool(new SR(locker));
			//locker.lock();// 加锁，阻塞主线程
			locker.lockForTime(2000);// 最多锁住2000ms
			System.out.println("ok");
		} catch (InterruptedException e) {
			e.printStackTrace();
		} finally {
			locker.unlock();
		}

	}

}

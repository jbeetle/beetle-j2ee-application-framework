package example.appsrv.routine;

import com.beetle.framework.appsrv.SubRoutine;

public class SR2 extends SubRoutine {

	protected void routine() throws InterruptedException {
		System.out.println("sr2-begin");
		sleep(2000);
		System.out.println("sr2-end");
		
	}

}

package example.appsrv.task;

import com.beetle.framework.appsrv.scheduler.Task;

public class DemoTask extends Task {

	public void doTask() {
		System.out.println("do task...");
	}

}

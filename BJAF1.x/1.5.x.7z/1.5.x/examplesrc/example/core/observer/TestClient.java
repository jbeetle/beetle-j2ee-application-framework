package example.core.observer;

public class TestClient {

	
	public static void main(String[] args) {
		StockAlert alert=new StockAlert();
		Stock stock=new Stock();
		stock.addOneObserver(alert);//注册报警事件
		stock.setPrice(new Float(12.5f), new Float(6.5f));//股票价位正常
		System.out.println("---");
		stock.setPrice(new Float(4.5f), new Float(6.5f));//股票价位跌破目标价，自动触发事件
		System.out.println("---");
	}

}

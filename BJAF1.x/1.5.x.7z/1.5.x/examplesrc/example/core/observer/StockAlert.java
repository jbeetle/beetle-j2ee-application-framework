package example.core.observer;

import com.beetle.framework.util.pattern.observer.AbleImp;
import com.beetle.framework.util.pattern.observer.ObserverImp;

public class StockAlert extends ObserverImp {// 股票报警类，主要处理报警事件

	public void dealEvent(AbleImp ableImp, Object observedObj) {
		Stock stock = (Stock) ableImp;
		System.out.println("price:" + stock.getPrice());
		System.out.println("send a sms to the stock's owner!");// 发短信通知客户
	}

}

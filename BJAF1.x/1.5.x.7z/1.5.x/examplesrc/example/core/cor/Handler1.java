package example.core.cor;

import java.util.Date;

import com.beetle.framework.util.pattern.cor.HandleResult;
import com.beetle.framework.util.pattern.cor.IReq;
import com.beetle.framework.util.pattern.cor.NodeHandler;

public class Handler1 extends NodeHandler {

	public HandleResult handle(IReq req) {
		System.out.println("-->handler1");
		MyReq my = (MyReq) req;
		System.out.println("-->" + my.getName());
		System.out.println("-->" + my.getDate());
		sleep();
		my.setDate(new Date(System.currentTimeMillis()));
		System.out.println("-->end");
		return new HandleResult(false);
	}

	private void sleep() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
		}
	}

}

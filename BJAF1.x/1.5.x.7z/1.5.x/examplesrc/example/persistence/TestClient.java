package example.persistence;

import com.beetle.framework.persistence.storage.IStorageAccess;
import com.beetle.framework.persistence.storage.StorageAdmin;
import com.beetle.framework.persistence.storage.StorageObj;

public class TestClient {

	public static void main(String[] args) {
		// 构建一个user值对象并赋值
		User user = new User();
		user.setName("Henry");
		user.setAge(32);
		user.setAddress("中国深圳");
		user.setPhone("13501583576");
		user.setPwd("888888");
		// 构建一个存储对象，以便保存
		StorageObj sobj = new StorageObj();
		sobj.setId("100001");// 指定一个id，保证文件系统能够唯一标示此存储对象
		sobj.setCreatetime(new java.sql.Timestamp(System.currentTimeMillis()));// 指定创建时间
		sobj.setObj(user);// 把user值对象加入存储对象中
		sobj.setObjtype(new Integer(1));// 设置对象类型，类型值含义自己定义
		sobj.setStatus(new Integer(0));// 设置存储对象在文件系统状态，状态值含义自己定义
		sobj.setPlus("");
		// 获取一个StorageAdmin实例，并从实例获取磁盘操作实例
		IStorageAccess access = StorageAdmin.getAccess();
		access.create(sobj);// 建立一个存储对象（把存储对象保存在磁盘中）
	}
}

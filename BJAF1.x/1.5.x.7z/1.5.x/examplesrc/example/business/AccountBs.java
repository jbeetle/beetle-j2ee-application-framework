package example.business;

import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.BusinessException;
import com.beetle.framework.business.delegate.IBusiness;

public class AccountBs implements IBusiness {

	public BsResponse execute(BsRequest req) throws BusinessException {
		String user = req.getValueAsString("user");
		BsResponse res = new BsResponse();
		res.put("echo", "echo:" + user);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			throw new BusinessException(e);
		}
		return res;
	}

}

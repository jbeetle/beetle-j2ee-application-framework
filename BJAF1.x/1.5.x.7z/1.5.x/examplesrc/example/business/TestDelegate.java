package example.business;

import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.BusinessException;
import com.beetle.framework.business.delegate.DelegateExecutor;
import com.beetle.framework.business.delegate.IBusinessCallBack;

public class TestDelegate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 20; i++) {
			t1(i);
		}
		System.out.println("OK");
	}

	private static void t1(int i) {
		BsRequest req = new BsRequest();
		req.put("user", "Henry" + i);
		req.registerBusinessURL(AccountBs.class.getName());
		DelegateExecutor.asynchroExecuteBusiness(req, new IBusinessCallBack() {

			public void handle(BsResponse res) throws BusinessException {
				String echo = res.getValueAsString("echo");
				System.out.println(echo);
			}
		});
	}
}

package test;

public interface IA {
	void go();
}

package test;

public class Aimp implements IA{

	@Override
	public void go() {
		System.out.println("xxxxxxxxxxxxx");
		
	}

}

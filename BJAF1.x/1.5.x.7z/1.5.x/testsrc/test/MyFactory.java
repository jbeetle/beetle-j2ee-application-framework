package test;

public class MyFactory {
	public static <T> T getDaoObject(Class<T> daoImpClass) throws Throwable {
		T t = daoImpClass.newInstance();
		return t;
	}
}

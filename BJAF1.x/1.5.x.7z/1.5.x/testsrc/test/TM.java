package test;

public class TM {

	/**
	 * @param args
	 * @throws Throwable 
	 */
	public static void main(String[] args) throws Throwable {
		IA a = MyFactory.getDaoObject(Aimp.class);
		a.go();

	}

}

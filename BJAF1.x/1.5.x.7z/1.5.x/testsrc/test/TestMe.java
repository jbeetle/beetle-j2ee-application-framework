package test;

import java.io.UnsupportedEncodingException;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.util.AesEncrypt;
import com.beetle.framework.util.OtherUtil;

public class TestMe {
	private static class SelectorVO {

		public int getI() {
			return i;
		}

		public SelectorVO() {
			x = OtherUtil.randomLong(100, 2000);
			i = 0;
		}

		private final Object lock = new Object();
		private long x;
		private int i;

		public long getX() {
			return x;
		}

		public void add() {
			i = i + 1;
		}

		public Object getLock() {
			return lock;
		}

		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((lock == null) ? 0 : lock.hashCode());
			return result;
		}

	}

	static SelectorVO ss[];
	private static int post = 0;

	private static SelectorVO roundRobin() {
		synchronized (ss) {
			SelectorVO svo = ss[post];
			post++;
			if (post >= ss.length) {
				post = 0;
			}
			return svo;
		}
	}

	private static class T extends AppThreadImp {

		public T(String threadName, int interval) {
			super(threadName, interval);
		}

		protected void workProc() {
			final SelectorVO vo = roundRobin();
			synchronized (vo.getLock()) {
				System.out.println("--begin[" + this.getName() + "]");
				System.out.println("id-" + vo.getX());
				vo.add();
				// System.out.println(vo.hashCode());
				System.out.println(AesEncrypt.encrypt("999999999999999999"
						+ vo.getI()));
				System.out.println(vo.getI());
				System.out.println("--end[" + this.getName() + "]");
			}
		}

	}

	public static String toStringHex(String s) {
		byte[] baKeyword = new byte[s.length() / 2];
		for (int i = 0; i < baKeyword.length; i++) {
			try {
				baKeyword[i] = (byte) (0xff & Integer.parseInt(
						s.substring(i * 2, i * 2 + 2), 16));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		try {
			s = new String(baKeyword, "utf-8");// UTF-16le:Not
		} catch (Exception e1) {
			e1.printStackTrace();
		}
		return s;
	}

	public static void main(String arg[]) throws Throwable {
		String word = "a";
		String key = "thekey";
		byte en[] = XXTEA.encrypt(word.getBytes("UTF-8"), key.getBytes());
		//System.out.println(new String(word.getBytes("UTF-8")));
		System.out.println(en);
		System.out.println(new String(en));
		System.out.println(new String(en,"UTF-8"));
		byte dn[] = XXTEA.decrypt(en, key.getBytes());
		System.out.println(dn);
		System.out.println(new String(dn));
		// org.apache.commons.codec.binary.
	
	}

	public static void main222(String arg[]) {
		String word = "hi,i am Henry";
		String key = "thekey";
		String enStr = new String(
				XXTEA.encrypt(word.getBytes(), key.getBytes()));
		System.out.println(enStr);
		String dnStr = new String(XXTEA.decrypt(enStr.getBytes(),
				key.getBytes()));
		System.out.println(dnStr);
	}

	public static void main3(String arg[]) {

	}
}

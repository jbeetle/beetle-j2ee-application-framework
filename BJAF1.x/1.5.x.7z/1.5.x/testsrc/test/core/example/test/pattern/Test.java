package test.core.example.test.pattern;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.BinaryCodec;

import com.beetle.framework.util.ObjectUtil;
import com.beetle.framework.util.OtherUtil;

public class Test {
	public static byte[] compressBytes(byte[] bytes) throws IOException {
		ByteArrayOutputStream baos = null;
		baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(new GZIPOutputStream(baos));
		dos.write(bytes);
		dos.close();
		return baos.toByteArray();
	}

	public static byte[] decompressBytes(byte[] bytes) throws IOException {
		GZIPInputStream gis = new GZIPInputStream(new ByteArrayInputStream(
				bytes));
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		byte[] buf = new byte[1024];
		int len;
		while ((len = gis.read(buf)) >= 0) {
			baos.write(buf, 0, len);
		}
		gis.close();
		baos.close();
		return baos.toByteArray();
	}

	// ѹ��
	public static String compress(String str) throws IOException {
		if (str == null || str.length() == 0) {
			return str;
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		GZIPOutputStream gzip = new GZIPOutputStream(out);
		gzip.write(str.getBytes());
		gzip.close();
		return out.toString("ISO-8859-1");
	}

	// ��ѹ��
	public static String uncompress(String str) throws IOException {
		if (str == null || str.length() == 0) {
			return str;
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		ByteArrayInputStream in = new ByteArrayInputStream(str.getBytes("ISO-8859-1"));
		//ByteArrayInputStream in = new ByteArrayInputStream(str.getBytes());
		GZIPInputStream gunzip = new GZIPInputStream(in);
		byte[] buffer = new byte[256];
		int n;
		while ((n = gunzip.read(buffer)) >= 0) {
			out.write(buffer, 0, n);
		}
		// toString()ʹ��ƽ̨Ĭ�ϱ��룬Ҳ������ʽ��ָ����toString("GBK")
		return out.toString();
		//return out.toString("ISO-8859-1");
	}

	public static void main(String[] args) throws Throwable {
		Map m = new HashMap();
		for (int i = 0; i < 100; i++) {
			Info info = new Info();
			info.setLoginTime(new java.util.Date(System.currentTimeMillis()));
			info.setTime(new java.sql.Timestamp(System.currentTimeMillis()));
			info.setLoginUser("�û�Henry" + i);
			info.setPassword(999);
			m.put("info" + i, info);
		}
		//
		z(m);
	}

	private static void z(Map m) throws IOException {
		String AAA = ObjectUtil.objToBase64Str(m);
		System.out.println(AAA.length());
		// String BBB = new String(compressBytes(AAA.getBytes()));
		String BBB = compress(AAA);
		System.out.println(BBB);
		System.out.println("--");
		String CCC = uncompress(BBB);
		System.out.println(CCC.length());
		// System.out.println(CCC);
		Map m2 = (Map) ObjectUtil.base64StrToObject(CCC);
		// System.out.println(m2);
		System.out.println(((Info) m2.get("info1")).getLoginUser());
	}

	public static void mainz(String[] args) {
		Info info = new Info();
		info.setLoginTime(new java.util.Date(System.currentTimeMillis()));
		info.setTime(new java.sql.Timestamp(System.currentTimeMillis()));
		info.setLoginUser("�û�Henry Yuhhhhhhhhhhhhh");
		info.setPassword(999);
		Base64 b64 = new Base64();
		try {
			String o = BinaryCodec.toAsciiString(OtherUtil.objToBytes(info));
			System.out.println(o);
			// log.debug(o);
			BinaryCodec bc = new BinaryCodec();
			byte[] b = bc.decode(o.getBytes());
			Object o2 = OtherUtil.bytesToObj(b);
			System.out.println(o2);
			//
			byte b2[] = b64.encode(OtherUtil.objToBytes(info));
			String s1 = new String(b2);
			System.out.println(s1);
			// System.out.println(new String(OtherUtil.objToBytes(info)));
			byte b3[] = b64.decode(s1.getBytes());
			Object o22 = OtherUtil.bytesToObj(b3);
			System.out.println(o22);
			Info info2 = (Info) o22;
			System.out.println(info2.getLoginUser());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void a2(Info in2) {
		System.out.println(in2);
		System.out.println(in2.getLoginUser());
		System.out.println(in2.getLoginTime());
		System.out.println(in2.getTime());
		System.out.println(in2.getPassword());
	}

}

package test.core.example.test.pattern;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.PBEParameterSpec;

public class TM {
  
  public static final String Algorithm="PBEWithMD5AndDES"; //���� �����㷨,����AES DES,DESede,Blowfish
  public static final String Key="CCF-SYSTEM213123";
//Salt
  public static final byte[] salt = {
      (byte)0xc7, (byte)0x73, (byte)0x21, (byte)0x8c,
      (byte)0x7e, (byte)0xc8, (byte)0xee, (byte)0x99
  };

  // Iteration count
  public static final int count = 32;
  
  public static String encrypt(String source){
    return encrypt2(source);
  }
  
  public static String encrypt1(String source) {
    String result = source;
//    BASE64Encoder encoder = new BASE64Encoder();
//    result = encoder.encode(source.getBytes());
    String encryString=null;
    String charHexSet,strTemp,strRAW;
    int intStringLen;
    long intKey,intOffSet;
    
    intKey = Math.round((Math.random()* 10000) + 10000);
    intOffSet = Math.round((Math.random()* 10000) + 10000);
    charHexSet="";
    if (result!=null){
      strRAW = result;
      intStringLen = strRAW.length();
      for(int i = 0;i<intStringLen;i++){
         strTemp = strRAW.substring(0,1);
         strRAW = strRAW.substring(1);
         charHexSet = charHexSet + Long.toHexString((byte)strTemp.charAt(0) + intKey)+"!" +Long.toHexString(intKey);
      }
      encryString = charHexSet + "|" + Long.toHexString(intOffSet + intKey) + "|" + Long.toHexString(intOffSet);
    }else{
      encryString = "";
    }
   return encryString;
  }
  public static String encrypt2(String source){
    String result=source;
    try {
     Cipher c1 = Cipher.getInstance(Algorithm);
     PBEParameterSpec  ap=new PBEParameterSpec(TM.salt,TM.count);
     c1.init(Cipher.ENCRYPT_MODE,genKey(),ap);
     byte[] cipherByte=c1.doFinal(result.getBytes());
     result=asHex(cipherByte);
      
    } catch (Exception e) {
      e.printStackTrace();
     //CCFLogger.error("", DecryptUtil.class, "decrypt", e.getMessage());
    }
    return result;
  }
  /**
   * Turns array of bytes into string
   */
  public static String asHex(byte buf[]) {
    StringBuffer strbuf = new StringBuffer(buf.length * 2);

    for (int i = 0; i < buf.length; i++) {
      if ( ( (int) buf[i] & 0xff) < 0x10) {
        strbuf.append("0");
      }

      strbuf.append(Long.toString( (int) buf[i] & 0xff, 16));
    }

    return strbuf.toString();
  }

  /**
   * Turns string into array of bytes
   */
  public static byte[] asByte(String buf) {
    if (buf.length() % 2 == 1) {
      buf = "0" + buf;
    }
    int length = buf.length() / 2;
    byte[] bytebuf = new byte[length];
    for (int i = 0; i < length; i++) {
      int pos = i * 2;
      String b = buf.substring(pos, pos + 2);
      bytebuf[i] = (byte) Integer.parseInt(b, 16);
    }
    return bytebuf;
  }
  public static SecretKey genKey() throws Exception {
    KeySpec  keySpec = new PBEKeySpec(Key.toCharArray());
    SecretKeyFactory keyFac = SecretKeyFactory.getInstance(Algorithm);
    SecretKey pbeKey = keyFac.generateSecret(keySpec);
    return pbeKey;
  }
   public static String decrypt(String source) {
    return decrypt2(source);  
  }
  public static String decrypt1(String source){
    String result=source;
//    BASE64Decoder decoder = new BASE64Decoder();
//    byte[] userCertBase64;
//    try {
//      userCertBase64 = decoder.decodeBuffer(source);
//      result=new String(userCertBase64);
//    } catch (IOException e) {
//      CCFLogger.error("", DecryptUtil.class, "decrypt", e.getMessage());
//    }
    
    String strRAW,strRawKey, strHexCrypData,intOffSet;  
    long intKey;
    strRAW="";  
    strRawKey = result.substring(result.indexOf("|")+1);
    intOffSet = strRawKey.substring(strRawKey.indexOf("|")+1);
    intKey = Integer.parseInt(strRawKey.substring(0,strRawKey.indexOf("|")),16) - Integer.parseInt(intOffSet,16);
    strHexCrypData = result.substring(0,result.indexOf("|"));
    String [] arHexCharSet =strHexCrypData.split("!"+Long.toHexString(intKey));
    for(int i=0 ;i<arHexCharSet.length;i++){
      strRAW = strRAW + (char)(byte)(Long.parseLong(arHexCharSet[i],16)-intKey);
    }
    return strRAW;
  }

  public static String decrypt2(String source) {
    String result="";
    try {
      byte[] encrypted = asByte(source);
      Cipher c1 = Cipher.getInstance(TM.Algorithm);
      PBEParameterSpec  ap=new PBEParameterSpec(TM.salt,TM.count);
      c1.init(Cipher.DECRYPT_MODE, TM.genKey(),ap);
      byte[] original = c1.doFinal(encrypted);
      result= new String(original);
    }
    catch (Exception e) {
      e.printStackTrace();
    //  CCFLogger.error("", DecryptUtil.class, "decrypt", e.getMessage());
    }
    return result;
  }
  public static void main(String[] args) {
    System.out.println(TM.encrypt1("aaaaa111"));
    System.out.println(TM.encrypt1("123ss342a"));
    System.out.println(decrypt1(TM.encrypt1("test12342a")));

    System.out.println(decrypt1(TM.encrypt1("123ss342a")));
    //String a="test12342a213145152134����·��sadf2343412342312�й�2341234123";
    //System.out.println(a);
    //String ea=encrypt(a);
    //System.out.println(ea);
    System.out.println(decrypt("7f68f1c88a42c4d3c4f053f63a514567b673f38a6204f6aeb700419ee61a00dce44585d277f9143ee9f821b28adc94f4ead18c0b53282909bbe80bffdb38cd8f"));
  }
}


package test.core.example.test.pattern;

import com.beetle.framework.util.OtherUtil;

public class TestUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(OtherUtil.getLocalHostIps());

	}

}

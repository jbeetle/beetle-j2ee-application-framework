package test.core;

import javax.mail.MessagingException;

import com.beetle.framework.util.mail.Letter;
import com.beetle.framework.util.mail.SendLetter;
import com.beetle.framework.util.mail.SmtpServerInfo;

public class SendMail {

	public static void main(String[] args) {
		// 构建smtp服务器信息
		SmtpServerInfo ssi = new SmtpServerInfo("smptserverhost", "username",
				"password");
		// 构建一个邮件
		Letter letter = new Letter();
		letter.setSubject("hi,test");
		letter.setFrom("from@xx.com");
		letter.setTo("to@xxx.com");
		letter.setMessage("xxxxx");// 邮件内容，若发html格式可用letter.setHtmlMessage(arg0)
		try {
			letter.addAttachment("c:\\xxx.doc");// 添加附件
			SendLetter.send(letter, ssi);
		} catch (MessagingException e1) {
			e1.printStackTrace();
		}
	}
}

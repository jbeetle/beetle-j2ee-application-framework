package test.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

public class TestMe {
	public static void main(String[] args) {
		StringTokenizer st = new StringTokenizer("a,b,c,d", ",");
	    System.out.println(st.countTokens());
	    ArrayList li = new ArrayList();
	    while (st.hasMoreTokens()) {
	      li.add(st.nextToken());
	    }
	}
	/**
	 * @param args
	 */
	public static void main_(String[] args) {
		Map m = new HashMap();
		m.put("a", "b");
		Map m3 = new HashMap();
		m3.put("aa", "bb");
		Map m2 = new HashMap();
		m2.putAll(m);
		m2.putAll(m3);
		System.out.println(m2);
		m2.clear();
		System.out.println(m2);
		System.out.println(m);
		System.out.println(m3);
	}

	public static void main2(String[] args) {
		String a = "xx$/presentation.ctrl.account.ListAccountController.ctrl";
		String b = "$presentation/ctrl/account/ListAccountController.ctrl";
		if (b.indexOf('$') == 0) {
			b = b.substring(1);
			System.out.println(b);
		}
		System.out.println(formatPath(a));
		System.out.println(formatPath(b));

	}

	private static String formatPath(String a) {
		int k = a.indexOf('$');
		if (k >= 0) {
			a = a.substring(k + 1);
		}
		if (a.indexOf('/') == 0) {
			a = a.substring(1);
		}
		int i = a.lastIndexOf('.');
		if (i > 0) {
			a = a.substring(0, i);
		}
		return a;
	}

}

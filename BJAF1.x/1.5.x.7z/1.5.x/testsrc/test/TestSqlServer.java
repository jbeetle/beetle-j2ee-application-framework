package test;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Types;

import com.beetle.framework.persistence.dao.DaoFactory;

public class TestSqlServer {

	public static void main(String[] args) {

		// Create a variable for the connection string.
		String connectionUrl = "jdbc:sqlserver://10.25.17.68:52188;"
				+ "databaseName=demo";
		// Declare the JDBC objects.
		Connection con = null;
		CallableStatement stmt = null;
		ResultSet rs = null;

		try {
			// Establish the connection.
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			con = DriverManager.getConnection(connectionUrl, "sa", "asdF1234");

			// Create and execute an SQL statement that returns some data.
			String SQL = "SELECT  * FROM tbUser";
			String callstr = "{call Sp_Pagination(?,?,?,?,?)}";
			stmt = con.prepareCall(callstr);
			// stmt.setString(1, SQL);
			// stmt.setInt(2, 1);
			// stmt.setInt(3, 2);
			stmt.setObject(1, SQL, Types.VARCHAR);
			stmt.setObject(2, new Integer(1), Types.INTEGER);
			stmt.setObject(3, new Integer(2), Types.INTEGER);
			stmt.registerOutParameter(4, Types.INTEGER);
			stmt.registerOutParameter(5, Types.VARCHAR);
			if (stmt.execute()) {
				rs = stmt.getResultSet();
				while (rs.next()) {
					System.out.println(rs.getString(1) + "," + rs.getString(2)
							+ "," + rs.getString(3));
				}
				stmt.getMoreResults();
				rs = stmt.getResultSet();
				while (rs.next()) {
					System.out.println(rs.getString(1) + "-" + rs.getString(2)
							+ "-" + rs.getString(3));
				}
			}
		}

		// Handle any errors that may have occurred.
		catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (stmt != null)
				try {
					stmt.close();
				} catch (Exception e) {
				}
			if (con != null)
				try {
					con.close();
				} catch (Exception e) {
				}
		}
	}

}

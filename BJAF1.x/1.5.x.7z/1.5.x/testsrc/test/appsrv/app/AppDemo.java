package test.appsrv.app;

import com.beetle.framework.appsrv.AppMainImp;

public class AppDemo extends AppMainImp {
	public AppDemo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppDemo(int cmdSrvPort) {
		super(cmdSrvPort);
		// TODO Auto-generated constructor stub
	}

	private ModuleDemo md;

	public static void main(String arg[]) {
		AppDemo app = new AppDemo();
		if (arg.length == 0 || arg[0].equalsIgnoreCase("start")) {
			app.startServer();// 启动服务
		} else {
			app.executeCmd(arg[0]);// 发生命令参数
		}
	}

	protected void dealCmd(String cmd) {
		// 处理参数命令
		if (cmd == null) {
			return;
		}
		if (cmd.equalsIgnoreCase("help")) {
			System.out.println("--help");
			System.out.println("--shutdown");
		} else if (cmd.equalsIgnoreCase("shutdown")) {
			this.shutDownServer();
		}
	}

	protected void shutDownServerEvent() {
		System.out.println("shutDownServerEvent called!");

	}

	protected void starServertEvent() {
		// 在启动事件中，做相关初始化工作
		this.startCmdService();// 启动参数名称服务
		this.startThreadMonitorService();// 启动后台功能模块线程监控服务
		this.startMemoryWatcherService();// 启动内存监控服务
		md = new ModuleDemo("ModuleDemo", 30, 3000);// 构建ModuleDemo功能模块
		this.monitoThread(md);// 监控此模块线程运行
		md.startNow();// 启动此模块
		// ...
	}

}

package test.appsrv;

import com.beetle.framework.appsrv.SubRoutine;

public class TimeoutRoutine extends SubRoutine {
	protected void timeoutEvent() {
		i = 100;
		System.out.println("timeout envent");
	}

	private int i;

	public TimeoutRoutine(int i) {
		super(i);
		this.i = i;
	}

	protected void routine() throws InterruptedException {
		try {
			while (true) {
				if (i == 1000) {
					break;
				}
			}
			System.out.println("routine ..." + i);
		} catch (Throwable e) {
			if (i == 100 && e instanceof java.lang.ThreadDeath) {
				System.out.println("e ...00000000000000000");
			}
		}
	}
}

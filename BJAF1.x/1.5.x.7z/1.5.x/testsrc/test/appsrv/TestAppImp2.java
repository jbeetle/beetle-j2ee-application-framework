package test.appsrv;

import com.beetle.framework.appsrv.AppThreadImp;

public class TestAppImp2 extends AppThreadImp {

	protected void end() {
		System.out.println("end call");
	}

	private int i;

	public TestAppImp2(int interval, int i) {
		super(interval);
		this.i = i;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new TestAppImp2(3000, 0).startNow();
	}

	protected void workProc() {
		i++;
		System.out.println(i);
		if (i > 10) {
			//throw new AppRuntimeException("out");
			//this.stopNow();
			this.stopBrutally();
		}
	}

}

package test.appsrv.remoting;

import java.util.Collection;
import java.util.Iterator;

import com.beetle.framework.appsrv.remoting.MessageServer;
import com.beetle.framework.appsrv.remoting.MsgRes;
import com.beetle.framework.appsrv.remoting.MessageServer.RequestSession;

public class AEchoServer {
	private static class Send implements Runnable {
		private MessageServer ms;

		public Send(MessageServer ms) {
			this.ms = ms;
		}

		public void run() {
			while (true) {
				Collection c = ms.getRequestSessionCollection();
				Iterator it = c.iterator();
				while (it.hasNext()) {
					RequestSession rs = (RequestSession) it.next();
					if (rs.getVerifyTime() > 0) {
						MsgRes res = new MsgRes();
						res.put("mykey", "yes"
								+ System.currentTimeMillis());
						rs.pushMessageToClient(res);
					}
				}
				try {
					Thread.sleep(500);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

		}

	}

	public static void main(String[] args) {
		MessageServer ms = new MessageServer(9090);
		ms.registerServerAction(new EchoServerAction());
		ms.start();
		//new Thread(new Send(ms)).start();
	}

}

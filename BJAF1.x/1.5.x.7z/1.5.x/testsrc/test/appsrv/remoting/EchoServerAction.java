package test.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.Header;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MessageServer;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;

public class EchoServerAction extends MessageServer.ServerAction {

	public boolean authenticate(String username, String password) {
		if (username.equals("Henry") && password.equals("888888")) {
			return true;
		}
		return false;
	}

	public MsgRes requestHandle(MsgReq req) throws MessageCommunicateException {
		System.out.println(req);
		Header header = req.getHeader();
		System.out.println(header);
		if (header == null || header.getMethod() == null) {
			System.out.println("return null-1");
			return null;
		}
		if (header.getMethod().equals(Header.METHOD_INVOKE)) {
			String word = req.getValueAsString("word");
			MsgRes res = new MsgRes();
			res.put("echo", "echo:["
					+ System.currentTimeMillis() + "]" + word); 
			System.out.println(res);
			return res;
		} else {
			System.out.println("return null-2");
			return null;
		}
	}

	protected void beforeStopServerEvent() throws MessageCommunicateException {
		System.out.println("beforeStopServerEvent");
	}

	protected void connectionBreakEvent(String sessionId)
			throws MessageCommunicateException {
		System.out.println("connectionBreakEvent[" + sessionId + "]");
	}

	protected void sessionBeforeLoseEvent(String sessionId)
			throws MessageCommunicateException {
		System.out.println("sessionBeforeLoseEvent[" + sessionId + "]");
	}

	protected void sessionCreatedEvent(String sessionId)
			throws MessageCommunicateException {
		System.out.println("sessionCreatedEvent[" + sessionId + "]");
	}
}

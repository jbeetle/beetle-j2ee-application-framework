package test.appsrv;

import com.beetle.framework.appsrv.AppRunnable;

public class TestAppRunnable {

	private static class T extends AppRunnable {

		protected void end() {
			System.out.println("--end");

		}

		public void run() {
			while (!this.getStopFlag()) {
				System.out.println(System.currentTimeMillis());
				this.sleep(200);
			}

		}

	}

	public static void main(String[] args) throws InterruptedException {
		T t=new T();
		t.startNow();
		System.out.println("A");
		Thread.sleep(10000);
		t.stopBrutally();
		System.out.println("B");
	}

}

package test;

import com.beetle.framework.appsrv.SubRoutine;

public class DemoRoutine extends SubRoutine {
	public DemoRoutine(int maxBlockTime) {
		super(maxBlockTime);// ��ȡ��ʱ�����캯��
	}

	protected void routine2() throws InterruptedException {
		System.out.println(System.currentTimeMillis() + "->do something...");
	}

	protected void routine() throws InterruptedException {
		while (true) {// ��ѭ��
			System.out
					.println(System.currentTimeMillis() + "->do something...");
		}
	}
}
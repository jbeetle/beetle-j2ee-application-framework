package test.persistence;

import test.persistence.dao.IMyTableDao;
import test.persistence.dao.PsMyTable;
import test.persistence.vo.MyTable;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.persistence.dao.DaoFactory;

public class TestDao {

	/**
	 * @param args
	 */
	private static class T extends AppThreadImp {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public T(int interval) {
			super(interval);
		}

		protected void workProc() {
			IMyTableDao dao = (IMyTableDao) DaoFactory
					.getDaoObject(PsMyTable.class);
			for (int i = 0; i < 1; i++) {
				MyTable mt = new MyTable();
				mt.setId("" + i);
				mt.setVl("Henry" + i);
				dao.insertTable1(mt);
			}
		}

		protected void end() {

		}

	}

	public static void main(String[] args) {
		for (int i = 0; i < 1; i++) {
			new T(i * 1000).startNow();
		}
		System.out.println("ok");
	}

}

package test.persistence;

import com.beetle.framework.persistence.access.operator.QueryOperator;
import com.beetle.framework.persistence.access.operator.RsDataSet;
import com.beetle.framework.persistence.access.operator.SqlParameter;
import com.beetle.framework.persistence.access.operator.SqlServerProcOperator;
import com.beetle.framework.persistence.access.operator.SqlType;

public class TestMe {

	public static void main(String[] args) {
		String sql = "SELECT EmployeeID, LastName, FirstName, Title, TitleOfCourtesy, BirthDate, HireDate, Address, City FROM  Employees";
		SqlServerProcOperator proc = new SqlServerProcOperator();
		proc.setSql("Sp_Pagination");
		//proc.setSql("test_update");
		 //proc.addParameter(sql);
		 //proc.addParameter(new Integer(1));
		 //proc.addParameter(new Integer(3));
		proc.addParameter(new SqlParameter(SqlType.VARCHAR, sql));
		proc.addParameter(new SqlParameter(SqlType.INTEGER, new Integer(1)));
		proc.addParameter(new SqlParameter(SqlType.INTEGER, new Integer(3)));
		proc.access();
		System.out.println(proc.getReturnFlag());
		System.out.println(proc.getReturnMsg());
		RsDataSet rs = new RsDataSet(proc.getSqlResultSet());
		for (int i = 0; i < rs.rowCount; i++) {
			for (int j = 0; j < rs.colCount; j++) {
				System.out.println(rs.getFieldValue(j));
			}
			System.out.println("-");
			rs.next();
		}
		//proc.
	}

	public static void main2(String[] args) {
		QueryOperator query = new QueryOperator();
		query.setSql("SELECT * FROM Employees");
		query.access();
		RsDataSet rs = new RsDataSet(query.getSqlResultSet());
		for (int i = 0; i < rs.rowCount; i++) {
			for (int j = 0; j < rs.colCount; j++) {
				System.out.println(rs.getFieldValue(j));
			}
			System.out.println("-");
			rs.next();
		}

	}

}

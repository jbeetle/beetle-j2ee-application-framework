package test.persistence;

import java.math.BigDecimal;
import java.sql.Timestamp;

import com.beetle.framework.persistence.access.operator.RsDataSet;
import com.beetle.framework.persistence.composite.CompositeQueryOperator;

public class TestSQL {

	public static void main(String[] args) {
		String EMPNO = null;// 设置参数（从页面获取输入参数）
		String ENAME = null;
		String JOB = null;
		BigDecimal MGR = null;
		Timestamp HIREDATE = null;
		BigDecimal SAL_1 = null;
		BigDecimal SAL_2 = null;
		BigDecimal COMM = null;
		BigDecimal DEPTNO = null;
		CompositeQueryOperator cqo = new CompositeQueryOperator();
		cqo.setDataSourceName("SYSDATASOURCE_DEFAULT");// 数据数据源
		cqo.setSql("select * from emp");// 数据查询语句（只填显示字段select部分，无需写where子句）
		cqo.addParameter("EMPNO", "=", EMPNO);// 添加各种组合条件字段
		cqo.addParameter("ENAME", "=", ENAME);
		cqo.addParameter("JOB", "=", JOB);
		cqo.addParameter("MGR", "=", MGR);
		cqo.addParameter("HIREDATE", ">", HIREDATE);
		cqo.addParameter("SAL", ">=", SAL_1);
		cqo.addParameter("SAL", "<=", SAL_2);
		cqo.addParameter("COMM", "=", COMM);
		cqo.addParameter("DEPTNO", "=", DEPTNO);
		cqo.access();// 执行查询
		if (cqo.resultSetAvailable()) {// 处理结果，处理结果请参考QueryOperator，这里只是打印出来
			RsDataSet rs = new RsDataSet(cqo.getSqlResultSet());
			for (int i = 0; i < rs.rowCount; i++) {
				for (int j = 0; j < rs.colCount; j++) {
					System.out.println(rs.getFieldValue(j));
				}
				rs.next();
				System.out.println("--");
			}
		}
	}
}

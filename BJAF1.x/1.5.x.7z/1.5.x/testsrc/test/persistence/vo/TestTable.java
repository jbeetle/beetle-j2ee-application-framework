package test.persistence.vo;

import java.math.BigDecimal;

import com.beetle.framework.persistence.access.operator.TableOperator;

public class TestTable {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		TableOperator operator = new TableOperator("SYSDATASOURCE_DEFAULT",
				"TBJOB", TbTBJOB.class);
		TbTBJOB job = (TbTBJOB) operator
				.selectByPrimaryKey(new BigDecimal(1093));
		System.out.println(job);
	}

}

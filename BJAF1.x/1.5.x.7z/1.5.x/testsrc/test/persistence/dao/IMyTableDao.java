package test.persistence.dao;

import test.persistence.vo.MyTable;

public interface IMyTableDao {
	int insertTable1(MyTable table);

	int insertTable2(MyTable table);

	int updateTable1(MyTable table);

	int updateTable2(MyTable table);
}

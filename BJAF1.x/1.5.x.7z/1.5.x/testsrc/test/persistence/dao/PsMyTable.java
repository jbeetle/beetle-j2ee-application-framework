package test.persistence.dao;

import test.persistence.vo.MyTable;

import com.beetle.framework.persistence.access.operator.TableOperator;
import com.beetle.framework.persistence.access.operator.UpdateOperator;

public class PsMyTable implements IMyTableDao {
	private TableOperator tableOperator;

	public PsMyTable() {
		this.tableOperator = new TableOperator("SYSDATASOURCE_XXX", "myt1",
				MyTable.class);
	}

	public int insertTable1(MyTable table) {
		return tableOperator.insert(table);
	}

	public int insertTable1_(MyTable table) {
		UpdateOperator update = new UpdateOperator();
		update.setDataSourceName("SYSDATASOURCE_XXX");
		update.setSql("insert into myt1 (id,vl)values (?,?)");
		update.addParameter(table.getId());
		update.addParameter(table.getVl());
		update.access();
		return update.getEffectCounts();
	}

	public int insertTable2(MyTable table) {
		UpdateOperator update = new UpdateOperator();
		update.setDataSourceName("SYSDATASOURCE_DEFAULT");
		update.setSql("insert into myt2 (id,vl)values (?,?)");
		update.addParameter(table.getId());
		update.addParameter(table.getVl());
		update.access();
		return update.getEffectCounts();
	}

	public int updateTable1(MyTable table) {
		UpdateOperator update = new UpdateOperator();
		update.setDataSourceName("SYSDATASOURCE_DEFAULT");
		update.setSql("update myt1 set vl=? where id=?");
		update.addParameter(table.getVl());
		update.addParameter(table.getId());
		update.access();
		return update.getEffectCounts();
	}

	public int updateTable2(MyTable table) {
		UpdateOperator update = new UpdateOperator();
		update.setDataSourceName("SYSDATASOURCE_DEFAULT");
		update.setSql("update myt2 set vl=? where id=?");
		update.addParameter(table.getVl());
		update.addParameter(table.getId());
		update.access();
		return update.getEffectCounts();
	}

}

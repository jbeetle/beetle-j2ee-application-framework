package com.beetle.framework.util.pattern.di;

import javax.inject.Inject;

public class ServiceClient {
	private IService service;
	private IServiceImp imp;

	
	public void setImp(IServiceImp imp) {
		this.imp = imp;
	}

	@Inject
	public void setService(IService service) {
		this.service = service;
	}

	public void work2() {
		imp.doit();
	}

	public void work() {
		service.doit();
	}

}

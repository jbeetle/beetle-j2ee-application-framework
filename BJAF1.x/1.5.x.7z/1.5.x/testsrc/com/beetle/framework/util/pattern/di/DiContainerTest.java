package com.beetle.framework.util.pattern.di;

import java.io.File;

public class DiContainerTest {

	public static void main(String arg[]) {
		Dependency dy = new Dependency();
		// dy.bind(IService.class, IServiceImp.class, true);
		// dy.bind(IServiceImp.class, true);
		//dy.bind(IService.class, Service2Provider.class);
		dy.bindFromConfig(new File("D:\\DIBinder.xml"));
		DIContainer di = new DIContainer(dy);
		ServiceClient sc = di.getInstance(ServiceClient.class);
		sc.work();
		//sc.work2();
	}
}

package com.beetle.framework.util.cache;

import java.util.Iterator;
import java.util.Map;

import junit.framework.TestCase;

public class ConcurrentCacheTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	// to test
	public static void main(String arg[]) {
		ConcurrentCache cc = new ConcurrentCache();
		cc.put("aaa", "0xxxx");
		cc.put("bbb", "1xxxx");
		cc.put("ccc", "2xxxx");
		cc.put("ddd", "3xxxx");
		Iterator it = cc.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			if (kv.getKey().equals("ccc")) {
				it.remove();
			}
		}
		System.out.println(cc.values());
	}
}

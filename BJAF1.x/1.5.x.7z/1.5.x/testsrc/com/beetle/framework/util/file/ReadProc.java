package com.beetle.framework.util.file;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.beetle.framework.appsrv.AppThreadImp;

public class ReadProc {

	private static class T extends AppThreadImp {

		public T(int interval) {
			super(interval);
			// TODO Auto-generated constructor stub
		}

		protected void workProc() {
			System.out.println("---->");
			c();
			System.out.println("---->");
		}

	}

	public static void main(String[] args) {
		new T(200).startNow();

	}

	private static void c() {
		try {
			IPCFile ipc = new IPCFile("d:\\jobs_err_info.tmp2", 1024 * 100);
			while (true) {
				if (ipc.tryLock()) {
					HashMap m = (HashMap) ipc.read();
					if (m != null) {
						Iterator it = m.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry kv = (Map.Entry) it.next();
							// BigDecimal jobid = (BigDecimal) kv.getKey();
							// MsgReq req = (MsgReq) kv.getValue();
							System.out.println(kv.getKey());
							// System.out.println(kv.getValue());
						}
						m.clear();
						ipc.write(m);
						break;
					}
				}
			}
			ipc.unlock();
			ipc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

package com.beetle.framework.util.pattern.di;

public class Service2Provider extends ServiceProvider<IService> {

	@Override
	public IService get() {
		return new IServiceImp();
		//return null;
	}

}

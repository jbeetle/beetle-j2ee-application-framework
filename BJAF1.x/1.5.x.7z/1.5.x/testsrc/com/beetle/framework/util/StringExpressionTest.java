package com.beetle.framework.util;

public class StringExpressionTest {
	public static void main(String arg[]) {
		String x = "I am ${name},and sex is ${sex}.";
		StringExpression se = new StringExpression(x);
		se.set("name", "Henry");
		se.set("sex", "M");
		System.out.println(se.getResult());
	}
}

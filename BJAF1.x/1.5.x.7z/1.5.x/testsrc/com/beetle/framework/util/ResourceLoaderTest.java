package com.beetle.framework.util;

import java.io.IOException;

import org.junit.Assert;
import org.junit.Test;

public class ResourceLoaderTest {

	@Test
	public void testGetResourceContentFromJarFile() {
		try {
			String a = ResourceLoader.getResourceContentFromJarFile(
					"d:\\beetle.jar", "config/application.properties");
			System.out.println(a);
			Assert.assertTrue(true);
		} catch (IOException e) {
			e.printStackTrace();
			Assert.assertTrue(false);
		}
	}

}

package com.beetle.framework.util.file;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.appsrv.remoting.MsgReq;

public class WriteProc {

	private static class T extends AppThreadImp {

		public T(int interval) {
			super(interval);
			// TODO Auto-generated constructor stub
		}

		protected void workProc() {
			zz();

		}

	}

	public static void main(String[] args) {
		new T(1500).startNow();
	}

	private static void zz() {
		IPCFile ipcf = null;
		Map m = null;
		try {
			ipcf = new IPCFile("d:\\jobs_err_info.tmp2", 1024 * 100);
			int i = 0;
			while (true) {
				i++;
				if (ipcf.tryLock()) {
					m = (Map) ipcf.read();
					if (m == null) {
						m = new HashMap();
					}
					// m.put(jobid, msg);
					TbTBJOB job = new TbTBJOB();
					job.setCREATETIME(new Timestamp(System.currentTimeMillis()));
					job.setJARNAME("xxxx" + i);
					job.setJOBSTATUS(new BigDecimal(1000));
					MsgReq rq = new MsgReq();
					rq.put("xxx" + i, job);
					m.put(new BigDecimal(System.currentTimeMillis()), rq);
					// /
					ipcf.write(m);
					ipcf.flush();
					System.out.println("write ok");
					break;
				} else {
					Thread.sleep(1000);
					if (i > 60 * 2) {// 最多等2分钟
						break;
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (m != null) {
				m.clear();
				m = null;
			}
			try {
				ipcf.unlock();
				ipcf.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}

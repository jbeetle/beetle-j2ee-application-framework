package com.beetle.framework.util.pattern.di;

public interface IService {
	abstract void doit();
}

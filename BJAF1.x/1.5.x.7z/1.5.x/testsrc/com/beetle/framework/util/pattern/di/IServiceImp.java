package com.beetle.framework.util.pattern.di;

public class IServiceImp implements IService {

	@Override
	public void doit() {
		System.out.println("--------do it---------");
	}

}

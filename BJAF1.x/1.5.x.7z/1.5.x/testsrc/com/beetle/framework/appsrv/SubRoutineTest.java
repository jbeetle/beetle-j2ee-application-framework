package com.beetle.framework.appsrv;

public class SubRoutineTest {
	private static class T extends SubRoutine {

		void terminated() {
			System.out.println("terminated");
			clearSystemStream();
			System.exit(0);
		}

		public T(int maxBlockTime) {
			super(maxBlockTime);
		}

		protected void routine() throws InterruptedException {
			while (true) {
				// System.out.println(System.currentTimeMillis());
				this.sleep(5100 * 10);
				// Thread.sleep(1000);
			}
		}

	}

	private static void clearSystemStream() {
		try {
			if (System.in != null) {
				System.in.close();
			}
			if (System.out != null) {
				System.out.close();
			}
			if (System.err != null) {
				System.err.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String arg[]) {
		RoutinePool wtp = new RoutinePool(2, 2, 60 * 1000, false);
		// RoutineExecutor re = new RoutineExecutor(wtp);
		// re.addSubRoutine(new T(5).killThreadWhenTimeout());
		// re.runRoutine();
		wtp.runInPool(new T(5000));
		System.out.println("ok1");
		// RoutinesPool.runRoutineInPool(new T(5).killThreadWhenTimeout());
	}

	public static void main3(String arg[]) {
		RoutinePool.getCommonPool().runInPool(new T(5));
	}
}

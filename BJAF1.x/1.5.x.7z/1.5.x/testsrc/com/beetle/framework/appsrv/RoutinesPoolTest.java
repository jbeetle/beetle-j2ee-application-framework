package com.beetle.framework.appsrv;

import junit.framework.TestCase;

public class RoutinesPoolTest extends TestCase {

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

}

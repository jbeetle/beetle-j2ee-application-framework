package com.beetle.framework.appsrv.pubsub;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.appsrv.pubsub.Subscriber.SubWorker;

public class PsEntryTest {
	private static class P extends Publisher.PubWorker {

		protected Document produceDocument() throws AppRuntimeException {
			Document doc = new Document(new SubWorker() {
				public void handleDocument(Document doc)
						throws AppRuntimeException {
					System.out.println(doc);
				}
			});
			doc.put("curtime", new java.util.Date(System.currentTimeMillis()));
			return doc;
		}

	}

	public static void main(String arg[]) throws Exception {
		PsEntry ps=new PsEntry(4);
		ps.joinIn(new P());
		ps.execute();
		System.out.println("done");
	}

}

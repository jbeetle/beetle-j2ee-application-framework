package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.persistence.access.ConnectionFactory;

public class DriverPoolTest {

	private static class T extends AppThreadImp {

		public T() {
			super();
			this.setCycleFlag(MANUAL_CYCLE);
		}

		@Override
		protected void workProc() {
			long l=System.currentTimeMillis();
			for (int i = 0; i < 50; i++) {
				Connection con = ConnectionFactory
						.getConncetion("SYSDATASOURCE_DEFAULT");
				try {
					System.out.println(con.getMetaData());
					//con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println(System.currentTimeMillis()-l);
		}

	}

	public static void main(String arg[]) {
		for (int i = 0; i < 5; i++) {
			new T().startNow();
		}
	}

}

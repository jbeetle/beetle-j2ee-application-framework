package com.beetle.framework.persistence.storage.imp;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import test.persistence.vo.MyTable;

import com.beetle.framework.persistence.storage.StorageObj;

public class PsH2StorageTest {
	public static void main(String arg[]) {
		PsH2Storage ps = PsH2Storage.getInstance();
		ps.open();
		String id = "";
		List lt = new ArrayList();
		for (int i = 0; i < 500; i++) {
			lt.add(id + i);
		}
		ps.deleteBatch(lt);
		ps.close();
	}

	public static void main2(String arg[]) {
		PsH2Storage ps = PsH2Storage.getInstance();
		ps.open();
		int k = 0;
		String id = "";
		for (int i = 0; i < 500; i++) {
			StorageObj so = new StorageObj();
			so.setId(id + i);
			so.setPlus("ccccz");
			MyTable my = new MyTable();
			my.setId("xxx");
			my.setVl("dsjfldsjflkjdflkjdlskfj");
			so.setStatus(new Integer(100));
			so.setObj(my);
			so.setCreatetime(new Timestamp(System.currentTimeMillis()));
			so.setLasttime(new Timestamp(System.currentTimeMillis()));
			ps.create(so);
			k++;
			System.out.println(i);
		}
		ps.close();
	}
}

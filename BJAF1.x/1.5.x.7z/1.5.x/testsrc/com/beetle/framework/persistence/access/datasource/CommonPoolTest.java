package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class CommonPoolTest {
	public static void main(String arg[]) throws Throwable {
		CommonPool pool = new CommonPool();
		pool.setConURL("jdbc:mysql://cnsz020525:3308/demo");
		pool.setDriverName("com.mysql.jdbc.Driver");
		pool.setMax(5);
		pool.setUsername("scheduler");
		pool.setPassword("760224");
		pool.start();
		Connection conn = pool.getConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select * from User");
		rs.next();
		System.out.println(rs.getString(2));
		conn.close();
		pool.shutdown();
		System.out.println("OK");
	}

	public static void main_microsoft(String arg[]) throws Throwable {
		CommonPool pool = new CommonPool();
		pool.setConURL("jdbc:sqlserver://10.25.17.68:52188;databaseName=demo");
		pool.setDriverName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		pool.setMax(5);
		pool.setUsername("sa");
		pool.setPassword("asdF1234");
		pool.start();
		Connection conn = pool.getConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select * from tbUser");
		rs.next();
		System.out.println(rs.getString(2));
		conn.close();
		pool.shutdown();
		System.out.println("OK");
	}

	public static void main_jtds(String arg[]) throws Throwable {
		CommonPool pool = new CommonPool();
		pool.setConURL("jdbc:jtds:sqlserver://10.25.17.68:52188/demo;tds=8.0;lastupdatecount=true");
		pool.setDriverName("net.sourceforge.jtds.jdbc.Driver");
		pool.setMax(5);
		pool.setUsername("sa");
		pool.setPassword("asdF1234");
		pool.start();
		Connection conn = pool.getConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select * from tbUser");
		rs.next();
		System.out.println(rs.getString(2));
		conn.close();
		pool.shutdown();
		System.out.println("OK");
	}

	public static void main_oracle(String arg[]) throws Throwable {
		CommonPool pool = new CommonPool();
		pool.setConURL("jdbc:oracle:thin:@CNSZ020525:1521:hdyusid");
		pool.setDriverName("oracle.jdbc.driver.OracleDriver");
		pool.setMax(5);
		pool.setUsername("tjs");
		pool.setPassword("88888888");
		pool.start();
		Connection conn = pool.getConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select sysdate from dual");
		rs.next();
		System.out.println(rs.getString(1));
		conn.close();
		pool.shutdown();
		System.out.println("OK");
	}

}

package com.beetle.framework.persistence.pagination.imp;

import com.beetle.framework.persistence.access.operator.RsDataSet;
import com.beetle.framework.persistence.pagination.PageParameter;
import com.beetle.framework.persistence.pagination.PageResult;
import com.beetle.framework.persistence.pagination.PaginationException;

public class SqlServerPaginationImpTest {
	public static void main(String[] args) throws PaginationException {
		PageParameter pp = new PageParameter();
		pp.setCacheRecordAmountFlag(true);
		pp.setDataSourceName("SYSDATASOURCE_SQLSERVER");
		pp.setPageNumber(1);
		pp.setPageSize(2);
		pp.setUserSql("SELECT  * FROM tbUser");
		// pp.setUserSql(
		// "SELECT * FROM  fc_AccRecord2View where  group_id=?  and gen_mode=? and rec_status in (100)");
		// pp.addParameter(new SqlParameter(SqlType.BIGINT, new
		// Long(500000000000002l)));
		// pp.addParameter(new SqlParameter(SqlType.INTEGER, new Integer(10)));
		SqlServerPaginationImp sp = new SqlServerPaginationImp();
		PageResult pr = sp.page(pp);
		System.out.println(pr.getRecordAmount());
		System.out.println(pr.getCurPageNumber());
		System.out.println(pr.getCurPageSize());
		RsDataSet rs = new RsDataSet(pr.getSqlResultSet());
		for (int i = 0; i < rs.rowCount; i++) {
			for (int j = 0; j < rs.colCount; j++) {
				System.out.println(rs.getFieldValue(j));
			}
			rs.next();
			System.out.println("---");
		}
		// PageDataList
	}
}

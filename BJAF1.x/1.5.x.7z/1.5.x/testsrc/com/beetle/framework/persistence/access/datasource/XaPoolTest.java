package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class XaPoolTest {

	public static void main(String arg[]) throws Throwable {
		XaPool pool = new XaPool();
		pool.setConURL("jdbc:oracle:thin:@CNSZ020525:1521:hdyusid");
		pool.setDriverName("oracle.jdbc.xa.client.OracleXADataSource");
		pool.setMax(5);
		pool.setUsername("tjs");
		pool.setPassword("88888888");
		pool.start();
		Connection conn = pool.getConnection();
		Statement s = conn.createStatement();
		ResultSet rs = s.executeQuery("select sysdate from dual");
		rs.next();
		System.out.println(rs.getString(1));
		conn.close();
		pool.shutdown();
		System.out.println("OK");
	}
}

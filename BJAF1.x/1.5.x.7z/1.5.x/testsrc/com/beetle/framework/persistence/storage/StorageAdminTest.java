package com.beetle.framework.persistence.storage;

import junit.framework.TestCase;

public class StorageAdminTest extends TestCase {

	public StorageAdminTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetAccess() {
		try {
			StorageAdmin.getAccess();
			assertTrue(true);
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.getMessage());
		}
	}

}

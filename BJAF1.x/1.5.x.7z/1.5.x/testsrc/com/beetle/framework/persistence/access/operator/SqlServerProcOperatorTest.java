package com.beetle.framework.persistence.access.operator;

public class SqlServerProcOperatorTest {
	public static void main(String arg[]) {
		SqlServerProcOperator proc = new SqlServerProcOperator();
		proc.setDataSourceName("SYSDATASOURCE_SQLSERVER");
		proc.setSql("Sp_Pagination");
		proc.addParameter(new SqlParameter(SqlType.VARCHAR,
				"select * from tbUser"));
		proc.addParameter(new SqlParameter(SqlType.INTEGER, Integer.valueOf(1)));
		proc.addParameter(new SqlParameter(SqlType.INTEGER, Integer.valueOf(2)));
		proc.access();
		RsDataSet rs = new RsDataSet(proc.getSqlResultSet());
		for (int i = 0; i < rs.rowCount; i++) {
			for (int j = 0; j < rs.colCount; j++) {
				System.out.println(rs.getFieldValue(j));
			}
			rs.next();
			System.out.println("---");
		}
	}
}

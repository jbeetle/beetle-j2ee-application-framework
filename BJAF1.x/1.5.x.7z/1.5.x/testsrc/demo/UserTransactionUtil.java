package demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import javax.transaction.UserTransaction;

import com.atomikos.icatch.jta.UserTransactionImp;
import com.atomikos.jdbc.AtomikosDataSourceBean;

/**
*
*/
public class UserTransactionUtil {

	public static UserTransaction getUserTransaction() {
		UserTransaction utx = new UserTransactionImp();
		return utx;
	}

	private static AtomikosDataSourceBean dsBean;

	private static AtomikosDataSourceBean getDataSource() {
		if (dsBean != null)
			return dsBean;
		AtomikosDataSourceBean ds = new AtomikosDataSourceBean();
		ds.setUniqueResourceName("db");
		ds.setXaDataSourceClassName("oracle.jdbc.xa.client.OracleXADataSource");
		Properties p = new Properties();
		p.setProperty("user", "db_user_name");
		p.setProperty("password", "db_user_pwd");
		p.setProperty("URL", "jdbc:oracle:thin:@192.168.0.10:1521:oradb");
		ds.setXaProperties(p);
		ds.setPoolSize(5);
		dsBean = ds;
		return dsBean;
	}

	public static Connection getDbConnection() throws SQLException {
		Connection conn = getDataSource().getConnection();
		return conn;
	}

	private static AtomikosDataSourceBean dsBean1;

	private static AtomikosDataSourceBean getDataSource1() {
		if (dsBean1 != null)
			return dsBean1;
		AtomikosDataSourceBean ds = new AtomikosDataSourceBean();
		ds.setUniqueResourceName("db1");
		ds.setXaDataSourceClassName("oracle.jdbc.xa.client.OracleXADataSource");
		Properties p = new Properties();
		p.setProperty("user", "db_user_name");
		p.setProperty("password", "db_user_pwd");
		p.setProperty("URL", "jdbc:oracle:thin:@192.168.0.11:1521:oradb1");
		ds.setXaProperties(p);
		ds.setPoolSize(5);
		dsBean1 = ds;
		return dsBean1;
	}

	public static Connection getDb1Connection() throws SQLException {
		Connection conn = getDataSource1().getConnection();
		return conn;
	}

	public static void main(String[] args) {
		UserTransaction utx = getUserTransaction();
		boolean rollback = false;
		try {
			// begin a transaction
			utx.begin();

			// execute db operation
			Connection conn = null;
			Connection conn1 = null;
			Statement stmt = null;
			Statement stmt1 = null;
			try {
				conn = getDbConnection();
				conn1 = getDb1Connection();

				stmt = conn.createStatement();
				stmt.executeUpdate("insert into t values(1,'23')");

				stmt1 = conn1.createStatement();
				stmt1.executeUpdate("insert into t values(1,'123456789')");

			} catch (Exception e) {
				throw e;
			} finally {
				if (stmt != null)
					stmt.close();
				if (conn != null)
					conn.close();
				if (stmt1 != null)
					stmt1.close();
				if (conn1 != null)
					conn1.close();
			}
		} catch (Exception e) {
			// an exception means we should not commit
			rollback = true;
			e.printStackTrace();
		} finally {
			try {
				// commit or rollback the transaction
				if (!rollback)
					utx.commit();
				else
					utx.rollback();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}

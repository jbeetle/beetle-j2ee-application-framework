package demo;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import javax.sql.XAConnection;
import javax.transaction.Transaction;
import javax.transaction.xa.XAResource;

import oracle.jdbc.xa.client.OracleXADataSource;

import com.atomikos.icatch.jta.UserTransactionManager;

public class TransactionManagerUtil {
	public static UserTransactionManager getUserTransactionManager()
			throws Exception {
		return new UserTransactionManager();
	}

	private static OracleXADataSource xads;

	private static OracleXADataSource getXADataSource() throws SQLException {
		if (xads != null)
			return xads;
		xads = new OracleXADataSource();
		xads.setUser("db_user_name");
		xads.setPassword("db_user_pwd");
		xads.setURL("jdbc:oracle:thin:@192.168.0.10:1521:oradb");
		return xads;
	}

	public static XAConnection getXAConnection() throws SQLException {
		OracleXADataSource ds = getXADataSource();
		return ds.getXAConnection();
	}

	private static OracleXADataSource xads1;

	private static OracleXADataSource getXADataSource1() throws SQLException {
		if (xads1 != null)
			return xads1;
		xads1 = new OracleXADataSource();
		xads1.setUser("db_user_name");
		xads1.setPassword("db_user_pwd");
		xads1.setURL("jdbc:oracle:thin:@192.168.0.11:1521:oradb1");
		return xads1;
	}

	public static XAConnection getXAConnection1() throws SQLException {
		OracleXADataSource ds = getXADataSource1();
		return ds.getXAConnection();
	}

	public static void main(String[] args) {
		try {
			UserTransactionManager tm = getUserTransactionManager();

			XAConnection xaconn = getXAConnection();
			XAConnection xaconn1 = getXAConnection1();

			boolean rollback = false;
			try {
				// begin and retrieve tx
				tm.begin();
				Transaction tx = tm.getTransaction();

				// get the XAResourc from the JDBC connection
				XAResource xares = xaconn.getXAResource();
				XAResource xares1 = xaconn1.getXAResource();

				// enlist the resource with the transaction
				// NOTE: this will only work if you set the configuration
				// parameter:
				// com.atomikos.icatch.automatic_resource_registration=true
				// or, alternatively, if you use the UserTransactionService
				// integration mode
				tx.enlistResource(xares);
				tx.enlistResource(xares1);

				// access the database, the work will be
				// subject to the outcome of the current transaction
				Connection conn = xaconn.getConnection();
				Statement stmt = conn.createStatement();
				stmt.executeUpdate("insert into t values(1,'1234567')");
				stmt.close();
				conn.close();
				Connection conn1 = xaconn1.getConnection();
				Statement stmt1 = conn1.createStatement();
				stmt1.executeUpdate("insert into t values(1,'abc1234567890')");
				stmt1.close();
				conn1.close();

				// delist the resource
				tx.delistResource(xares, XAResource.TMSUCCESS);
				tx.delistResource(xares1, XAResource.TMSUCCESS);
			} catch (Exception e) {
				// an exception means we should not commit
				rollback = true;
				throw e;
			} finally {
				// ALWAYS terminate the tx
				if (rollback)
					tm.rollback();
				else
					tm.commit();

				// only now close the connection
				// i.e., not until AFTER commit or rollback!
				xaconn.close();
				xaconn1.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

package db;

import com.beetle.framework.persistence.access.DBConfig;

public class TestMe {

	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		System.out.println(DBConfig
				.decodeDatasourcePassword("SYSDATASOURCE_DEFAULT"));

	}

}

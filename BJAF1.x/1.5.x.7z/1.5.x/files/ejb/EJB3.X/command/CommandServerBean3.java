package com.beetle.framework.business.ejb3.command;

import com.beetle.framework.business.command.CommandImp;
import com.beetle.framework.business.ejb.command.CommandServerBean;
import javax.ejb.Stateless;
import javax.ejb.TransactionManagement;

@TransactionManagement(javax.ejb.TransactionManagementType.BEAN)
@Stateless(name="CommandServerBean3")

public class CommandServerBean3 implements ICommandLocal,ICommandRemote{
  public CommandServerBean3() {

  }

  public CommandImp executeCommandWithTransaction(CommandImp command) {
    CommandServerBean csb=new CommandServerBean();
    return csb.executeCommandWithTransaction(command);
  }

  public CommandImp executeCommand(CommandImp command) {
    CommandServerBean csb=new CommandServerBean();
    return csb.executeCommand(command);
  }
}

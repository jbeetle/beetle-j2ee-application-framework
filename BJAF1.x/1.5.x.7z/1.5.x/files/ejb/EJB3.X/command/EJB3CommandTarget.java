package com.beetle.framework.business.ejb3.command;

import com.beetle.framework.business.command.ICommandTarget;
import com.beetle.framework.business.command.CommandImp;
import com.beetle.framework.business.command.CommandExecuteException;
import com.beetle.framework.resource.AppContext;
import javax.naming.NamingException;

/**
 * <p>Title: Beetleҵ���߼����</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: �׿ǳ�����</p>
 *
 * @author ��ƶ���yuhaodong@gmail.com��
 * @version 1.0
 */
public class EJB3CommandTarget
    implements ICommandTarget {
  public CommandImp executeCommand(CommandImp command) throws
      CommandExecuteException {
    try {
      ICommand cmd = (ICommand) AppContext.getContainerContext().lookup(
          "CommandServerBean3/Remote");
      return cmd.executeCommand(command);
    }
    catch (NamingException ex) {
      throw new CommandExecuteException(ex);
    }
  }
  public CommandImp executeCommandWithTransation(CommandImp command) throws
      CommandExecuteException {
    try {
      ICommand cmd = (ICommand) AppContext.getContainerContext().lookup(
          "CommandServerBean3/Remote");
      return cmd.executeCommandWithTransaction(command);
    }
    catch (NamingException ex) {
      throw new CommandExecuteException(ex);
    }
  }
}

<map version="0.9.0">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1287391028449" ID="ID_5779914" MODIFIED="1287391266556" TEXT="BJAF1.4.1&#x7248;&#x672c;">
<icon BUILTIN="gohome"/>
<node CREATED="1287392380298" ID="ID_152076067" MODIFIED="1287460144358" POSITION="left" TEXT="AppSrv">
<icon BUILTIN="flag-black"/>
<node CREATED="1287391622583" ID="ID_833986308" MODIFIED="1287392370689" TEXT="appsrv&#x5305;AppRunnable/AppThreadImp&#x9ed8;&#x8ba4;&#x521b;&#x5efa;&#x7ebf;&#x7a0b;&#x540d;&#x79f0;&#x6307;&#x5b9a;&#x4e3a;&#x6846;&#x67b6;&#x6807;&#x8bc6;&#x540d;&#x79f0;">
<icon BUILTIN="full-1"/>
</node>
<node CREATED="1287460161982" ID="ID_978858957" MODIFIED="1287460199928" TEXT="remoting&#x5b50;&#x5305;&#x540c;&#x6b65;&#x9501;&#x673a;&#x5236;&#x4f18;&#x5316;">
<icon BUILTIN="full-2"/>
</node>
<node CREATED="1287553281236" ID="ID_237540284" MODIFIED="1287553355279" TEXT="MessageServer&#x5b9e;&#x73b0;&#x591a;Selector&#x5904;&#x7406;&#x673a;&#x5236;">
<icon BUILTIN="full-3"/>
</node>
</node>
</node>
</map>

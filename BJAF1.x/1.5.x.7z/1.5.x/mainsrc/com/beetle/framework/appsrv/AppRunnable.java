/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv;

import java.util.concurrent.atomic.AtomicLong;

import com.beetle.framework.AppRuntimeException;

/**
 * <p>
 * Title: FrameWork
 * </p>
 * 
 * <p>
 * Description: 线程接口封装类
 * 
 * </p>
 * 
 * <p>
 * AppRunnable有两个基本属性，theadName线程名称，是这个线程的标识。maxIdle最大空闲时间，单位为毫秒，
 * 
 * 如果线程超过这个最大空闲时间还是处于阻塞状态的话，监控线程回自动停止这个线程，并重新拉起此线程。这个模型的基本运行流程为： <br>
 * （1），设置最大空闲时间，创建一个线程对象。 <br>
 * （2），调用startNow()方法启动线程，自动调用run()方法完成业务逻辑。 <br>
 * （3），线程运行期间，AppThreadMonitor检查线程阻塞情况，判别是否线程已经停止或超出最大空闲时间。<br>
 * （4），调用stopNow()方法结束线程的执行，结束前，触发stopEvent()事件。<br>
 * </p>
 * 此类作为一个线程框架抽象的基础类，除非特殊需求，否则不推荐直接继承使用， 建议使用AppThreadImp抽象类
 * 
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * 
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */
public abstract class AppRunnable implements Runnable {
	/**
	 * 获取线程启动时间（固定）
	 */
	public long getStartTime() {
		return iStartTime;
	}

	/**
	 * 获取此线程最近一次工作时间
	 */
	public long getLastTime() {
		return iLastTime;
	}

	private volatile boolean bStop;

	private transient Thread thread; // 线程
	private long iStartTime;// 线程启动时间
	private long iLastTime; // 最新时间
	static final AtomicLong couter = new AtomicLong(0);
	private String sThreadName; // 线程名称

	private long iMaxIdle; // 最大空闲时间

	public AppRunnable() {
		bStop = true;
		thread = null;
		iLastTime = 0L;
		iMaxIdle = 0;
		sThreadName = "BJAF-TAR-" + couter.incrementAndGet();
	}

	/**
	 * AppRunnable
	 * 
	 * @param maxIdle
	 *            最大空闲时间，单位为毫秒
	 */
	public AppRunnable(long maxIdle) {
		this();
		setMaxIdle(maxIdle);
	}

	/**
	 * AppRunnable
	 * 
	 * @param threadName
	 *            线程名称
	 */
	public AppRunnable(String threadName) {
		bStop = true;
		thread = null;
		iLastTime = 0L;
		iMaxIdle = 0;
		sThreadName = threadName;
	}

	/**
	 * AppRunnable
	 * 
	 * @param threadName
	 *            线程名称
	 * @param MaixIdle
	 *            最大空闲时间，单位为秒
	 */
	public AppRunnable(String threadName, long maxIdle) {
		this(threadName);
		setMaxIdle(maxIdle);
	}

	/**
	 * 设置最大空闲时间，单位为秒
	 * 
	 * @param i
	 *            int
	 */
	void setMaxIdle(long i) {
		iMaxIdle = i;
	}

	/**
	 * 返回线程的名称
	 * 
	 * 
	 * @return String
	 */
	public String getName() {
		return sThreadName;
	}

	boolean interrupted() {
		return Thread.interrupted();
	}

	long getMaxIdleTime() {
		return iMaxIdle;
	}

	/**
	 * 检测当前线程是否已经结束 若run方法调用isStopped来作为检查一个循环接受标记，
	 * 要在run方法体内显性调用resetIdleTime方法来每次复位时间
	 * 
	 * 
	 * @return 返回true为已经结束
	 */
	public boolean isStoped() {
		if (thread == null) {
			return true;
		}
		if (getIdleTime2() > getMaxIdleTime()) {
			return true;
		}
		if (getStopFlag()) {
			return true;
		}
		return false;
	}

	/**
	 * 启动线程 多次启动一个线程是非法的。特别是当线程已经结束执行后，不能再重新启动。
	 * 
	 * 
	 * @return 成功返回true
	 */
	public boolean startNow() {
		bStop = false;
		thread = new Thread(this, this.getName());
		thread.start();
		iLastTime = System.currentTimeMillis();
		iStartTime = iLastTime;
		return true;
	}

	/**
	 * 作为守护线程来启动 多次启动一个线程是非法的。特别是当线程已经结束执行后，不能再重新启动。
	 * 
	 * 
	 * @return
	 */
	public boolean startAsDaemon() {
		bStop = false;
		thread = new Thread(this, this.getName());
		thread.setDaemon(true);
		thread.start();
		iLastTime = System.currentTimeMillis();
		iStartTime = iLastTime;
		return true;
	}

	/**
	 * 返回当前已空闲的时间（线程已运行的时间ms）
	 * 
	 * 
	 * @return
	 */
	long getIdleTime2() {
		long l = (System.currentTimeMillis() - iLastTime);
		return l;
	}

	/**
	 * 重置空闲时间，重置后通过getIdleTime()获取的空闲时间为0
	 */
	public void resetIdleTime() {
		iLastTime = System.currentTimeMillis();
	}

	/**
	 * 调用stopNow触发的事件
	 */
	protected void stopEvent() {
	}

	/**
	 * 停止线程
	 */
	public void stopNow() {
		try {
			stopEvent();
		} finally {
			stopByFlag();
		}
	}

	/**
	 * 线程休眠
	 * 
	 * @param iTime
	 *            休眠时间，单位为毫秒
	 */
	public void sleep(long iTime) {
		if (thread == null) {
			return;
		}
		if (iTime < 0) {
			return;
		}
		try {
			Thread.sleep(iTime);
		} catch (InterruptedException e) {
			throw new AppRuntimeException(this.getName() + ",sleep err", e);
		}

	}

	/**
	 * 返回当前线程对象
	 * 
	 * @return Thread
	 */
	public Thread getThread() {
		if (thread == null) {
			return Thread.currentThread();
		} else {
			return thread;
		}
	}

	/**
	 * 返回当前结束标记状态
	 * 
	 * 
	 * @return boolean
	 */
	protected boolean getStopFlag() {
		return bStop;
	}

	/**
	 * 通过标记结束线程，但不触发end事件
	 */
	private void stopByFlag() {
		bStop = true;
	}

	/**
	 * 粗暴地停止此线程 终止之前先调用stopNow
	 */
	public void stopBrutally() {
		try {
			this.stopNow();
			this.interrupt();
			kill();
		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	/**
	 * @deprecated
	 */
	private void kill() {
		getThread().stop();
	}

	/**
	 * 中断线程
	 */
	public void interrupt() {
		getThread().interrupt();
	}

	/**
	 * 线程运行主方法
	 */
	public abstract void run();

}

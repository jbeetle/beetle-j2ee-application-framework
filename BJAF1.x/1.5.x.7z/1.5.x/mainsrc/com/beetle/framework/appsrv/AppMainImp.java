/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

import com.beetle.framework.log.SysLogger;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * 
 * <p>
 * Description: 服务器主程序抽象类 <br>
 * \u2022启动命令参数监听服务startCmdService()，在主程序中只有启动此服务，应用服务器才能具备参数的处理功能。
 * 
 * 如果一个应用服务器不需求命令参数，则可以不调用startCmdService()方法。 <br>
 * \u2022定义dealInputParameterCmd(cmd:String)抽象方法。所有参数命令的响应处理，都在这个方法里面实现。
 * 
 * 如果你的应用具备了参数命令管理功能，则你需要实现这个方法。 <br>
 * \u2022参数命令发送，sendParameterCmd(cmd:String)方法。你需要向服务器发送命令指令，调用此方法来实现。 <br>
 * \u2022启动后台线程监控服务startThreadMonitor()。只有启动了此服务，应用服务器才能实时监控各个功能子模块的运行情况。
 * 
 * 如果无需监控服务，则不必启动。 <br>
 * \u2022指定监控线程，monitorOneThread(threadImp:AppThreadImp)方法。利用这个方法，
 * 可以指定那个功能子模块需要被监控。 <br>
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */
public abstract class AppMainImp {
	private static SysLogger logger = SysLogger.getInstance();

	private CmdListener cmdService;
	private MainCoreService mcs;
	private AppMemoryWatcher amw;
	// private AppThreadMonitor monitor; //=AppThreadMonitor;
	private boolean monitorFlag = false;
	private boolean watcherFlag = false;
	private boolean cmdServiceFlag = false;

	private int cmdSerivicePort = 22476;

	final public void startMemoryWatcherService() {
		if (!watcherFlag) {
			amw = new AppMemoryWatcher(3000);
			amw.startNow();
			logger.info(AppMainImp.class, "MemoryWatcherService started!");
			watcherFlag = true;
		}
	}

	public AppMainImp() {
		this.mcs = new MainCoreService();
	}

	/**
	 * MainAppImp
	 * 
	 * @param cmdSerivicePort
	 *            后台命令服务监控端口，默认为22476
	 */
	public AppMainImp(int cmdSrvPort) {
		this();
		cmdSerivicePort = cmdSrvPort;
	}

	/**
	 * 启动命令服务
	 */
	final public void startCmdService() {
		if (!cmdServiceFlag) {
			cmdService = new CmdListener(cmdSerivicePort);
			cmdService.startNow();
			logger.info(AppMainImp.class, "CmdService started!");
			cmdServiceFlag = true;
		}
	}

	/**
	 * 发送命令参数 (一般开启一个新的进程去完成这个工作)
	 * 
	 * @param cmd
	 *            命令字符串
	 */
	final public void executeCmd(String cmd) {
		CmdVisitor cmdVistitor = new CmdVisitor(cmdSerivicePort, cmd);
		cmdVistitor.startNow();
		try {
			Thread.sleep(2048);
		} catch (InterruptedException e) {
			logger.error(AppMainImp.class, e.getMessage(), e);
		} finally {
			cmdVistitor.stopNow();
			System.exit(0);
		}
	}

	/**
	 * 监控后台应用线程
	 * 
	 * @param threadImp
	 *            应用线程实现对象
	 */
	final public void monitoThread(AppThreadImp threadImp) {
		AppThreadMonitor.putIntoCache(threadImp);
		if (logger.isDebugEnabled()) {
			logger.debug(AppMainImp.class, "monitor:" + threadImp.getName());
		}
	}

	final public void unmonitorThread(AppThreadImp threadImp) {
		AppThreadMonitor.removeFromCache(threadImp);
		if (logger.isDebugEnabled()) {
			logger.debug(AppMainImp.class, "unmonitor:" + threadImp.getName());
		}
	}

	/**
	 * 启动后台线程监控服务
	 */
	final public void startThreadMonitorService() {
		if (!this.monitorFlag) {
			AppThreadMonitor.startMonitor();
			logger.info(AppMainImp.class, "ThreadMonitorService started!");
			this.monitorFlag = true;
		}
	}

	/**
	 * 处理输入命令的抽象方法
	 * 
	 * 
	 * @param cmd
	 *            命令字符串
	 */
	protected abstract void dealCmd(String cmd);

	/**
	 * 关闭服务器时候触发的事件
	 */
	protected abstract void shutDownServerEvent();

	/**
	 * 启动服务器时触发的事件
	 */
	protected abstract void starServertEvent();

	/**
	 * 启动此应用服务器 (CmdService\MemoryWatcherService\ThreadMonitorService不会启动)
	 */
	final public void startServer() {
		if (this.mcs == null) {
			this.mcs = new MainCoreService();
		}
		Runtime.getRuntime().addShutdownHook(new Thread() {
			public void run() {
				if (logger.isDebugEnabled()) {
					logger.debug("jvm hook work...");
				}
				shutdownBeforeDo();
				if (logger.isDebugEnabled()) {
					logger.debug("jvm hook done.");
				}
			}
		});
		this.starServertEvent();
		this.mcs.startNow();
		logger.info(AppMainImp.class, "Application Server started!");
	}

	/**
	 * 关闭此应用服务器
	 */
	final public void shutDownServer() {
		try {
			shutdownBeforeDo();
		} finally {
			System.exit(0);
		}
	}

	private static boolean shutdownBeforeDoFlag = false;

	private void shutdownBeforeDo() {
		if (!shutdownBeforeDoFlag) {
			logger.info(AppMainImp.class, "Application Server shutdown..");
			try {
				this.mcs.stopNow();
				Thread.sleep(2048);
			} catch (Exception e) {
				logger.error(AppMainImp.class, e.getMessage(), e);
			} finally {
				this.shutDownServerEvent();
				shutdownBeforeDoFlag = true;
			}
		}
	}

	private class MainCoreService extends AppRunnable {

		private static final long serialVersionUID = 1L;

		public MainCoreService() {
			super();
		}

		protected void stopEvent() {
			if (cmdServiceFlag) {
				cmdService.stopNow();
			}
			if (monitorFlag) {
				AppThreadMonitor.stopMonitor();
			}
			if (watcherFlag) {
				amw.stopNow();
			}
		}

		public void run() {
			while (!this.getStopFlag()) {
				if (cmdServiceFlag) {
					String cmd = cmdService.getRecievedParam();
					dealCmd(cmd);
				}
				sleep(1024);
			}
			if (logger.isDebugEnabled()) {
				logger.debug(MainCoreService.class,
						"application server stopped!");
			}
			this.stopNow();
		}
	}

	/**
	 * 命令监听器
	 * 
	 * 
	 */
	private static class CmdListener extends AppRunnable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private ServerSocket theServerSocket;
		private int port;
		private String recievedParam;

		public CmdListener(int port) {
			super();
			this.port = port;
			init();
		}

		private void init() {
			try {
				theServerSocket = new ServerSocket(port);
				logger.info(CmdListener.class,
						"CmdListener started and the port:" + port);
			} catch (Exception e) {
				logger.error(CmdListener.class, e.getMessage(), e);
			}
		}

		protected void stopEvent() {
			try {
				this.theServerSocket.close(); // 关闭ServerSocket
			} catch (Exception e) {
				logger.error(CmdListener.class, e.getMessage(), e);
			}
			logger.info(CmdListener.class, "stop the CmdListener");
		}

		final public void run() {
			try {
				while (this.getStopFlag() == false) {
					this.setRecievedParam(null);
					Socket theClientSocket = this.theServerSocket.accept();
					if (!theClientSocket.isClosed()) {
						BufferedReader reader = new BufferedReader(
								new InputStreamReader(
										theClientSocket.getInputStream()));
						while (true) {
							String aStr = reader.readLine();
							if (aStr != null) {
								logger.info(CmdListener.class, "parameter:"
										+ aStr);
								this.setRecievedParam(aStr);
							} else {
								break;
							}
						}
						if (!theClientSocket.isClosed()) {
							theClientSocket.close();
						}
					}
					sleep(1000);
				}
			} catch (Exception e) {
				logger.error(CmdListener.class, e.getMessage(), e);
			}
		}

		/**
		 * 获取收到的命令(参数)
		 * 
		 * @return String
		 */
		public String getRecievedParam() {
			return recievedParam;
		}

		private void setRecievedParam(String recievedParam) {
			this.recievedParam = recievedParam;
		}

	}

	/**
	 * 命令发送器
	 * 
	 */
	private static class CmdVisitor extends AppRunnable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int port;
		private Socket theSocket;
		private String cmdStr;

		public CmdVisitor(int port, String cmdStr) {
			this.port = port;
			this.cmdStr = cmdStr;
			init();
		}

		private void init() {
			try {
				theSocket = new Socket("127.0.0.1", this.port);
			} catch (Exception e) {
				logger.error(CmdVisitor.class, e.getMessage(), e);
			}
		}

		protected void stopEvent() {
			try {
				theSocket.close();
			} catch (Exception e) {
				logger.error(CmdVisitor.class, e.getMessage(), e);
			}
		}

		public void run() {
			try {
				OutputStream os = theSocket.getOutputStream();
				PrintWriter out = new PrintWriter(os);
				out.println(cmdStr);
				out.flush();
			} catch (Exception e) {
				logger.error(CmdVisitor.class,
						"Cmd Serivice not start,please check it!", e);
			}
		}
	}
}

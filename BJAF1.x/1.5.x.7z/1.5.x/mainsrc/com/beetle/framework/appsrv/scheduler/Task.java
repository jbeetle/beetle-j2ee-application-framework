/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.scheduler;

import java.util.Date;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

/**
 * <p>Title: BeetleSoft Framework</p>
 *
 * <p>Description: 应用任务（job）抽象类</p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东
 * @version 1.0
 */
public abstract class Task
    implements Job {
  private JobExecutionContext jobConetext;
  public Task() {}

  /**
   * 获取上一次被执行的时间
   *
   * @return Date
   */
  public Date getPreviousFireTime() {
    return jobConetext.getPreviousFireTime();
  }

  /**
   * 获取将被执行的时间
   *
   * @return Date
   */
  public Date getNextFireTime() {
    return jobConetext.getNextFireTime();
  }

  /**
   * The actual time the trigger fired. For instance the scheduled time may have been 10:00:00
   * but the actual fire time may have been 10:00:03 if the scheduler was too busy.
   *
   * @return Date
   */
  public Date getFireTime() {
    return jobConetext.getFireTime();
  }

  /**
   * doTask－－执行任务的抽象方法，在此方法内实现任务代码
   */
  public abstract void doTask();

  final public void execute(JobExecutionContext jobExecutionContext) throws
      JobExecutionException {
    this.jobConetext = jobExecutionContext;
    this.doTask();
  }

  public String getTaskName() {
    return this.jobConetext.getJobDetail().getName();
  }

}

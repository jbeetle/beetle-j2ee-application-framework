package com.beetle.framework.appsrv;

import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import com.beetle.framework.AppProperties;
import com.beetle.framework.log.SysLogger;

public class RoutinePool extends ThreadPoolExecutor {
	private final static SysLogger logger = SysLogger
			.getInstance(RoutinePool.class);
	static {
		if (!RoutineMonitor.isMonitorAlive()) {
			new RoutineMonitor(false).startAsDaemon();
		}
	}

	public static RoutinePool getCommonPool() {
		if (instance == null) {
			int pool_max = AppProperties.getAsInt("routinespool_POOL_MAX_SIZE",
					200);
			int pool_min = AppProperties.getAsInt("routinespool_POOL_MIN_SIZE",
					25);
			int pool_ide = AppProperties.getAsInt(
					"routinespool_IDLESSE_MINUTE", 5) * 1000 * 60;
			instance = new RoutinePool(pool_min, pool_max, pool_ide, true);
		}
		return instance;
	}

	static class RoutineMonitor extends AppRunnable {

		private static ConcurrentHashMap<String, SubRoutine> cache = new ConcurrentHashMap<String, SubRoutine>(
				1334);
		private volatile static boolean aliveFlag = false;
		private int poo_monitor_interval;

		public RoutineMonitor() {
			super();
			selfStopFlag = true;
			poo_monitor_interval = AppProperties.getAsInt(
					"routinespool_MONITOR_INTERVAL", 250);
		}

		public RoutineMonitor(boolean selfStopFlag) {
			super();
			this.selfStopFlag = selfStopFlag;
		}

		final static boolean isMonitorAlive() {
			return aliveFlag;
		}

		private boolean selfStopFlag;

		final static void removeFromCache(String threadName) {
			cache.remove(threadName);
		}

		final static void putRoutineIntoCache(SubRoutine sbr) {
			if (!cache.containsKey(sbr.getId())) {
				cache.put(sbr.getId(), sbr);
			}
		}

		protected void end() {
			cache.clear();
			aliveFlag = false;
		}

		public void run() {
			aliveFlag = true;
			while (!getStopFlag()) {
				if (!cache.isEmpty()) {
					checkDie();
				}
				this.sleep(poo_monitor_interval);
				// System.out.println(getPoo_monitor_interval());
				if (cache.isEmpty()) {
					if (selfStopFlag) {
						this.stopNow();
					}
				}
			}
		}

		private static void checkDie() {
			try {
				Set<?> kvs = cache.entrySet();
				Iterator<?> it = kvs.iterator();
				while (it.hasNext()) {
					Map.Entry kv = (Map.Entry) it.next();
					SubRoutine sr = (SubRoutine) kv.getValue();
					if (sr != null) {
						if (sr.isStopped()) {
							if (logger.isDebugEnabled()) {
								logger.debug("Thread:[" + sr.getId()
										+ "]normal stopped!");
							}
							sr = null;
							cache.remove(kv.getKey());
						} else {
							if (!sr.isOvertime()) {
								continue;
							} else {
								Thread trd = sr.getRunThisRoutineThread();
								if (trd != null) {
									try {
										trd.interrupt();
										logger.info("[" + sr.getId()
												+ "]is interrupted!--");
										sr.terminated();
									} finally {
										if (sr.isKillWhenTimeout()) {
											trd.stop();
											logger.info("[" + sr.getId()
													+ "]is killed!--");
										}
										trd = null;
										sr = null;
										cache.remove(kv.getKey());
									}
								}
							}
						}
					} else {
						cache.remove(kv.getKey());
					}
				}
			} catch (Throwable e) {
				logger.error("checkDie thread err", e);
			} finally {
				// logger.debug("...xxx..");
			}
		}

		/**
		 * 默认为true，则内存不存在监控子线程，则自动退出
		 * 
		 * 
		 * @param disableSelfStop
		 */
		public void disableSelfStop() {
			this.selfStopFlag = false;
		}

	}

	private volatile static RoutinePool instance = null;

	@Override
	protected void beforeExecute(Thread t, Runnable r) {
		SubRoutine sr = (SubRoutine) r;
		if (sr.isJoinMonFlag()) {
			sr.setRunThisThread(t);
		}
	}

	@Override
	protected void afterExecute(Runnable r, Throwable t) {

	}

	/**
	 * 在池中执行
	 * 
	 * 
	 * @param subRoutine
	 * @throws InterruptedException
	 */
	public boolean runInPool(SubRoutine subRoutine) {
		try {
			execute(subRoutine);
			return true;
		} catch (RejectedExecutionException e) {
			e.printStackTrace();
			return false;
		}
	}

	private static class DaemonThreadFactory implements ThreadFactory {
		static final AtomicInteger poolNumber = new AtomicInteger(1);
		final ThreadGroup group;
		final AtomicInteger threadNumber = new AtomicInteger(1);
		final String namePrefix;
		boolean isDaemonThread;

		private DaemonThreadFactory(boolean isDaemonThread) {
			SecurityManager s = System.getSecurityManager();
			group = (s != null) ? s.getThreadGroup() : Thread.currentThread()
					.getThreadGroup();
			this.isDaemonThread = isDaemonThread;
			if (isDaemonThread) {
				namePrefix = "routinePool-" + poolNumber.getAndIncrement()
						+ "-daemonThread-";
			} else {
				namePrefix = "routinePool-" + poolNumber.getAndIncrement()
						+ "-thread-";
			}
		}

		public Thread newThread(Runnable r) {
			Thread t = new Thread(group, r, namePrefix
					+ threadNumber.getAndIncrement(), 0);
			if (isDaemonThread) {
				t.setDaemon(true);
			} else {
				if (t.isDaemon()) {
					t.setDaemon(false);
				}
			}
			if (t.getPriority() != Thread.NORM_PRIORITY)
				t.setPriority(Thread.NORM_PRIORITY);
			return t;
		}
	}

	private RoutinePool(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, TimeUnit unit,
			BlockingQueue<Runnable> workQueue, ThreadFactory threadFactory,
			RejectedExecutionHandler handler) {
		super(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
				threadFactory, handler);
	}

	/**
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 * @param workQueue
	 * @param isDaemonThread
	 * @param handler
	 */
	public RoutinePool(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, BlockingQueue<Runnable> workQueue,
			boolean isDaemonThread, RejectedExecutionHandler handler) {
		this(corePoolSize, maximumPoolSize, keepAliveTime,
				TimeUnit.MILLISECONDS, workQueue, new DaemonThreadFactory(
						isDaemonThread), handler);
	}

	/**
	 * [采取SynchronousQueue，自己指定饱和策略]
	 * 
	 * @param corePoolSize
	 * @param maximumPoolSize
	 * @param keepAliveTime
	 *            --存活时间，单位ms
	 * @param isDaemonThread
	 * @param handler
	 */
	public RoutinePool(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, boolean isDaemonThread,
			RejectedExecutionHandler handler) {
		this(corePoolSize, maximumPoolSize, keepAliveTime,
				TimeUnit.MILLISECONDS, new SynchronousQueue<Runnable>(),
				new DaemonThreadFactory(isDaemonThread), handler);
	}

	/**
	 * 
	 * [采取AbortPolicy策略和SynchronousQueue队列]<br>
	 * 新请求到达频率超过线程池处理它们的速度时，新请求不会放入等待队列，直接拒绝<br>
	 * 抛RejectedExecutionException<br>
	 * 
	 * @param corePoolSize
	 *            --核心池大小
	 * @param maximumPoolSize
	 *            --池最大大小
	 * @param keepAliveTime
	 *            --池存活的时间，单位毫秒
	 * @param isDaemonThread
	 *            --true,线程池的线程都为daemon线程<br>
	 *            --false,线程池的线程都为非daemon线程
	 */
	public RoutinePool(int corePoolSize, int maximumPoolSize,
			long keepAliveTime, boolean isDaemonThread) {
		this(corePoolSize, maximumPoolSize, keepAliveTime,
				TimeUnit.MILLISECONDS, new SynchronousQueue<Runnable>(),
				new DaemonThreadFactory(isDaemonThread), new AbortPolicy());
	}

}

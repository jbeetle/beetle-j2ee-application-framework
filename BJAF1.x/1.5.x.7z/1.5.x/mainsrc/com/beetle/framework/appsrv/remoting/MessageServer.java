/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.remoting;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.appsrv.AppRunnable;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.AesEncrypt;
import com.beetle.framework.util.OtherUtil;
import com.beetle.framework.util.cache.ConcurrentCache;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;
import com.beetle.framework.util.queue.NoBlockQueue;

/**
 * 消息服务器
 * 
 * 
 */
public final class MessageServer {

	/**
	 * 封装所有服务器端需要编程的动作的抽象类
	 * 
	 */
	public static abstract class ServerAction {
		/**
		 * 交互执行方法
		 * 
		 * @param req
		 *            --请求消息
		 * @return--响应消息
		 * @throws AppRuntimeException交互异常
		 */
		public abstract MsgRes requestHandle(MsgReq req)
				throws MessageCommunicateException;

		/**
		 * 客户验证接口
		 * 
		 * @param username
		 * @param password
		 * @return--true验证通过；false验证失败
		 */
		public abstract boolean authenticate(String username, String password);

		/**
		 * 客户端断开在服务端触发的此事件 (连接中断)
		 * 
		 * @param sessionId
		 *            --客户端的会话id
		 * @param breakTypeFlag
		 *            --客户端中断类型标记，<br>
		 *            值"0"--客户端正常主动调用disconnect方法中断<br>
		 *            值"1"--客户端非正常中断，例如没有关闭连接突然退出jvm<br>
		 *            值"2"--服务主动中断，例如调用session的invalidate方法
		 * @throws MessageCommunicateException
		 */
		protected void connectionBreakEvent(String sessionId, int breakTypeFlag)
				throws MessageCommunicateException {
		}

		/**
		 * 在此服务器停止之前触发此事件
		 */
		protected void beforeStopServerEvent()
				throws MessageCommunicateException {
		}

		/**
		 * Session建立成功后触发此事件
		 * 
		 * @param sessionId
		 * @throws MessageCommunicateException
		 */
		protected void sessionCreatedEvent(String sessionId)
				throws MessageCommunicateException {
		}

		/**
		 * Session长时间没有会话，掉线之前（及系统自动回收此会话之前）触发此事件
		 * 
		 * 
		 * @param sessionId
		 * @throws MessageCommunicateException
		 */
		protected void sessionBeforeLoseEvent(String sessionId)
				throws MessageCommunicateException {
		}
	}

	/**
	 * 注册服务动作处理者
	 * 
	 * 
	 * @param exchange
	 */
	public void registerServerAction(ServerAction serverAction) {
		this.exchange = serverAction;
	}

	/**
	 * 设置连接校验超时时间，默认为5000毫秒
	 * 
	 * @param timeout
	 *            --单位毫秒ms
	 */
	public void setConnectionVerifyTimeout(long timeout) {
		if (timeout < 0) {
			timeout = 5000;
		}
		RequestSession.VERIFY_TIMEOUT = timeout;
	}

	private final static SysLogger logger = SysLogger
			.getInstance(MessageServer.class);

	/**
	 * 会话存活的时间，默认30分钟
	 * 
	 * @return
	 */
	public long getSessionLiveTime() {
		return sessionLiveTime;
	}

	/**
	 * 设置会话存活时间，不设置默认30分钟
	 * 
	 * @param sessionLiveTime
	 *            单位毫秒ms
	 */
	public void setSessionLiveTime(long sessionLiveTime) {
		this.sessionLiveTime = sessionLiveTime;
	}

	/**
	 * 设置扫描流数据的频率
	 * 
	 * @param time
	 *            --毫秒ms，默认为10ms
	 */
	public void scanStreamDataRate(long time) {
		PipedStream.setCheck_data_interval(time);
	}

	/**
	 * 服务器监听端口
	 * 
	 * 
	 * @return
	 */
	public int getPort() {
		return port;
	}

	private int port;
	private SelectorVO selectors[];
	private int selectorNumber = 0;

	/**
	 * 设置信道的selector的个数；性能调优参数，默认大小为操作系统所在机器的cpu核数， 但最大不超过8个。
	 * 此方法必须在start方法之前调用参数才会生效。
	 * 
	 * @param selectorNumber
	 */
	public void setSelectorNumber(int selectorNumber) {
		this.selectorNumber = selectorNumber;
	}

	private ServerSocketChannel serverChannel;
	// private final Object acceptLock = new Object();
	private EventHandler eventHandler;
	private ServerAction exchange;
	private AcceptWorker acceptWorker;
	private ReadWriteWorker[] readWriteWorkers;
	private SessionCheckWorker sessionCheckWorker;
	private long sessionLiveTime;// 会话存活时间

	private static class SelectorVO {

		public SelectorVO(Selector selector) {
			this.selector = selector;
			this.byteBuffer = ByteBuffer
					.allocateDirect(PipedStream.ByteBufferSize);
		}

		private Selector selector;
		private final Object lock = new Object();
		private final ByteBuffer byteBuffer;

		public ByteBuffer getByteBuffer() {
			return byteBuffer;
		}

		public Selector getSelector() {
			return selector;
		}

		public Object getLock() {
			return lock;
		}

		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((lock == null) ? 0 : lock.hashCode());
			return result;
		}

	}

	/**
	 * 服务器构造函数
	 * 
	 * 
	 * @param port
	 *            --监听端口
	 */
	public MessageServer(int port) {
		this.port = port;
		this.sessionLiveTime = 1000 * 60 * 30;
	}

	/**
	 * 获取请求会话集合缓存
	 * 
	 * @return ICache(key-SelectionKey,value-RequestSession)
	 */
	public ICache getRequestSessionCache() {
		return this.eventHandler.sessionCache;
	}

	/**
	 * 获取请求会话集合
	 * 
	 * @return
	 */
	public Collection getRequestSessionCollection() {
		return this.eventHandler.sessionCache.values();
	}

	/**
	 * 移除会话（如果存在的话）
	 * 
	 * @param sessionId
	 */
	public void removeRequestSession(String sessionId) {
		RequestSession session = getRequestSession(sessionId);
		if (session != null) {
			if (session.getKey() != null) {
				this.eventHandler.sessionCache.remove(session.getKey());
			}
			session.clearX();
		}
	}

	/**
	 * 根据sessionId获取请求会话
	 * 
	 * @param sessionId
	 * @return RequestSession
	 */
	public RequestSession getRequestSession(String sessionId) {
		ICache cc = getRequestSessionCache();
		if (cc.isEmpty()) {
			return null;
		}
		Set s = cc.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			RequestSession rs = (RequestSession) kv.getValue();
			if (rs != null) {
				if (rs.getSessionId().equals(sessionId)) {
					return rs;
				}
			}
		}
		return null;
	}

	private static class ResQueueConsumeWorker extends AppRunnable {
		private BlockQueue resQ;

		private static class PushRoutine extends SubRoutine {
			private RequestSession session;

			public PushRoutine(RequestSession session) {
				super();
				this.session = session;
			}

			protected void routine() throws InterruptedException {
				session.push();
			}

		}

		public ResQueueConsumeWorker(BlockQueue resQ) {
			super("ResQueueConsumeWorker");
			this.resQ = resQ;
		}

		public void run() {
			while (true) {
				RequestSession session = (RequestSession) resQ.pop();
				if (session.isValid()) {
					// session.push();
					PushRoutine pr = new PushRoutine(session);
					boolean f = RoutineExecutor.runRoutineInCommonPool(pr);
					if (!f) {
						if (pr != null) {
							pr.run();
							pr = null;
						}
						logger.warn("system common thread pool is full!");
					}
				}
			}
		}

	}

	private static class ReqQueueConsumeWorker extends AppRunnable {
		private BlockQueue reqQ;
		private ServerAction exchange;
		private EventHandler event;

		private static class ExchangeRoutine extends SubRoutine {
			private RequestSession request;
			private ServerAction exchange;
			private EventHandler event;

			public ExchangeRoutine(RequestSession request,
					ServerAction exchange, EventHandler event) {
				super();
				this.request = request;
				this.exchange = exchange;
				this.event = event;
			}

			protected void routine() throws InterruptedException {
				for (;;) {
					MsgReq mReq = request.getMsgReq();
					if (logger.isDebugEnabled()) {
						logger.debug("request info:");
						logger.debug(mReq);
						logger.debug("---------------");
					}
					if (mReq == null) {
						event.sessionCache.remove(request.getKey());
						request.clearX();
						break;
					}
					String mid = mReq.getMessageId();
					Header header = mReq.getHeader();
					String callmethod = null;
					if (header != null) {
						callmethod = header.getMethod();
					}
					MsgRes mRes = null;
					if (request.getVerifyTime() == 0) {
						if (header != null && header.getPassword() != null) {
							String sessionId = header.getSessionId();
							mRes = new MsgRes();
							mRes.setMessageId(mid);
							String pwd = AesEncrypt.decrypt(header
									.getPassword());
							if (exchange.authenticate(header.getUser(), pwd)) {
								mRes.setReturnFlag(0);
								mRes.setReturnMsg("authenticate ok!");
								request.setLoginOk(true);
								request.setSessionId(header.getSessionId());
								request.setUser(header.getUser());
								request.setLastTime(System.currentTimeMillis());
								request.setVerifyTime(request.getLastTime());
								// header.setMethod(Header.METHOD_INVOKE);
								header.setMethod(Header.METHOD_SEND);
								mRes.setHeader(header);
								request.write(mRes);
								try {
									exchange.sessionCreatedEvent(sessionId);// 注册事件
								} catch (MessageCommunicateException e) {
									e.printStackTrace();
								}
								if (request.notifyRequestDone()) {
									break;
								}
							} else {
								request.setVerifyTime(0);
								mRes.setReturnFlag(-1);
								mRes.setReturnMsg("authenticate failed!");
								header.setMethod(Header.METHOD_SEND);
								mRes.setHeader(header);
								request.write(mRes);
								sleep(50);
								event.sessionCache.remove(request.getKey());
								request.clearX();
								// removeRequestSession(header.getSessionId());
								break;
							}
							return;
						}
					}
					try {
						mRes = exchange.requestHandle(mReq);
					} catch (Throwable e) {
						if (mRes != null) {
							mRes.clear();
						} else {
							mRes = new MsgRes();
						}
						mRes.setReturnFlag(-10000);
						mRes.setReturnMsg(logger.getStackTraceInfo(e));
						logger.error("exchange err", e);
					} finally {
						if (mReq != null) {
							mReq.clear();
							mReq = null;
						}
						if (mRes != null && !mRes.isEmpty()) {
							mRes.setMessageId(mid);// 设置mid标识请求响应结果
							if (header != null) {
								header.clear();
								header = null;
							}
							header = new Header();
							// header.setMethod(Header.METHOD_INVOKE);
							header.setMethod(callmethod);
							header.setSessionId(request.getSessionId());
							mRes.setHeader(header);
							if (logger.isDebugEnabled()) {
								logger.debug("out...");
								logger.debug(mRes);
							}
							request.write(mRes);
						}
						if (request.notifyRequestDone()) {
							break;
						}
					}
				}
			}

		}

		public ReqQueueConsumeWorker(BlockQueue reqQ, ServerAction exchange,
				EventHandler event) {
			super("ReqQueueConsumeWorker");
			this.reqQ = reqQ;
			this.exchange = exchange;
			this.event = event;
		}

		public void run() {
			while (true) {
				RequestSession request = (RequestSession) reqQ.pop();
				request.setLastTime(System.currentTimeMillis());// 记录最新访问时间
				ExchangeRoutine er = new ExchangeRoutine(request, exchange,
						event);
				boolean f = RoutineExecutor.runRoutineInCommonPool(er);
				if (!f) {
					if (er != null) {
						er.run();
						er = null;
					}
					logger.warn("system common thread pool is full!");
				}
				// request.clear();
			}
		}
	}

	/**
	 * 请求动作及状态会话（Session）的封装
	 * 
	 */
	public final static class RequestSession {

		private boolean loginOk;
		private SelectionKey key;
		// private PipedInputStream clientInputStream;
		private PipedStream pipedStream;
		// private OutputStream clientOut;
		private BlockQueue queue;// 进来的数据
		private BlockQueue pushQueue;// 出去的数据
		private boolean requestReady = false;
		// private MsgRes pushObj;// 推送会客户端的响应对象
		private final IQueue msgResQueue = new NoBlockQueue();// 推送到客户端的响应对象队列
		private long loginTime;// 登录时间（session创建时间）
		private final Object pushLock = new Object();
		private long verifyTime;// 验证时间
		private long lastTime;// 最近访问时间
		private ServerAction serverAction;
		private String user;
		static long VERIFY_TIMEOUT = 5000;// 验证失效时间

		RequestSession(SelectionKey readKey, BlockQueue q,
				BlockQueue pushQueue, ServerAction serverAction) {
			key = readKey;
			this.queue = q;
			this.pushQueue = pushQueue;
			this.loginTime = System.currentTimeMillis();
			this.verifyTime = 0;
			this.loginOk = false;
			this.serverAction = serverAction;
			// this.msgResQueue = new NoBlockQueue();
			initializePipe();
		}

		boolean isLoginOk() {
			return loginOk;
		}

		void setLoginOk(boolean loginOk) {
			this.loginOk = loginOk;
		}

		/**
		 * 获取Session的Id
		 * 
		 * @return
		 */
		public String getSessionId() {
			return sessionId;
		}

		void setSessionId(String sessionId) {
			this.sessionId = sessionId;
		}

		private String sessionId;// 会话id

		/**
		 * 获取用户名
		 * 
		 * 
		 * @return
		 */
		public String getUser() {
			return user;
		}

		void setUser(String user) {
			this.user = user;
		}

		/**
		 * 获取最新访问的时间
		 * 
		 * @return
		 */
		public long getLastTime() {
			return lastTime;
		}

		void setLastTime(long lastTime) {
			this.lastTime = lastTime;
		}

		/**
		 * 获取校验时间。若此Session没有通过合法校验，其值为0； 通过合法校验，其值为当时校验时间
		 * 
		 * @return
		 */
		public long getVerifyTime() {
			return verifyTime;
		}

		void setVerifyTime(long verifyTime) {
			this.verifyTime = verifyTime;
		}

		/**
		 * 获取登录时间
		 * 
		 * @return
		 */
		public long getLoginTime() {
			return loginTime;
		}

		/**
		 * 推送一个消息给客户端
		 * 
		 * 
		 * @param pushObj
		 */
		public void pushMessageToClient(MsgRes pushObj) {
			synchronized (pushLock) {
				if (pushObj != null) {
					Header header = new Header();
					header.setMethod(Header.METHOD_SEND);
					header.setSessionId(this.getSessionId());
					pushObj.setHeader(header);
					this.msgResQueue.push(pushObj);
					pushQueue.push(this);// 把自己放在发送队列中
				}
			}
		}

		/**
		 * 此Session是否可用
		 * 
		 * @return
		 */
		public boolean isValid() {
			if (key == null) {
				return false;
			}
			Socket s = ((SocketChannel) key.channel()).socket();
			if (s.isClosed()) {
				return false;
			}
			// ...
			return true;
		}

		/**
		 * 获取此Nio通道的Key
		 * 
		 * @return
		 */
		public SelectionKey getKey() {
			return key;
		}

		/**
		 * 获取客户端的地址
		 * 
		 * @return
		 */
		public String getClientAddress() {
			if (key != null) {
				Socket s = ((SocketChannel) key.channel()).socket();
				if (s != null) {
					return s.getInetAddress().getHostAddress();
				} else {
					return "unknown";
				}
			} else {
				return "unknown";
			}
		}

		MsgReq getMsgReq() {
			if (!isValid()) {
				return null;
			}
			InputStream is = this.pipedStream.getInputStream();
			if (is == null) {
				return null;
			}
			synchronized (is) {
				try {
					/*
					 * 此方法会导致正常流读数不正确 if (is.available() <= 0) { return null; }
					 */
					ObjectInputStream ois = new ObjectInputStream(is);
					Object obj = ois.readObject();
					return (MsgReq) obj;
				} catch (Exception e) {
					// closeInputStream(ois);
					logger.error("getMsgReq(),readObject err", e);
					// this.clear();
					return null;
				}
			}
		}

		/**
		 * 写入res响应对象，以便推送出去
		 * 
		 * 
		 * @param pushObj
		 */
		void push() {
			synchronized (msgResQueue) {
				if (!msgResQueue.isEmpty()) {
					while (true) {
						MsgRes pushObj = (MsgRes) msgResQueue.pop();
						if (pushObj == null) {
							break;
						}
						write(pushObj);
						if (pushObj != null) {
							pushObj.clear();
							pushObj = null;
						}
					}
				}
			}
		}

		void write(Map map) {
			if (!isValid()) {
				return;
			}
			if (map != null && !map.isEmpty()) {
				SocketChannel channel = (SocketChannel) key.channel();
				try {
					channel.write(ByteBuffer.wrap(OtherUtil.objToBytes(map)));
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					map.clear();
					map = null;
				}
			}
		}

		/**
		 * 作废此Session，也就是会话终止，连接及与其相关的内存资源回收<br>
		 * 会触发connectionBreakEvent事件
		 * 
		 * @throws MessageCommunicateException
		 */
		public void invalidate() throws MessageCommunicateException {
			try {
				clearX();
			} finally {
				serverAction.connectionBreakEvent(getSessionId(), 2);
			}
		}

		void clearX() {
			try {
				if (key != null) {
					// this.eventHandler.sessionCache.remove(key);
					key.cancel();
					SocketChannel sc = (SocketChannel) key.channel();
					sc.socket().close();
					// key.channel().close();
					sc.close();
				}
				closeOutputStream(this.pipedStream.getOutputStream());
				closeInputStream(this.pipedStream.getInputStream());
				if (!msgResQueue.isEmpty()) {
					while (true) {
						MsgRes pushObj = (MsgRes) msgResQueue.pop();
						if (pushObj == null) {
							break;
						}
						pushObj.clear();
						pushObj = null;
					}
				}
				this.msgResQueue.clear();
				this.pushQueue.clear();
				this.queue.clear();
			} catch (Exception e) {
				logger.error("request clear() err", e);
			} finally {
				key = null;
			}
		}

		private void initializePipe() {
			try {
				// PipedOutputStream pos = new PipedOutputStream();
				// clientInputStream = new PipedInputStream(pos);
				// clientOut = new BufferedOutputStream(pos, 1024);
				this.pipedStream = new PipedStream();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		void flushIntoPiped(byte[] data) throws IOException {
			OutputStream os = this.pipedStream.getOutputStream();
			synchronized (os) {
				os.write(data);
				os.flush();
				// clientOut.write(data);
				// clientOut.flush();
				if (!requestReady) {
					requestReady = true;
					queue.push(this);// 把自己放入请求对象
				}
			}
		}

		boolean notifyRequestDone() {
			try {
				InputStream is = this.pipedStream.getInputStream();
				synchronized (is) {
					if (is.available() <= 0) {
						requestReady = false;
					}
					return !requestReady;
				}
			} catch (IOException e) {
				return false;
			}
		}
	}

	/**
	 * 统一事件处理者, 所有请求及响应都由此处理建立的队列承担 [可视为处理nio通信的公共功能模块]
	 */
	private class EventHandler {

		private BlockQueue requestQueue;// 对所有的请求建立一个queue,[RequestSession]
		private BlockQueue responseQueue;// 为推送数据建立一个队列[RequestSession]

		private ICache sessionCache;// 建立一个session缓存器

		public void clear() {
			requestQueue.clear();
			responseQueue.clear();
			sessionCache.clear();
		}

		public EventHandler() throws IOException {
			requestQueue = new BlockQueue();
			responseQueue = new BlockQueue();
			sessionCache = new ConcurrentCache(1334);
			int processsorNum = Runtime.getRuntime().availableProcessors();
			PipedStream.startConsumerThread(processsorNum, true);
			for (int i = 0; i < processsorNum; i++) {//
				new ReqQueueConsumeWorker(requestQueue, exchange, this)
						.startAsDaemon();
			}
			for (int i = 0; i < processsorNum; i++) {//
				new ResQueueConsumeWorker(responseQueue).startAsDaemon();
			}
			logger.info("availableProcessors:" + processsorNum);
		}

		public void disconnectClient(SelectionKey key) {
			key.attach(null);
			try {
				SocketChannel sc = (SocketChannel) key.channel();
				logger.warn("client[" + sc.socket().getInetAddress()
						+ "]closed");
				sc.close();
				//
				sessionCache.remove(key);// 清空缓存
			} catch (IOException e) {
				logger.error(e);
			}
		}

		private int post = 0;

		private SelectorVO roundRobin() {
			synchronized (selectors) {
				SelectorVO svo = selectors[post];
				post++;
				if (post >= selectors.length) {
					post = 0;
				}
				return svo;
			}
		}

		public void connectClient() {
			SelectionKey rwKey = null;
			try {
				SocketChannel sc = serverChannel.accept();
				sc.configureBlocking(false);
				logger.info("accept from:" + sc.socket().getInetAddress() + ":"
						+ sc.socket().getPort());
				SelectorVO svo = roundRobin();
				synchronized (svo.getLock()) {
					Selector selector = svo.getSelector();
					selector.wakeup();
					// rwKey = sc.register(selector, SelectionKey.OP_READ
					// | SelectionKey.OP_WRITE);
					rwKey = sc.register(selector, SelectionKey.OP_READ);// 注册，只有当客户端有请求时才处理
					rwKey.attach(new RequestSession(rwKey, requestQueue,
							responseQueue, exchange));
					sessionCache.put(rwKey, rwKey.attachment());// 记录
					if (logger.isDebugEnabled()) {
						logger.debug("mark session ok!");
					}
				}
			} catch (Exception e) {
				if (rwKey != null) {
					disconnectClient(rwKey);
				}
				logger.error("accept a new client raise err,close client", e);
			}
		}

		public void writeDataToClient(SelectionKey key) throws IOException {
			RequestSession request = (RequestSession) key.attachment();
			request.push();
		}

		public void readDataFromClient(SelectionKey key, ByteBuffer byteBuffer)
				throws IOException {
			int count = ((SocketChannel) key.channel()).read(byteBuffer);
			try {
				if (count > 0) {// 有数据
					byteBuffer.flip();
					byte[] data = new byte[count];
					byteBuffer.get(data, 0, count);
					if (logger.isDebugEnabled()) {
						logger.debug("income data:" + count);
					}
					RequestSession rs = (RequestSession) key.attachment();
					if (rs != null && rs.isValid()) {
						rs.flushIntoPiped(data);// 数据 放入管道里面以便构建完整数据，并rs扔到输入队列
						if (logger.isDebugEnabled()) {
							logger.debug(key.attachment());
							logger.debug("income data ok");
						}
					}
				} else if (count == 0) {// 没数据
					// ..
				} else if (count < 0) {// client断了end-of-stream
					try {
						exchange.connectionBreakEvent(((RequestSession) key
								.attachment()).getSessionId(), 0);
						if (logger.isDebugEnabled()) {
							logger.debug("clientBreak event done[-2]");
						}
					} catch (Exception e) {
						logger.error(e);
					} finally {
						SocketChannel sc = (SocketChannel) key.channel();
						logger.warn("read() return <0,close["
								+ sc.socket().getInetAddress() + "]client");
						sc.close();
					}
				}
			} finally {
				byteBuffer.clear();
			}
		}
	}

	private class SessionCheckWorker extends AppRunnable {

		public SessionCheckWorker() {
			super("SessionCheckWorker");
		}

		public void run() {
			while (!this.getStopFlag()) {
				ICache sessionCache = getRequestSessionCache();
				Set s = sessionCache.entrySet();
				Iterator it = s.iterator();
				while (it.hasNext()) {
					Entry kv = (Entry) it.next();
					RequestSession rs = (RequestSession) kv.getValue();
					if (rs != null) {
						if (rs.getVerifyTime() == 0) {// 验证失败标记，失败后在预定时间内回收此连接
							long bk = System.currentTimeMillis()
									- rs.getLoginTime();
							if (bk >= RequestSession.VERIFY_TIMEOUT) {// 在预定的时间内都没有完成验证
								sessionCache.remove(kv.getKey());
								rs.clearX();// 结束这个会话
								if (logger.isDebugEnabled()) {
									logger.debug("kill unlaw connection!");
								}
								break;
							}
						}
						if (!rs.isValid()) {
							try {
								exchange.sessionBeforeLoseEvent(rs
										.getSessionId());// 注册session实现事件
							} catch (Exception e) {
								e.printStackTrace();
							} finally {
								sessionCache.remove(kv.getKey());
								rs.clearX();// 结束这个会话
								if (logger.isDebugEnabled()) {
									logger.debug("remove a invalid session");
								}
							}
							break;
						}
						if (rs.isLoginOk()) {// 成功登录才检查

							long cz = System.currentTimeMillis()
									- rs.getLastTime();
							// System.out.println(cz);
							// System.out.println(getSessionLiveTime());
							if (cz >= getSessionLiveTime()) {// 检查Session是否过期
								try {
									exchange.sessionBeforeLoseEvent(rs
											.getSessionId());// 注册session实现事件
								} catch (Exception e) {
									e.printStackTrace();
								} finally {
									sessionCache.remove(kv.getKey());
									rs.clearX();// 结束这个会话
									if (logger.isDebugEnabled()) {
										logger.debug("kill session");
									}
								}
								break;
							}
						}
					}
				}
				this.sleep(250);
			}
		}
	}

	/**
	 * 所有对所有的客户端的数据进行读和写的工作线程 （永远活着，除非服务死亡）
	 */
	private class ReadWriteWorker extends AppRunnable {
		private SelectorVO svo;

		public ReadWriteWorker(SelectorVO svo) {
			super("ReadWriteWorker");
			this.svo = svo;
		}

		public void run() {
			while (!this.getStopFlag()) {
				synchronized (svo.getLock()) {
					if (logger.isDebugEnabled()) {
						logger.debug("ReadWriteWorker-->begin");
					}
				}
				dealit();
				if (logger.isDebugEnabled()) {
					logger.debug("ReadWriteWorker--end");
				}
			}
		}

		private void dealit() {
			Selector selector = svo.getSelector();
			SelectionKey key = null;
			try {
				int n = selector.select();// ????
				if (n > 0) {
					Set keys = selector.selectedKeys();
					Iterator it = keys.iterator();
					while (it.hasNext()) {
						key = (SelectionKey) it.next();
						it.remove();
						if (key.isReadable()) {
							eventHandler.readDataFromClient(key,
									svo.getByteBuffer());// 待优化？采取另外线程去处理，是否在高并发下性能好点？
						} else if (key.isWritable()) {// 没有注册，应该不会触发，保留
							eventHandler.writeDataToClient(key);
						} else {
							if (logger.isDebugEnabled()) {
								logger.debug("ReadWriteWorker other.....");
							}
						}
					}
				}
			} catch (Throwable e) {// client断了
				logger.warn(
						"ReadWriteWorker dealit() method raise err,and deal this exception",
						e);
				if (key != null) {
					// 处理断开事件
					try {
						RequestSession rs = (RequestSession) key.attachment();
						if (rs != null) {
							String sessionid = rs.getSessionId();
							if (sessionid != null) {
								exchange.connectionBreakEvent(sessionid, 1);
								if (logger.isDebugEnabled()) {
									logger.debug("clientBreak event done["
											+ sessionid + "]-1");
								}
							}
							eventHandler.sessionCache.remove(key);
							rs.clearX();
						}
					} catch (Exception mce) {
						logger.error("client break err", mce);
					} finally {
						if (key != null) {
							key.cancel();
							eventHandler.disconnectClient(key);
						}
					}
				}
			}
		}
	}

	private class AcceptWorker extends AppRunnable {

		public AcceptWorker() {
			super("AcceptWorker");
		}

		public void run() {
			while (!this.getStopFlag()) {
				eventHandler.connectClient();
			}
		}

	}

	private void init() {
		try {
			if (this.eventHandler == null) {
				this.eventHandler = new EventHandler();// 消费队列线程数量
			}
			serverChannel = ServerSocketChannel.open();
			if (selectorNumber <= 0) {
				selectorNumber = Runtime.getRuntime().availableProcessors();
				if (selectorNumber > 8) {// 太多反而浪费资源
					selectorNumber = 8;
				}
			}
			selectors = new SelectorVO[selectorNumber];
			for (int i = 0; i < selectors.length; i++) {
				selectors[i] = new SelectorVO(Selector.open());
			}
			serverChannel.socket().bind(new InetSocketAddress(port));
			// 采取阻塞方式监听
			// serverChannel.configureBlocking(false);
			// serverChannel.register(selector, SelectionKey.OP_ACCEPT);
			this.acceptWorker = new AcceptWorker();
			acceptWorker.startNow();// 启动后台请求接受线程
			readWriteWorkers = new ReadWriteWorker[selectorNumber];
			for (int i = 0; i < readWriteWorkers.length; i++) {
				readWriteWorkers[i] = new ReadWriteWorker(selectors[i]);
				readWriteWorkers[i].startNow();// 启动后台读写线程
			}
			sessionCheckWorker = new SessionCheckWorker();
			sessionCheckWorker.startNow();
			logger.info("MessageServer Listen port:" + this.port);
			logger.info("MessageServer start OK!");
		} catch (IOException e) {
			logger.error(e);
			throw new AppRuntimeException("can't create the MessageServer", e);
		}
	}

	/**
	 * 关闭此服务器
	 */
	public void stop() {
		try {
			exchange.beforeStopServerEvent();
			this.acceptWorker.stopNow();
			for (int i = 0; i < readWriteWorkers.length; i++) {
				readWriteWorkers[i].stopNow();
			}
			this.sessionCheckWorker.stopNow();
			// Thread.sleep(5000);
			ICache cahce = getRequestSessionCache();
			Set s = cahce.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
				Entry kv = (Entry) it.next();
				RequestSession rs = (RequestSession) kv.getValue();
				removeRequestSession(rs.getSessionId());
			}
			this.eventHandler.clear();
			for (int i = 0; i < selectors.length; i++) {
				Selector selector = selectors[i].getSelector();
				selector.wakeup();
				selector.close();
			}
			serverChannel.close();
			PipedStream.stopConsumerThread();
			logger.info("MessageServer stopped!");
		} catch (Exception e) {
			logger.error(e);
		}
	}

	private static void closeOutputStream(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			os = null;
		}
	}

	private static void closeInputStream(InputStream is) {
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			is = null;
		}
	}

	/**
	 * 启动此服务器(对于一个服务器，建议只Start一次，多次start会有不确定性)
	 */
	public void start() {
		if (this.exchange == null) {
			throw new AppRuntimeException(
					"register exchange first befor start the server!");
		}
		init();
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv;

import com.beetle.framework.appsrv.AppThreadMonitor.MonitorInfo;
import com.beetle.framework.util.OtherUtil;

/**
 * <p>
 * Title: FrameWork
 * </p>
 * <p>
 * Description: 应用线程抽象类[ 注意： 对于参与后台监控的应用线程，要保留构造函数，不能在现有构造函数的基础上 新添加构造参数。]
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */

public abstract class AppThreadImp extends AppRunnable {

	public boolean startNow() {
		boolean f = super.startNow();
		if (mInfo != null) {
			mInfo.setStartTime(this.getStartTime());
		}
		return f;
	}

	public void stopNow() {
		try {
			this.interrupt();
		} finally {
			super.stopNow();
		}
	}

	private MonitorInfo mInfo = null;
	private long interval;
	public static final int AUTO_CYCLE = 0;
	public static final int MANUAL_CYCLE = 1;
	private int cycleFlag = AUTO_CYCLE;

	/**
	 * AppThreadImp
	 * 
	 * @param threadName
	 *            线程名称
	 * @param MaixIdle
	 *            最大空闲时间，单位为ms毫秒， 超过此空闲时间，系统后台监控线程会认为线程已经瘫痪，此时会 先杀死它，然后再拉起它
	 *            必须在start此线程之前，显示调用joinThreadMonitor方法才有效
	 * @param interval
	 *            运行间隔时间，单位为ms毫秒
	 */
	public AppThreadImp(String threadName, long MaixIdle, long interval) {
		super(threadName, MaixIdle);
		this.interval = interval;
	}

	/**
	 * @param MaixIdle
	 *            最大空闲时间，单位为毫秒， 超过此空闲时间，系统后台监控线程会认为线程已经瘫痪，此时会 先杀死它，然后再拉起它
	 *            必须在start此线程之前，显示调用joinThreadMonitor方法才有效
	 * @param interval
	 *            运行间隔时间，单位为毫秒
	 */
	public AppThreadImp(long MaixIdle, long interval) {
		this("BJAF-TATI-" + couter.incrementAndGet(), MaixIdle, interval);
	}

	/**
	 * 此构造方法 threadName为随机生成 MaixIdle为30秒 若要参与线程监控，
	 * 必须在start此线程之前，显示调用joinThreadMonitor方法才有效
	 * 
	 * @param interval
	 *            --单位为毫秒
	 */
	public AppThreadImp(long interval) {
		this("BJAF-TATI-" + couter.incrementAndGet(), 30 * 1000, interval);
	}

	/**
	 * 此构造方法 threadName为随机生成 MaixIdle为30秒 若要参与线程监控，
	 * 必须在start此线程之前，显示调用joinThreadMonitor方法才有效
	 * 
	 * @param threadName
	 *            --线程名称
	 * @param interval
	 *            --执行间隔,单位为ms毫秒
	 */
	public AppThreadImp(String threadName, long interval) {
		this(threadName, 30 * 1000, interval);
	}

	/**
	 * <pre>
	 * 此构造方法 threadName为随机生成 MaixIdle为30秒,interval为0
	 * 若要参与线程监控，必须在start此线程之前，显示调用joinThreadMonitor方法才有效;
	 * </pre>
	 */
	public AppThreadImp() {
		this("BJAF-TATI-" + couter.incrementAndGet(), 30 * 1000, 0);
	}

	/**
	 * MaixIdle为30秒,interval为0
	 * 若要参与线程监控，必须在start此线程之前，显示调用joinThreadMonitor方法才有效;
	 * 
	 * @param threadName
	 *            --线程名称
	 */
	public AppThreadImp(String threadName) {
		this(threadName, 30 * 1000, 0);
	}

	/**
	 * 加入监控器受监控（加入监控器后，线程自身的生命周期由监控器管理， 此时再调用线程自身相关方法，其作用具备不确定性）
	 */
	public void joinThreadMonitor() {
		mInfo = new MonitorInfo();
		mInfo.setId(this.getName());
		// mInfo.setStartTime(startTime)
		mInfo.setStatus(MonitorInfo.READY_STATUS);
		AppThreadMonitor.addMonitorInfoIntoCache(mInfo.getId(), mInfo);
		if (!AppThreadMonitor.isStarted()) {
			AppThreadMonitor.startMonitor();
		}
		AppThreadMonitor.putIntoCache(this);
	}

	/**
	 * 撤销监控
	 */
	public void separateThreadMonitor() {
		AppThreadMonitor.removeFromCache(this);
	}

	final public void run() {
		if (this.cycleFlag == MANUAL_CYCLE) { // 自己手动控制循环
			this.resetIdleTime();
			try {
				workProc();
				markMInfoRunning();
			} finally {
				end();
			}
		} else {
			try {
				while (!interrupted() && !getStopFlag()) { // 根据执行标记还决定线程的持续运行
					this.resetIdleTime(); // 复位当然线程时间，为后台监控线程提供计算标准
					workProc(); // 执行业务逻辑方法
					markMInfoRunning();
					if (interval > 0) {
						this.sleep(interval); // 可以根据需要让线程休眠一段时间，让cpu更合理的分配任务
					}
				}
				this.setMaxIdle(-1);// 标明调用stopNow方法已经结束，从通过isStopped反应
			} finally {
				end();
			}
		}
	}

	private void markMInfoRunning() {
		if (mInfo != null) {
			mInfo.setLastTime(this.getLastTime());
			mInfo.setStatus(MonitorInfo.RUNNING_STATUS);
		}
	}

	/**
	 * 线程结束事件
	 */
	protected void end() {
		if (mInfo != null) {
			mInfo.setStatus(MonitorInfo.STOPPED_STATUS);
		}
	}

	/**
	 * 工作过程，只需实现业务逻辑，无需考虑线程后台循环执行逻辑
	 */
	protected abstract void workProc();

	/**
	 * 设置此线程执行间隔时间
	 * 
	 * 
	 * @param interval
	 *            单位为毫秒
	 */
	public void setInterval(long interval) {
		this.interval = interval;
	}

	/**
	 * 根据输入最小值和最大值算出随机数。
	 * 
	 * @param min
	 * @param max
	 */
	public void randomInterval(int min, int max) {
		this.setInterval(OtherUtil.randomInt(min, max));
	}

	/**
	 * 设置循环标记，默认为框架自动维护执行的循环。 public static final int AUTO_CYCLE = 0--自动循环
	 * public static final int MANUAL_CYCLE = 1--手动自己维护循环;
	 * 
	 * 
	 * @param manualCycleFlag
	 *            int
	 */
	public void setCycleFlag(int cycleFlag) {
		this.cycleFlag = cycleFlag;
	}

	/**
	 * 返回运行间隔，单位毫秒
	 * 
	 * 
	 * @return
	 */
	public long getInterval() {
		return interval;
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.scheduler;

import java.text.ParseException;

import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.SimpleTrigger;
import org.quartz.Trigger;
import org.quartz.TriggerUtils;
import org.quartz.impl.StdSchedulerFactory;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.util.UUIDGenerator;

/**
 * <p>Title: BeetleSoft Framework</p>
 *
 * <p>Description: 系统任务(job)计划器类</p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东
 * @version 1.0
 */
final public class TaskScheduler {
  private Scheduler theScheduler;
  private static TaskScheduler instance = null;
  private TaskScheduler() {
    SchedulerFactory sf = new StdSchedulerFactory();
    try {
      this.theScheduler = sf.getScheduler();
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 暂停某个计划任务
   *
   * @param taskName 任务名称
   */
  public void pauseTask(String taskName) {
    try {
      this.theScheduler.pauseJob(taskName, Scheduler.DEFAULT_GROUP);
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * 删除一个计划任务
   *
   * @param taskName 任务名称
   */
  public void deleteTask(String taskName) {
    try {
      this.theScheduler.deleteJob(taskName, Scheduler.DEFAULT_GROUP);
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * 恢复某个计划任务
   *
   * @param taskName 任务名称
   */
  public void resumeTask(String taskName) {
    try {
      this.theScheduler.resumeJob(taskName, Scheduler.DEFAULT_GROUP);
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * 计划一个任务
   *
   * @param appTaskClass AppTask类
   * @param taskName 任务名称
   * @param timeExpression 计划时间表达式<pre>
   * A "Time-Expression" is a string comprised of 6 or 7 fields separated by white space. The 6 mandatory and 1 optional fields are as follows:
   Field Name   Allowed Values   Allowed Special Characters
   Seconds    0-59    , - * /
   Minutes    0-59    , - * /
   Hours    0-23    , - * /
   Day-of-month    1-31    , - * ? / L W C
   Month    1-12 or JAN-DEC    , - * /
   Day-of-Week    1-7 or SUN-SAT    , - * ? / L C #
   Year (Optional)    empty, 1970-2099    , - * /
   The '*' character is used to specify all values. For example, "*" in the minute field means "every minute".
   The '?' character is allowed for the day-of-month and day-of-week fields. It is used to specify 'no specific value'. This is useful when you need to specify something in one of the two fileds, but not the other. See the examples below for clarification.
   The '-' character is used to specify ranges For example "10-12" in the hour field means "the hours 10, 11 and 12".
   The ',' character is used to specify additional values. For example "MON,WED,FRI" in the day-of-week field means "the days Monday, Wednesday, and Friday".
   The '/' character is used to specify increments. For example "0/15" in the seconds field means "the seconds 0, 15, 30, and 45". And "5/15" in the seconds field means "the seconds 5, 20, 35, and 50". Specifying '*' before the '/' is equivalent to specifying 0 is the value to start with. Essentially, for each field in the expression, there is a set of numbers that can be turned on or off. For seconds and minutes, the numbers range from 0 to 59. For hours 0 to 23, for days of the month 0 to 31, and for months 1 to 12. The "/" character simply helps you turn on every "nth" value in the given set. Thus "7/6" in the month field only turns on month "7", it does NOT mean every 6th month, please note that subtlety.
   The 'L' character is allowed for the day-of-month and day-of-week fields. This character is short-hand for "last", but it has different meaning in each of the two fields. For example, the value "L" in the day-of-month field means "the last day of the month" - day 31 for January, day 28 for February on non-leap years. If used in the day-of-week field by itself, it simply means "7" or "SAT". But if used in the day-of-week field after another value, it means "the last xxx day of the month" - for example "6L" means "the last friday of the month". When using the 'L' option, it is important not to specify lists, or ranges of values, as you'll get confusing results.
   The 'W' character is allowed for the day-of-month field. This character is used to specify the weekday (Monday-Friday) nearest the given day. As an example, if you were to specify "15W" as the value for the day-of-month field, the meaning is: "the nearest weekday to the 15th of the month". So if the 15th is a Saturday, the trigger will fire on Friday the 14th. If the 15th is a Sunday, the trigger will fire on Monday the 16th. If the 15th is a Tuesday, then it will fire on Tuesday the 15th. However if you specify "1W" as the value for day-of-month, and the 1st is a Saturday, the trigger will fire on Monday the 3rd, as it will not 'jump' over the boundary of a month's days. The 'W' character can only be specified when the day-of-month is a single day, not a range or list of days.
   The 'L' and 'W' characters can also be combined for the day-of-month expression to yield 'LW', which translates to "last weekday of the month".
   The '#' character is allowed for the day-of-week field. This character is used to specify "the nth" XXX day of the month. For example, the value of "6#3" in the day-of-week field means the third Friday of the month (day 6 = Friday and "#3" = the 3rd one in the month). Other examples: "2#1" = the first Monday of the month and "4#5" = the fifth Wednesday of the month. Note that if you specify "#5" and there is not 5 of the given day-of-week in the month, then no firing will occur that month.
   The 'C' character is allowed for the day-of-month and day-of-week fields. This character is short-hand for "calendar". This means values are calculated against the associated calendar, if any. If no calendar is associated, then it is equivalent to having an all-inclusive calendar. A value of "5C" in the day-of-month field means "the first day included by the calendar on or after the 5th". A value of "1C" in the day-of-week field means "the first day included by the calendar on or after sunday".
   The legal characters and the names of months and days of the week are not case sensitive.
   Here are some full examples:
   Expression   Meaning
   "0 0 12 * * ?"    Fire at 12pm (noon) every day
   "0 15 10 ? * *"    Fire at 10:15am every day
   "0 15 10 * * ?"    Fire at 10:15am every day
   "0 15 10 * * ? *"    Fire at 10:15am every day
   "0 15 10 * * ? 2005"    Fire at 10:15am every day during the year 2005
   "0 * 14 * * ?"    Fire every minute starting at 2pm and ending at 2:59pm, every day
   "0 0/5 14 * * ?"    Fire every 5 minutes starting at 2pm and ending at 2:55pm, every day
   "0 0/5 14,18 * * ?"    Fire every 5 minutes starting at 2pm and ending at 2:55pm, AND fire every 5 minutes starting at 6pm and ending at 6:55pm, every day
   "0 0-5 14 * * ?"    Fire every minute starting at 2pm and ending at 2:05pm, every day
   "0 10,44 14 ? 3 WED"    Fire at 2:10pm and at 2:44pm every Wednesday in the month of March.
   "0 15 10 ? * MON-FRI"    Fire at 10:15am every Monday, Tuesday, Wednesday, Thursday and Friday
   "0 15 10 15 * ?"    Fire at 10:15am on the 15th day of every month
   "0 15 10 L * ?"    Fire at 10:15am on the last day of every month
   "0 15 10 ? * 6L"    Fire at 10:15am on the last Friday of every month
   "0 15 10 ? * 6L"    Fire at 10:15am on the last Friday of every month
   "0 15 10 ? * 6L 2002-2005"    Fire at 10:15am on every last friday of every month during the years 2002, 2003, 2004 and 2005
   "0 15 10 ? * 6#3"    Fire at 10:15am on the third Friday of every month
   Pay attention to the effects of '?' and '*' in the day-of-week and day-of-month fields! </pre>
   */
  public void schedule(Class appTaskClass, String taskName,
                       String timeExpression) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    CronTrigger ct = new CronTrigger();
    ct.setName(UUIDGenerator.generate());
    ct.setJobName(taskName);
    ct.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      ct.setCronExpression(timeExpression);
      this.theScheduler.scheduleJob(jd, ct);
    }
    catch (ParseException ex) {
      throw new AppRuntimeException(ex);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 每日定时执行
   *
   * @param appTaskClass AppTask任务类
   * @param taskName 任务名称
   * @param hour （0－23）小时
   * @param minute （0－59）分钟
   */
  public void scheduleDialy(Class appTaskClass, String taskName, int hour,
                            int minute) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeDailyTrigger(UUIDGenerator.generate(),
        hour, minute);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 每周定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param dayOfWeek （1－7）星期
   * @param hour （0－23）小时
   * @param minute （0－59）分钟
   */
  public void scheduleWeekly(Class appTaskClass, String taskName, int dayOfWeek,
                             int hour,
                             int minute) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeWeeklyTrigger(UUIDGenerator.generate(),
        dayOfWeek,
        hour, minute);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 每月定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param dayOfMonth (1-31, or -1)月内某日
   * @param hour （0－23）小时
   * @param minute （0－59）分钟
   */
  public void scheduleMonthly(Class appTaskClass, String taskName,
                              int dayOfMonth,
                              int hour,
                              int minute) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeMonthlyTrigger(UUIDGenerator.generate(),
        dayOfMonth,
        hour, minute);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 立即执行，并可以按重复次数和间隔执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名
   * @param repeatCount 重复次数
   * @param repeatInterval 执行间隔 ms毫秒
   */
  public void scheduleImmediate(Class appTaskClass, String taskName,
                                int repeatCount,
                                long repeatInterval
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeImmediateTrigger(UUIDGenerator.generate(),
        repeatCount, repeatInterval);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以小时为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位小时，整数
   */
  public void scheduleHourly(Class appTaskClass, String taskName,
                             int intervalInHours
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeHourlyTrigger(intervalInHours);
    trigger.setJobName(taskName);
    trigger.setGroup(UUIDGenerator.generate());
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以小时为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位小时，整数
   * @param repeatCount 重复次数
   */
  public void scheduleHourly(Class appTaskClass, String taskName,
                             int intervalInHours, int repeatCount
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeHourlyTrigger(UUIDGenerator.generate(),
        intervalInHours, repeatCount);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以分钟为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位分钟，整数
   * @param repeatCount 重复次数
   */
  public void scheduleMinutely(Class appTaskClass, String taskName,
                               int intervalInMinutes, int repeatCount
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeImmediateTrigger(UUIDGenerator.generate(),
        intervalInMinutes, repeatCount);
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以分钟为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位分钟，整数
   */
  public void scheduleMinutely(Class appTaskClass, String taskName,
                               int intervalInMinutes
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    Trigger trigger = TriggerUtils.makeMinutelyTrigger(
        intervalInMinutes);
    trigger.setName(UUIDGenerator.generate());
    trigger.setJobName(taskName);
    trigger.setGroup(Scheduler.DEFAULT_GROUP);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以秒为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位秒，整数
   * @param repeatCount 重复次数
   */
  public void scheduleSecondly(Class appTaskClass, String taskName,
                               int intervalInSeconds, int repeatCount
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    SimpleTrigger trigger = new SimpleTrigger(UUIDGenerator.generate(),
                                              Scheduler.DEFAULT_GROUP);
    trigger.setRepeatInterval(intervalInSeconds * 1000l);
    trigger.setRepeatCount(repeatCount);
    trigger.setJobName(taskName);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 以秒为单位定时执行
   *
   * @param appTaskClass 任务类
   * @param taskName 任务名称
   * @param intervalInHours 时间间隔，单位秒，整数
   */
  public void scheduleSecondly(Class appTaskClass, String taskName,
                               int intervalInSeconds
      ) {
    JobDetail jd = new JobDetail();
    jd.setGroup(Scheduler.DEFAULT_GROUP);
    jd.setJobClass(appTaskClass);
    jd.setName(taskName);
    SimpleTrigger trigger = new SimpleTrigger(UUIDGenerator.generate(),
                                              Scheduler.DEFAULT_GROUP);
    trigger.setRepeatInterval(intervalInSeconds * 1000l);
    trigger.setRepeatCount(SimpleTrigger.REPEAT_INDEFINITELY);
    trigger.setJobName(taskName);
    try {
      this.theScheduler.scheduleJob(jd, trigger);
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  public void start() {
    try {
      this.theScheduler.start();
    }
    catch (SchedulerException ex) {
      throw new AppRuntimeException(ex);
    }
  }

  /**
   * 暂停所以的计划执行的任务
   */
  public void pauseAll() {
    try {
      this.theScheduler.pauseAll();
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  /**
   * 恢复所有被暂停的计划任务
   */
  public void resumeAll() {
    try {
      this.theScheduler.resumeAll();
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  public void shutdown(boolean waitForJobsToComplete) {
    try {
      this.theScheduler.shutdown(waitForJobsToComplete);
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  public boolean isShutdown() {
    try {
      return this.theScheduler.isShutdown();
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
      return false;
    }
  }

  public void shutdown() {
    try {
      this.theScheduler.shutdown();
    }
    catch (SchedulerException ex) {
      ex.printStackTrace();
    }
  }

  public static TaskScheduler getInstance() {
    if (instance == null) {
      instance = new TaskScheduler();
    }
    return instance;
  }
}

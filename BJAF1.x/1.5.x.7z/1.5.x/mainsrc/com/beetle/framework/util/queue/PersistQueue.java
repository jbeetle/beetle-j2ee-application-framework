package com.beetle.framework.util.queue;

import java.io.IOException;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.locks.ReentrantLock;

import jdbm.RecordManager;
import jdbm.RecordManagerFactory;

/**
 * 持久化队列实现，接收数据会根据内存队列长度先保持在内存中， 超过内存长度后，才会落地；<br>
 * 特别地，长度为0，则代表所有数据都会落地
 * 
 * @author HenryYu
 * 
 */
public final class PersistQueue implements IQueue {
	protected void finalize() throws Throwable {
		stopflag = true;
		if (recman != null) {
			recman.close();
		}
	}

	private volatile boolean stopflag = false;

	private class CM implements Runnable {

		public void run() {
			while (!stopflag) {
				if (recman != null) {
					try {
						if (!psKeys.isEmpty()) {
							writeLock.lock();
							try {
								recman.update(psKeysId, psKeys);
								recman.commit();
							} finally {
								writeLock.unlock();
							}
						}
						Thread.sleep(writeRate);
					} catch (Exception e) {
						try {
							recman.rollback();
						} catch (IOException e1) {
						}
						e.printStackTrace();
					}
				}
			}
		}
	}

	private IQueue tmpQueue;
	private int cacheLength;
	private RecordManager recman;
	private ConcurrentLinkedQueue<Long> psKeys;
	private long psKeysId;
	private long writeRate;
	private static final String psKeysName = "PersistQueue_HenryYu_psKeys";

	/**
	 * 构造函数
	 * 
	 * @param block
	 *            --是否为阻塞队列，true是阻塞队列,false是非阻塞队列
	 * @param cacheLength
	 *            --内存中队列长度；特別地为0；则代表所有数据都落地
	 * @param writeRate
	 *            -持久化队列是，写入频率，单位为ms毫秒为一个调优参数。<br>
	 *            特别地，为0时，实时写入，数据完整性最高；
	 * @param persistPathFilename
	 *            --持久数据落地文件名称（含路径）
	 * @throws IOException
	 */
	@SuppressWarnings("unchecked")
	public PersistQueue(boolean block, int cacheLength, long writeRate,
			String persistPathFilename) throws IOException {
		this.writeRate = writeRate;
		if (block) {
			this.tmpQueue = new BlockQueue();
		} else {
			this.tmpQueue = new NoBlockConcurrentQueue();
		}
		this.cacheLength = cacheLength;
		this.recman = RecordManagerFactory
				.createRecordManager(persistPathFilename);
		psKeysId = this.recman.getNamedObject(psKeysName);
		if (psKeysId == 0) {
			this.psKeys = new ConcurrentLinkedQueue<Long>();
			psKeysId = this.recman.insert(this.psKeys);
			this.recman.setNamedObject(psKeysName, psKeysId);
			this.recman.commit();
		} else {
			this.psKeys = (ConcurrentLinkedQueue<Long>) this.recman
					.fetch(psKeysId);
		}
		if (this.writeRate > 0) {
			Thread thead = new Thread(new CM());
			thead.setDaemon(true);
			thead.start();
		} else {
			this.writeRate = 0;
		}
	}

	public void push(Object obj) {
		if (tmpQueue.size() > cacheLength) {
			write(obj);
		} else {
			tmpQueue.push(obj);
		}
	}

	private final ReentrantLock writeLock = new ReentrantLock();

	private void write(Object obj) {// 无需synchronized
		try {
			long id = recman.insert(obj);
			psKeys.add(id);
			// recman.update(psKeysId, psKeys);
			if (writeRate == 0) {
				writeLock.lock();
				try {
					recman.update(psKeysId, psKeys);
					recman.commit();
				} finally {
					writeLock.unlock();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			tmpQueue.push(obj);// 出异常放回内存？
		}
	}

	private final ReentrantLock readLock = new ReentrantLock();

	public Object pop() {
		if (psKeys.isEmpty()) {
			return tmpQueue.pop();
		}
		return read();
	}

	private Object read() {// synchronized
		readLock.lock();
		try {
			Object obj = null;// NoSuchElementException
			Long fid = null;
			try {
				fid = (Long) psKeys.poll();
				if (fid != null) {
					obj = recman.fetch(fid.longValue());
					recman.delete(fid.longValue());
					// recman.update(psKeysId, psKeys);
					if (this.writeRate == 0) {
						writeLock.lock();
						try {
							recman.update(psKeysId, psKeys);
							recman.commit();
						} finally {
							writeLock.unlock();
						}
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
				try {
					if (this.writeRate == 0) {
						recman.rollback();
					}
					if (fid != null) {
						psKeys.add(fid);// 扔回最后
					}
				} catch (IOException e1) {
				}
			} finally {
				if (obj == null) {
					obj = tmpQueue.pop();
				}
			}
			return obj;
		} finally {
			readLock.unlock();
		}
	}

	public boolean isEmpty() {
		if (!tmpQueue.isEmpty()) {
			return false;
		}
		if (!psKeys.isEmpty()) {
			return false;
		}
		return true;
	}

	public synchronized void clear() {
		tmpQueue.clear();
		try {
			while (true) {
				Long fid = (Long) psKeys.poll();
				if (fid == null) {
					break;
				}
				recman.delete(fid.longValue());
			}
			psKeys.clear();
			recman.update(psKeysId, psKeys);
			recman.commit();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String getPersistFileName() {
		return recman.getFileName();
	}

	public long getPersistFileSize() throws IOException {
		return recman.getFileSize();
	}

	public int size() {
		return psKeys.size() + tmpQueue.size() - 1;
	}

}

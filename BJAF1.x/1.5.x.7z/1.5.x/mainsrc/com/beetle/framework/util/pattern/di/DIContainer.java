package com.beetle.framework.util.pattern.di;

import com.google.inject.Guice;
import com.google.inject.Injector;

/**
 * DI容器
 * 
 * @author HenryYu
 * 
 */
public final class DIContainer {
	private final Injector injector;

	public DIContainer(Dependency dependency) {
		injector = Guice.createInjector(dependency.getModuler());
	}

	/**
	 * 根据客户端类获取一个客户端实例（通过inject方式获取服务工作的类）
	 * 
	 * @param <T>
	 * @param client
	 * @return
	 */
	public <T> T getInstance(Class<T> client) {
		return injector.getInstance(client);
	}

}

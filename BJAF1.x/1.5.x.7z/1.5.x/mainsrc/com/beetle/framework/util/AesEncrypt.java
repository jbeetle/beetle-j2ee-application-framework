/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.util;

/**
 * <p>Title: J2EE��ܺ��Ĺ��߰�</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: �׿ǳ����</p>
 *
 * @author ��ƶ���hdyu@beetlesoft.net��
 * @version 1.0
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;

import com.beetle.framework.resource.ResourceReader;

public final class AesEncrypt {
	private static Cipher cipher = null;
	private static SecretKeySpec skeySpec = null;
	private static String sysconfigFileName = ResourceReader.getAPP_HOME()
			+ "config/BeetleACE.key";
	private final static char f = 2;

	private synchronized static void loadKey() {
		if (skeySpec == null) {
			File f = new File(sysconfigFileName);
			if (f.exists()) {
				fromFile();
			} else {
				fromPag();
			}
		}
	}

	private static void fromPag() {
		InputStream is = null;
		ObjectInputStream ois = null;
		try {
			cipher = Cipher.getInstance("AES");
			is = ResourceLoader
					.getResAsStream("com/beetle/framework/util/AesEncryptKey.properties");
			ois = new ObjectInputStream(is);
			skeySpec = (SecretKeySpec) ois.readObject();
			// System.out.println(skeySpec);
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
				if (is != null) {
					is.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	private static void fromFile() {
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try {
			cipher = Cipher.getInstance("AES");
			fis = new FileInputStream(sysconfigFileName);
			ois = new ObjectInputStream(fis);
			skeySpec = (SecretKeySpec) ois.readObject();
			// System.out.println(skeySpec);
		} catch (Throwable e) {
			e.printStackTrace();
		} finally {
			try {
				if (ois != null) {
					ois.close();
				}
				if (fis != null) {
					fis.close();
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Turns array of bytes into string
	 */
	private static String asHex(byte buf[]) {
		StringBuffer strbuf = new StringBuffer(buf.length * 2);
		for (int i = 0; i < buf.length; i++) {
			if (((int) buf[i] & 0xff) < 0x10) {
				strbuf.append("0");
			}

			strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
		}
		return strbuf.toString();
	}

	/**
	 * Turns string into array of bytes
	 */
	private static byte[] asByte(String buf) {
		if (buf.length() % 2 == 1) {
			buf = "0" + buf;
		}
		int length = buf.length() / 2;
		byte[] bytebuf = new byte[length];
		for (int i = 0; i < length; i++) {
			int pos = i * 2;
			String b = buf.substring(pos, pos + 2);
			bytebuf[i] = (byte) Integer.parseInt(b, 16);
		}
		return bytebuf;
	}

	/**
	 * 加密字符串（不支持中文）
	 * 
	 * @param pwd
	 *            --明文
	 * @return--密文
	 */
	public static String encrypt(String pwd) {
		if (skeySpec == null) {
			loadKey();
		}
		synchronized (cipher) {
			try {
				int lg = pwd.length();
				if (lg < 16) {
					int c = 16 - lg;
					for (int i = 0; i < c; i++) {
						pwd = pwd + f;
					}
				}
				cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
				byte[] encrypted = cipher.doFinal(pwd.getBytes());
				return asHex(encrypted);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	/**
	 * 解密字符串（不支持中文）
	 * 
	 * @param pwd
	 *            --密文
	 * @return--明文
	 */
	public static String decrypt(String pwd) {
		if (skeySpec == null) {
			loadKey();
		}
		synchronized (cipher) {
			try {
				byte[] encrypted = asByte(pwd);
				cipher.init(Cipher.DECRYPT_MODE, skeySpec);
				byte[] original = cipher.doFinal(encrypted);
				String r = new String(original);
				int lg = r.length();
				if (lg == 16) {
					int i = r.indexOf(f);
					if (i > 0) {
						r = r.substring(0, i);
					}
				}
				return r;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public static void genKeyFile() throws Exception {
		KeyGenerator keyGen = KeyGenerator.getInstance("AES");
		keyGen.init(128);
		java.io.ObjectOutputStream out = new java.io.ObjectOutputStream(
				new java.io.FileOutputStream("BeetleACE.key"));
		out.writeObject(keyGen.generateKey());
		out.close();

	}

	// to test
	public static void main(String[] args) throws Exception {
		String a = AesEncrypt.encrypt("999999999999999999");
		System.out.println(a);
		String aa = AesEncrypt.decrypt(a);
		System.out.println(aa);
		// genKeyFile();
	}
}

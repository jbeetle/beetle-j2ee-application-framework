/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.util.file;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

import com.beetle.framework.AppRuntimeException;

public class Dir {

	/**
	 * 列出某个目录下所有的文件名
	 * 
	 * @param dirPath
	 * @param includePath
	 *            -true文件名包含路径，false不带路径
	 * @return
	 */
	public final static List<String> getCurrentDirectoryFileNames(String dirPath,
			boolean includePath) {
		File file = new File(dirPath);
		if (!file.isDirectory()) {
			throw new AppRuntimeException(dirPath
					+ " is not a directory,can't deal!");
		}
		List<String> l = new ArrayList<String>();
		File[] fs = file.listFiles();
		if (fs == null) {
			return l;
		}
		for (int i = 0; i < fs.length; i++) {
			File f = fs[i];
			if (f.isFile()) {
				if (includePath) {
					l.add(f.getPath());
				} else {
					l.add(f.getName());
				}
			}
		}
		return l;
	}

	private static class FF implements FileFilter {
		private String suffixname;

		public FF(String suffixname) {
			super();
			this.suffixname = suffixname;
		}

		public boolean accept(File arg0) {
			if (arg0.isDirectory()) {
				return false;
			} else {
				String name = arg0.getName();
				int k = name.lastIndexOf('.');
				if (k <= 0) {
					return false;
				}
				name = name.substring(k);
				if (name.equalsIgnoreCase(suffixname)) {
					return true;
				} else {
					return false;
				}
			}
		}

	}

	/**
	 * 列出某个目录下所有的文件名
	 * 
	 * @param dirPath
	 * @param includePath
	 *            '.txt'
	 * @return
	 */
	public final static List<String> getCurrentDirectoryFileNames(String dirPath,
			boolean includePath, String suffixname) {
		File file = new File(dirPath);
		if (!file.isDirectory()) {
			throw new AppRuntimeException(dirPath
					+ " is not a directory,can't deal!");
		}
		List<String> l = new ArrayList<String>();
		File[] fs = file.listFiles(new FF(suffixname));
		if (fs == null) {
			return l;
		}
		for (int i = 0; i < fs.length; i++) {
			File f = fs[i];
			if (f.isFile()) {
				if (includePath) {
					l.add(f.getPath());
				} else {
					l.add(f.getName());
				}
			}
		}
		return l;
	}
}

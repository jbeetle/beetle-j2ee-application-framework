/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller.draw;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.controller.ControllerFactory;
import com.beetle.framework.web.tools.CommonUtil;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: J2EE系统开发框架
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author not attributable
 * @version 1.0
 */
public class DrawFactory {
	private static Map drawTable = new HashMap();
	private static ICache cacheDraw = new StrongCache();
	private static boolean initFlag = false;

	public static Map getDrawConfig(ServletContext app) {
		if (!initFlag) {
			loadDrawTable(app);
		}
		return drawTable;
	}

	public static boolean isDrawController(String url, ServletContext app) {
		if (!initFlag) {
			loadDrawTable(app);
			initFlag = true;
		}
		return drawTable.containsKey(url);
	}

	private static synchronized void loadDrawTable(ServletContext app) {
		initFlag = true;
		CommonUtil.fill_DataMap(app, "/config/WebController.xml",
				"mappings.controllers.drawing", "dItem", "name", "class",
				drawTable);
		Map mItem = ControllerFactory.getModuleItem(app);
		// 加载其它文件的数据
		if (!mItem.isEmpty()) {
			Set s = mItem.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
				Map.Entry e = (Map.Entry) it.next();
				String fn = (String) e.getKey();
				String active = (String) e.getValue();
				if (active.equalsIgnoreCase("true")) {
					CommonUtil.fill_DataMap(app, fn,
							"mappings.controllers.drawing", "dItem", "name",
							"class", drawTable);
				}
			}
		}
	}

	public static IDraw getDrawInstance(String url, ServletContext app,
			String zoreImpClass) throws ServletException {
		if (!initFlag) {
			loadDrawTable(app);
		}
		Object drawing = cacheDraw.get(url);
		if (drawing == null) {
			String className = (String) drawTable.get(url);
			if (className == null) {
				className = zoreImpClass;
				drawTable.put(url, className);
			}
			try {
				drawing = Class.forName(className.trim()).newInstance();
				IDraw imp = (IDraw) drawing;
				// 判别此控制器对象是否需要缓存
				if (ReflectUtil.isThreadSafe(imp.getClass())) {
					cacheDraw.put(url, drawing);
				}
			} catch (Exception e) {
				drawing = null;
				throw new ServletException(e);
			}
		}
		return (IDraw) drawing;
	}

}

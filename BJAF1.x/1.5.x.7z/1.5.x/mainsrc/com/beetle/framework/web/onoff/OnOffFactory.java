/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.onoff;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;

import com.beetle.framework.util.XMLProperties;

/**
 * <p>Title: BeetleWeb</p>
 *
 * <p>Description: MVC Web Framework</p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class OnOffFactory {
  private static String geOnOffStr(ServletContext application, String onOff) {
    String onffClass = null;
    InputStream in2 = null;
    in2 = application.getResourceAsStream("/config/WebController.xml");
    onffClass = XMLProperties.getTagContent(in2,
                                            "mappings.onoff." + onOff);
    if (in2 != null) {
      try {
        in2.close();
      }
      catch (IOException ex) {
        in2 = null;
      }
    }
    return onffClass;
  }

  public static IStartUp getStartUp(ServletContext application) {
    String s = geOnOffStr(application, "startUp");
    if (s == null || s.trim().equals("")) {
      return null;
    }
    try {
      Object o = Class.forName(s).newInstance();
      return (IStartUp) o;
    }
    catch (Exception ex) {
      return null;
    }
  }

  public static ICloseUp getCloseUp(ServletContext application) {
    String s = geOnOffStr(application, "closeUp");
    if (s == null || s.trim().equals("")) {
      return null;
    }
    try {
      Object o = Class.forName(s).newInstance();
      return (ICloseUp) o;
    }
    catch (Exception ex) {
      return null;
    }
  }
}

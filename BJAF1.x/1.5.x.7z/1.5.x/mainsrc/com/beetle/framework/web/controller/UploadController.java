/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.DiskFileUpload;
import org.apache.commons.fileupload.FileItem;

import com.beetle.framework.web.controller.upload.FileObj;
import com.beetle.framework.web.controller.upload.IUpload;
import com.beetle.framework.web.controller.upload.UploadFactory;
import com.beetle.framework.web.controller.upload.UploadForm;
import com.beetle.framework.web.tools.CommonUtil;
import com.beetle.framework.web.view.View;

/**
 * <p>
 * Title: BeetleWeb
 * </p>
 * 
 * <p>
 * Description: 文件上传控制器
 * 
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class UploadController extends ControllerImp {
	public UploadController() {
		super();
		this.setCacheSeconds(0);
		this.setInstanceCacheFlag(false);
	}

	/**
	 * execute
	 * 
	 * @param webInput
	 *            WebInput
	 * @return Model
	 * @throws ServletException
	 * @todo Implement this com.beetle.framework.web.controller.ControllerImp
	 *       method
	 */
	public View perform(WebInput webInput) throws ControllerException {
		HttpServletRequest request = webInput.getRequest();
		return doupload(webInput, request);
	}

	/**
	 * use the overdue upload package
	 * 
	 * @deprecated
	 * @param webInput
	 * @param request
	 * @return
	 * @throws ControllerException
	 */
	private View doupload(WebInput webInput, HttpServletRequest request)
			throws ControllerException {
		DiskFileUpload fu = null;
		List fileItems = null;
		try {
			IUpload upload = UploadFactory.getUploadInstance(webInput
					.getControllerName(), (String) webInput.getRequest()
					.getAttribute(CommonUtil.controllerimpclassname)); // 2007-03-21
			fu = new DiskFileUpload();
			long sizeMax = webInput.getParameterAsLng("sizeMax");
			if (sizeMax == 0) {
				fu.setSizeMax(IUpload.sizeMax);
			} else {
				fu.setSizeMax(sizeMax);
			}
			int sizeThreshold = webInput.getParameterAsInt("sizeThreshold");
			if (sizeThreshold == 0) {
				fu.setSizeThreshold(IUpload.sizeThreshold);
			} else {
				fu.setSizeThreshold(sizeThreshold);
			}
			List fileList = new ArrayList();
			Map fieldMap = new HashMap();
			fileItems = fu.parseRequest(request);
			Iterator i = fileItems.iterator();
			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				if (fi.isFormField()) {
					fieldMap.put(fi.getFieldName(), fi.getString());
				} else {
					fileList.add(new FileObj(fi));
				}
			}
			UploadForm fp = new UploadForm(fileList, fieldMap, request,
					webInput.getResponse());
			return upload.processUpload(fp);
		} catch (Exception ex) {
			throw new ControllerException("errCode[-1008]:" + ex.getMessage(),
					ex);
		} finally {
			if (fileItems != null) {
				fileItems.clear();
			}
			fu = null;
		}
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.controller.ControllerFactory;
import com.beetle.framework.web.controller.MainControllerServlet;
import com.beetle.framework.web.controller.ajax.AjaxConfig;
import com.beetle.framework.web.controller.document.DocFactory;
import com.beetle.framework.web.controller.draw.DrawFactory;
import com.beetle.framework.web.controller.upload.UploadFactory;
import com.beetle.framework.web.onoff.ICloseUp;
import com.beetle.framework.web.onoff.IStartUp;
import com.beetle.framework.web.onoff.OnOffFactory;
import com.beetle.framework.web.service.WebServiceServlet;
import com.beetle.framework.web.service.imp.ServiceConfig;
import com.beetle.framework.web.tools.CommonUtil;
import com.beetle.framework.web.view.ViewFactory;

final public class GlobalDispatchServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private static Map exeNameList = new HashMap();

	private static ICache actionCache = new StrongCache();// 主控servlet缓存

	private static String charset = null;
	private static String contentType = null;
	private static String ctrlPrefix = null;
	private static String disabledSessionView = null;
	private static String websrv_suffix = null;
	private static String ctrl_view_map_enabled = null;
	private static boolean init_f = false;

	private static boolean destory_f = false;

	// Process the HTTP Post request
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	/**
	 * init
	 * 
	 * @throws ServletException
	 * @todo Implement this javax.servlet.GenericServlet method
	 */
	public void init() throws ServletException {
		if (!init_f) {
			init_f = true;
			System.out.println("===Start up the ["
					+ this.getServletContext().getServletContextName()
					+ "] web application");
			IStartUp su = OnOffFactory.getStartUp(this.getServletContext());
			if (su != null) {
				su.startUp();
			}
			Map sMap = ControllerFactory.getStandartControllerConfigs(this
					.getServletContext());
			fillExeName(sMap, 1001); // ctrl
			sMap = DrawFactory.getDrawConfig(this.getServletContext());
			fillExeName(sMap, 1002); // draw
			sMap = UploadFactory.getUploadConfig(this.getServletContext());
			fillExeName(sMap, 1003); // upload
			sMap = ServiceConfig.getServices(this.getServletContext());
			fillExeName(sMap, 1004); // webservice
			sMap = AjaxConfig.getAjaxConfig(this.getServletContext());
			fillExeName(sMap, 1005); // ajax
			sMap = DocFactory.getDocConfig(this.getServletContext());
			fillExeName(sMap, 1006); // document
			Map m = ControllerFactory.getModuleItem(getServletContext()); // 清除无用数据
			m.clear();
			m = null;
			ViewFactory.loadViewConfigInfo(getServletContext()); // 加载视图数据以便初始化
			charset = this.getServletContext().getInitParameter("WEB_ENCODE");
			if (charset == null) {
				charset = System.getProperty("file.encoding");
			}
			ctrlPrefix = this.getServletContext().getInitParameter(
					"CTRL_PREFIX");
			if (ctrlPrefix == null) {
				ctrlPrefix = "";
			} else {// 格式化前缀
				ctrlPrefix = CommonUtil.addLastBeveltoPatch(ctrlPrefix);
			}
			if (ctrl_view_map_enabled == null) {
				ctrl_view_map_enabled = this.getServletContext()
						.getInitParameter("CTRL_VIEW_MAP_ENABLED");
			}

			websrv_suffix = this.getServletContext().getInitParameter(
					"WEB_SERVICE_SUFFIX");
			if (websrv_suffix == null) {
				websrv_suffix = "service";
			}
			if (disabledSessionView == null) {
				disabledSessionView = this.getServletContext()
						.getInitParameter("DISABLED_SESSION_VIEW");
				// 如果WebView.xml定义了，那么与它为准
				if (!ViewFactory.getViewCache().containsKey(
						CommonUtil.DISABLED_SESSION_VIEW)) {
					ViewFactory.getViewCache().put(
							CommonUtil.DISABLED_SESSION_VIEW,
							disabledSessionView);
				}
			}
			contentType = "text/html; charset=" + charset;
			System.out.println("charset:" + charset);
			System.out.println("ctrlPrefix:" + ctrlPrefix);
			System.out.println("ctrlViewMapEnabled:" + ctrl_view_map_enabled);
			System.out.println("exeNameList:" + exeNameList);
			System.out.println("GlobalDispatchServlet has initialized!");
		}
	}

	// Process the HTTP Get request
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String suffixname = getRequestSuffix(request);
		Integer keyValue = getKeyValue(suffixname);
		if (keyValue == null) {
			if (suffixname.equalsIgnoreCase(websrv_suffix)) {
				keyValue = new Integer(1004);
				exeNameList.put(websrv_suffix.toLowerCase(), keyValue);
			} else {
				keyValue = new Integer(1001);
				exeNameList.put(suffixname.toLowerCase(), keyValue);
			}
		}
		int flag = keyValue.intValue();
		if (flag == 1004) {
			WebServiceServlet service = (WebServiceServlet) actionCache
					.get(keyValue);
			if (service == null) {
				service = new WebServiceServlet();
				service.init(this.getServletConfig());
				actionCache.put(keyValue, service);
			}
			service.setContext(this.getServletContext());
			service.service(request, response);
		} else {// 1001,1002,1003,1005,1006
			doMainController(request, response, keyValue);
		}
	}

	private void doMainController(HttpServletRequest request,
			HttpServletResponse response, Integer keyValue) throws IOException,
			ServletException {
		response.setContentType(contentType);
		request.setCharacterEncoding(charset);
		request.setAttribute(CommonUtil.WEB_ENCODE_CHARSET, charset);
		request.setAttribute(CommonUtil.WEB_SERVER_INFO, this
				.getServletContext().getServerInfo());
		request.setAttribute(CommonUtil.WEB_CTRL_PREFIX, ctrlPrefix);
		request.setAttribute(CommonUtil.CTRL_VIEW_MAP_ENABLED,
				ctrl_view_map_enabled);
		request.setAttribute(CommonUtil.DISABLED_SESSION_VIEW,
				disabledSessionView);
		MainControllerServlet m = (MainControllerServlet) actionCache
				.get(keyValue);
		if (m == null) {
			m = new MainControllerServlet();
			actionCache.put(keyValue, m);
		}
		m.setContext(this.getServletContext());
		m.doGet(request, response);
	}

	private final static Integer getKeyValue(String suffixname) {
		// String path = CommonUtil.analysePath(request.getServletPath());
		Integer keyValue = (Integer) exeNameList.get(suffixname.toLowerCase());
		return keyValue;
	}

	private static String getRequestSuffix(HttpServletRequest request) {
		String path = request.getServletPath();
		int pos = path.lastIndexOf(CommonUtil.DOT_STR);
		if (pos >= 0) {
			path = path.substring(pos + 1);
		}
		return path;
	}

	private final static void fillExeName(Map sMap, int key) {
		Set s = sMap.keySet();
		Iterator it = s.iterator();
		if (key == 1006) { // 特殊，文档包含多个后缀
			while (it.hasNext()) {
				String keyName = (String) it.next();
				int i = keyName.indexOf(CommonUtil.DOT_STR);
				if (i >= 0) {
					exeNameList
							.put(keyName.substring(i + 1).toLowerCase(), key);
				}
			}
		} else { // 其他一个后缀，只读一次，提高效率
			if (it.hasNext()) {
				String keyName = (String) it.next();
				int i = keyName.indexOf(".");
				if (i >= 0) {
					exeNameList
							.put(keyName.substring(i + 1).toLowerCase(), key);
				}
			}
		}
	}

	/**
	 * destroy
	 * 
	 * @todo Implement this javax.servlet.Servlet method
	 */
	public void destroy() {
		if (!destory_f) {
			destory_f = true;
			System.out.println("===Closs up the ["
					+ this.getServletContext().getServletContextName()
					+ "] web application");
			ICloseUp cu = OnOffFactory.getCloseUp(this.getServletContext());
			if (cu != null) {
				cu.closeUp();
			}
		}
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.service;

import com.caucho.hessian.client.HessianProxyFactory;

/**
 * <p>
 * Title: BeetleWeb
 * </p>
 * 
 * <p>
 * Description: Web Service客户端帮助类
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class ClientHelper {
	/**
	 * 获取服务器对象
	 * 
	 * @param interfaceApi
	 *            Class－－对于的接口类
	 * @param serviceUrl
	 *            服务对应的url，WebController.xml对应，例如：
	 * @return 结果对象
	 */
	public static Object getServiceObject(Class interfaceApi, String serviceUrl)
			throws WebServiceException {
		HessianProxyFactory factory = new HessianProxyFactory();
		try {
			return factory.create(interfaceApi, serviceUrl);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new WebServiceException(ex);
		}
	}

	/**
	 * 获取特例通用服务
	 * 
	 * @param serviceUrl
	 *            服务的URL
	 * @return 通用服务接口
	 */
	public static ICommonService getCommonService(String serviceUrl)
			throws WebServiceException {
		try {
			Object obj = getServiceObject(ICommonService.class, serviceUrl);
			return (ICommonService) obj;
		} catch (WebServiceException wse) {
			throw wse;
		}
	}

	/**
	 * 直接调用特例服务业务方法
	 * @param serviceUrl 服务地址(url)
	 * @param webRequest 输入参数对象
	 * @return WebResponse 结果响应数据对象
	 * @throws WebServiceException
	 */
	public static WebResponse directInvoke(String serviceUrl,
			WebRequest webRequest) throws WebServiceException {
		try {
			Object obj = getServiceObject(ICommonService.class, serviceUrl);
			return ((ICommonService) obj).perform(webRequest);
		} catch (WebServiceException wse) {
			throw wse;
		}
	}
}

package com.beetle.framework;


/**
 * <p>
 * Title: J2EE��ܺ��Ĺ��߰�
 * 
 * </p>
 * 
 * <p>
 * Description:��ܷǼ���쳣����
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: �׿ǳ����
 * 
 * </p>
 * 
 * @author ��ƶ���hdyu@beetlesoft.net��
 * @version 1.0
 */
public class AppRuntimeException extends RuntimeException {
	private int errCode;

	public int getErrCode() {
		return errCode;
	}

	public AppRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	public AppRuntimeException(int errCode, String message, Throwable cause) {
		super(message, cause);
		this.errCode = errCode;
	}

	public AppRuntimeException(String message) {
		super(message);
	}

	public AppRuntimeException(int errCode, String message) {
		super(message);
		this.errCode = errCode;
	}

	public AppRuntimeException(Throwable cause) {
		super(cause);
	}

	public AppRuntimeException(int errCode, Throwable cause) {
		super(cause);
		this.errCode = errCode;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}

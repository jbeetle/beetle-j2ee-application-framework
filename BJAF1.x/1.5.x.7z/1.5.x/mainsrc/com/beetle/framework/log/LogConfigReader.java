/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.log;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Enumeration;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.PropertyConfigurator;

import com.beetle.framework.resource.ResourceReader;
import com.beetle.framework.util.PropertiesReader;
import com.beetle.framework.util.ResourceLoader;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: J2EEϵͳ�������
 * 
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: �׿ǳ����
 * 
 * </p>
 * 
 * @author not attributable
 * @version 1.0
 */
public class LogConfigReader extends PropertiesReader {
	final static String getResStr(String key) {
		return LogConfigReader.getValue(LogConfigReader
				.getBundle("com.beetle.framework.log.log4j"), key);
	}

	private static boolean hasInited = false;
	private static String lastpath = "";
	private static int loadFlag = 0;

	static boolean isInited() {
		return hasInited;
	}

	static void reload(Properties pro) {
		PropertyConfigurator.configure(pro);
	}

	static void reload() {
		if (loadFlag == 1) {
			PropertyConfigurator.configure(lastpath);
		} else if (loadFlag == 2) {
			URL url;
			try {
				url = ResourceLoader.getResURL(lastpath);
				PropertyConfigurator.configure(url);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	synchronized static void init(Properties pro) {
		if (!hasInited) {
			PropertyConfigurator.configure(pro);
		}
		hasInited = true;
	}

	synchronized static void init(URL url) {
		if (!hasInited) {
			PropertyConfigurator.configure(url);
			loadFlag = 2;
			lastpath = url.toString();
		}
		hasInited = true;
	}

	synchronized static void init(File configFile) {
		if (!configFile.exists()) {
			System.out.println(configFile + " can't be found! err");
			return;
		}
		if (!hasInited) {
			PropertyConfigurator.configure(configFile.getPath());
			lastpath = configFile.getPath();
			loadFlag = 1;
		}
		hasInited = true;
	}

	synchronized static void init() {
		if (!hasInited) {
			lastpath = ResourceReader.getAPP_HOME() + "config/log4j.properties";
			Enumeration<?> e = LogManager.getCurrentLoggers();
			if (!e.hasMoreElements()) {
				File f = new File(lastpath); 
				if (f.exists()) { // ��ϵͳ·������
					PropertyConfigurator.configure(lastpath);
					loadFlag = 1;
					System.out.println("loaded " + lastpath + "from file");
				} else { //
					try {
						URL url = ResourceLoader.getResURL(lastpath);
						loadFlag = 2;
						PropertyConfigurator.configure(url);
						System.out
								.println("loaded 'config/log4j.properties' from jar");
					} catch (IOException ex) {
						otherway();
					}
				}
				f = null;
			} else {
				System.out.println("other log4j's config has loaded,uses it.");
			}
		}
		hasInited = true;
	}

	private static void otherway() {
		lastpath = ResourceReader.getAPP_HOME() + "config/log4j.xml";
		File f = new File(lastpath);
		if (f.exists()) {
			PropertyConfigurator.configure(lastpath);
			loadFlag = 1;
			System.out.println("loaded " + lastpath + "from file");
		} else {
			lastpath = "config/log4j.properties";
			f = new File(lastpath);
			if (f.exists()) {
				PropertyConfigurator.configure(lastpath);
				loadFlag = 1;
				System.out.println("loaded " + lastpath + "from file");
			} else {
				lastpath = "log4j.properties";
				f = new File(lastpath);
				if (f.exists()) {
					PropertyConfigurator.configure(lastpath);
					System.out
							.println("loaded log4j.properties in current path or classpath");
				} else {
					loadDef();
				}
			}
		}
		f = null;
	}

	private static void loadDef() {
		System.out
				.println("can't find 'log4j.properties' file,use define setting[com.beetle.framework.log.log4j.properties].");
		Properties properties = new Properties();
		String rootLogger = LogConfigReader.getResStr("log4j.rootLogger");
		if (rootLogger != null) {
			properties.put("log4j.rootLogger", rootLogger);
		}
		String beetleLogger = LogConfigReader
				.getResStr("log4j.logger.com.beetle");
		if (beetleLogger != null) {
			properties.put("log4j.logger.com.beetle", beetleLogger);
		}
		properties.put("log4j.appender.A1", LogConfigReader
				.getResStr("log4j.appender.A1"));
		properties.put("log4j.appender.A1.layout", LogConfigReader
				.getResStr("log4j.appender.A1.layout"));
		properties
				.put(
						"log4j.appender.A1.layout.ConversionPattern",
						LogConfigReader
								.getResStr("log4j.appender.A1.layout.ConversionPattern"));
		properties.put("log4j.appender.A2", LogConfigReader
				.getResStr("log4j.appender.A2"));
		properties.put("log4j.appender.A2.file", LogConfigReader
				.getResStr("log4j.appender.A2.file"));
		properties.put("log4j.appender.A2.DatePattern", LogConfigReader
				.getResStr("log4j.appender.A2.DatePattern"));
		properties.put("log4j.appender.A2.layout", LogConfigReader
				.getResStr("log4j.appender.A2.layout"));
		properties
				.put(
						"log4j.appender.A2.layout.ConversionPattern",
						LogConfigReader
								.getResStr("log4j.appender.A2.layout.ConversionPattern"));
		PropertyConfigurator.configure(properties);
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp.ejb;

/**
 * <p>Title: BeetleSoft Framework</p>
 *
 * <p>Description: J2EE系统开发框架</p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东
 * @version 1.0
 */
import java.rmi.RemoteException;

import com.beetle.framework.business.BusinessConfigReader;
import com.beetle.framework.business.common.ejb.EJBFactoryException;
import com.beetle.framework.business.common.ejb.HomeFactoryHelper;
import com.beetle.framework.business.common.ejb.IEJBHomeFactory;
import com.beetle.framework.resource.SysConfigReader;
import com.beetle.framework.util.OtherUtil;

public class BusinessDelegateFactory implements IEJBHomeFactory {
	private static BusinessDelegateFactory instance = new BusinessDelegateFactory();

	private BusinessDelegateFactory() {
		remoteObjCacheFlag = isRemoteObjCacheMark();
	}

	private static boolean remoteObjCacheFlag = false;

	public boolean isRemoteObjCacheMark() {
		String flag = BusinessConfigReader
				.getDelegateLogicValue("REMOTE_OBJECT_CACHE");
		if (flag != null && !flag.equals("")) {
			if (flag.equalsIgnoreCase("true")) {
				return true;
			} else {
				return false;
			}
		} else {
			return false;
		}
	}

	public static BusinessDelegateFactory getInstance() {
		return instance;
	}

	public Object createRemoteHomeObject() throws EJBFactoryException {
		try {
			return HomeFactoryHelper.findRemoteHome(null, BusinessConfigReader
					.getDelegateLogicValue("JNDI_NAME"),
					BusinessDelegateHome.class);
		} catch (RemoteException e) {
			Object o = getOtherHomeObject();
			if (o != null) {
				return o;
			} else {
				throw new EJBFactoryException(e);
			}
		} catch (ClassNotFoundException e) {
			throw new EJBFactoryException(e);
		}
	}

	private static Object getOtherHomeObject() {
		Object o = null;
		String gnames = SysConfigReader.getGroupNames("default");
		if (gnames != null && gnames.equals("")) {
			String tgns[] = gnames.split("#");
			for (int i = 0; i < tgns.length; i++) {
				try {
					o = HomeFactoryHelper.findRemoteHome(tgns[i],
							BusinessConfigReader
									.getDelegateLogicValue("JNDI_NAME"),
							BusinessDelegateHome.class);
					if (o != null) {
						break;
					}
				} catch (Exception e) {
					o = null;
					e.printStackTrace();
				}
			}
			OtherUtil.clearArray(tgns);
		}
		return o;
	}

	public Object createLocalHomeObject() throws EJBFactoryException {
		try {
			return HomeFactoryHelper.findLocalHome(BusinessConfigReader
					.getDelegateLogicValue("LOCAL_JNDI_NAME"));
		} catch (Exception e) {
			throw new EJBFactoryException(e);
		}
	}

	private static BusinessDelegate bsDelegate = null;

	public static BusinessDelegate createBusinessDelegate()
			throws EJBFactoryException {
		try {
			if (remoteObjCacheFlag) {
				if (bsDelegate == null) {
					bsDelegate = ((BusinessDelegateHome) BusinessDelegateFactory
							.getInstance().createRemoteHomeObject()).create();
				}
				return bsDelegate;
			} else {
				return ((BusinessDelegateHome) BusinessDelegateFactory
						.getInstance().createRemoteHomeObject()).create();
			}
		} catch (Exception e) {
			throw new EJBFactoryException(e);
		}
	}

	public static BusinessDelegateLocal createBusinessDelegateLocal()
			throws EJBFactoryException {
		try {
			return ((BusinessDelegateLocalHome) BusinessDelegateFactory
					.getInstance().createLocalHomeObject()).create();
		} catch (Exception e) {
			throw new EJBFactoryException(e);
		}
	}
}

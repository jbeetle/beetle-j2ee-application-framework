/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp;

import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.BusinessException;
import com.beetle.framework.business.delegate.BusinessRollbackException;
import com.beetle.framework.business.delegate.DelegateExecuteException;
import com.beetle.framework.business.delegate.DelegateHelper;
import com.beetle.framework.business.delegate.IBusiness;
import com.beetle.framework.business.delegate.IDelegateTarget;
import com.beetle.framework.business.interrupt.ActionExecutor;
import com.beetle.framework.business.interrupt.ActionSignal;
import com.beetle.framework.resource.jta.ITransaction;
import com.beetle.framework.resource.jta.JTAException;
import com.beetle.framework.resource.jta.JTAFactory;
import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: J2EE系统开发框架
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东
 * @version 1.0
 */
public class PojoTarget implements IDelegateTarget {
	private static PojoTarget instance = new PojoTarget();
	private static ICache cacheSafeObj = new StrongCache(512);

	private PojoTarget() {

	}

	private Object getFromNative(String logicClass) {
		// checkUrl(logicClass);
		Object localObject = null;
		try {
			// Class[] constrParamTypes = new Class[] {};
			// Object[] constrParamValues = new Object[] {};
			localObject = ReflectUtil.newInstance(logicClass, null, null);
			return localObject;
		} catch (Exception t) {
			throw new com.beetle.framework.AppRuntimeException(
					"create service obj err!");
		}
	}

	private BsResponse getErrResultObj(String errMsg) {
		BsResponse ro = new BsResponse();
		ro.setReturnFlag(BsResponse.FATAL_ERR_FLAG);
		ro.setReturnMsg(errMsg);
		return ro;
	}

	public BsResponse executeBusinessWithTransaction(BsRequest bsReq)
			throws DelegateExecuteException {
		// begin point cut
		int procSignal = ActionExecutor.beginPointCutExecute(bsReq, null);
		if (procSignal == ActionSignal.PROCESS_BREAK) {
			return new BsResponse();
		}
		//
		ITransaction trans = null;
		BsResponse rd = null;
		try {
			trans = JTAFactory.getTransactionFromMock();
			DelegateHelper.bind(trans);
			IBusiness serviceObject = callServiceObj(bsReq);
			trans.begin();
			rd = serviceObject.execute(bsReq);
			trans.commit();
			// end point cut
			ActionExecutor.endPointCutExecute(bsReq, rd);
			return rd;
		} catch (JTAException jta) {
			throw new DelegateExecuteException(jta);
		} catch (BusinessException t) {
			trans.rollback();
			if (t instanceof BusinessRollbackException) {
				//System.out.println("rollback by hand!");
				BusinessRollbackException t2 = (BusinessRollbackException) t;
				return t2.getBs();
			} else {
				return getErrResultObj(t.getMessage());
			}

		} catch (Exception e) {
			trans.rollback();
			e.printStackTrace();
			return getErrResultObj(e.getMessage());
		} finally {
			if (bsReq != null) {
				bsReq.clear();
			}
			DelegateHelper.unbind();
			trans = null;
		}
	}

	public static PojoTarget getInstance() {
		return instance;
	}

	public BsResponse executeBusiness(BsRequest bsReq)
			throws DelegateExecuteException {
		// begin point cut
		int procSignal = ActionExecutor.beginPointCutExecute(bsReq, null);
		if (procSignal == ActionSignal.PROCESS_BREAK) {
			return new BsResponse();
		}
		try {
			DelegateHelper.bind();
			IBusiness serviceObject = callServiceObj(bsReq);
			BsResponse rd = serviceObject.execute(bsReq);
			// end point cut
			ActionExecutor.endPointCutExecute(bsReq, rd);
			return rd;
		} catch (BusinessException t) {
			return getErrResultObj(t.getMessage());
		} finally {
			if (bsReq != null) {
				bsReq.clear();
			}
			DelegateHelper.unbind();
		}
	}

	private IBusiness callServiceObj(BsRequest params) {
		IBusiness serviceObject = (IBusiness) cacheSafeObj.get(params
				.getBusinessURL());
		if (serviceObject == null) {
			serviceObject = (IBusiness) getFromNative(params.getBusinessURL());
			if (ReflectUtil.isThreadSafe(serviceObject.getClass())) {
				cacheSafeObj.put(params.getBusinessURL(), serviceObject);
			}
		}
		return serviceObject;
	}

}

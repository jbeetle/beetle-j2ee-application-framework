/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.service;

/**
 * <p>Title: Beetle业务逻辑框架</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东（yuhaodong@gmail.com）
 * @version 1.0
 */
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.business.BusinessConfigReader;
import com.beetle.framework.business.delegate.imp.ejb.BusinessDelegate;
import com.beetle.framework.business.delegate.imp.ejb.BusinessDelegateFactory;
import com.beetle.framework.business.delegate.imp.ejb.BusinessDelegateLocal;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.resource.ResourceReader;
import com.beetle.framework.util.ResourceLoader;

public class ServiceFactory {

	private final static Map<String, ServiceAtt> serviceConfig = new HashMap<String, ServiceAtt>();

	public static void resetServiceConfig() {
		serviceConfig.clear();
		loadConfig();
	}

	private static void loadConfig() {
		synchronized (serviceConfig) {
			if (serviceConfig.isEmpty()) {
				SAXReader reader = null;
				Document doc = null;
				File f = new File(ResourceReader.getAPP_HOME()
						+ "config/Service.xml");
				if (f.exists()) { // ResourceLoader.getResAsStream
					//
					BusinessConfigReader
							.markCfgInfo(f, ResourceReader.getAPP_HOME()
									+ "config/Service.xml");
					//
					reader = new SAXReader();
					readInfo(reader, doc, f);
					SysLogger.getInstance(ServiceFactory.class).info(
							"from file:[" + f.getPath() + "]");
				} else {
					reader = new SAXReader();
					try {
						readInfo(reader, doc,
								ResourceLoader
										.getResAsStream("config/Service.xml"));
						SysLogger.getInstance(ServiceFactory.class).info(
								"from jar:["
										+ ResourceLoader.getClassLoader()
												.toString() + "]");
					} catch (IOException ex) {
						SysLogger.getInstance(ServiceFactory.class).error(ex);
					}
				}
			}
		}
	}

	private static void readInfo(SAXReader reader, Document doc,
			InputStream xmlFileInputStream) {
		try {
			doc = reader.read(xmlFileInputStream);
			Node node = doc.selectSingleNode("Service");
			if (node != null) {
				Iterator<?> it = node.selectNodes("Item").iterator();
				while (it.hasNext()) {
					ServiceAtt attr = new ServiceAtt();
					Element e = (Element) it.next();
					attr.setId(e.valueOf("@id"));
					attr.setImpClass(e.valueOf("@impClass"));
					attr.setLocation(e.valueOf("@location"));
					attr.setType(e.valueOf("@type"));
					attr.setTransAttribute(e.valueOf("@transAttribute"));
					attr.setEnabled(e.valueOf("@enabled"));
					attr.setTimeout(e.valueOf("@timeout"));
					serviceConfig.put(attr.getId(), attr);
				}
			}
		} catch (Exception de) {
			de.printStackTrace();
		} finally {
			if (doc != null) {
				doc.clearContent();
				doc = null;
			}
			reader = null;
		}
	}

	private static void readInfo(SAXReader reader, Document doc, File f) {
		try {
			doc = reader.read(f);
			Node node = doc.selectSingleNode("Service");
			if (node != null) {
				Iterator<?> it = node.selectNodes("Item").iterator();
				while (it.hasNext()) {
					ServiceAtt attr = new ServiceAtt();
					Element e = (Element) it.next();
					attr.setId(e.valueOf("@id"));
					attr.setImpClass(e.valueOf("@impClass"));
					attr.setLocation(e.valueOf("@location"));
					attr.setType(e.valueOf("@type"));
					attr.setTransAttribute(e.valueOf("@transAttribute"));
					attr.setEnabled(e.valueOf("@enabled"));
					attr.setTimeout(e.valueOf("@timeout"));
					serviceConfig.put(attr.getId(), attr);
				}
			}
		} catch (Exception de) {
			de.printStackTrace();
		} finally {
			if (doc != null) {
				doc.clearContent();
				doc = null;
			}
			reader = null;
		}
	}

	/**
	 * 执行服务返回结果
	 * 
	 * @param input
	 *            输入参数Input
	 * @return 返回结果对象Output
	 * @throws AppRuntimeException
	 */
	public static final Output doService(Input input)
			throws AppRuntimeException {
		if (serviceConfig.isEmpty()) {
			loadConfig();
		}
		ServiceAtt sa = (ServiceAtt) serviceConfig.get(input.getServiceId());
		if (sa == null) {
			throw new AppRuntimeException("can not find ["
					+ input.getServiceId()
					+ "]config,check your config file,please.");
		}
		String type = sa.getType();
		input.put("imp_class_name", sa.getImpClass());
		Output out = null;
		if (type.equalsIgnoreCase(ServiceAtt.type_Local)) {
			out = doLocal(input, sa);
		} else if (type.equalsIgnoreCase(ServiceAtt.type_Remote)) {
			out = doRemote(input, sa);
		} else if (type.equalsIgnoreCase(ServiceAtt.type_Web)) {
			throw new AppRuntimeException("sorry,not implement yet!");
		}
		return out;
	}

	/**
	 * 执行服务返回结果
	 * 
	 * @param input
	 *            输入参数Input
	 * @param sa
	 *            服务属性对象
	 * 
	 * @return 返回结果对象
	 * @throws AppRuntimeException
	 */
	public static final Output doService(Input input, ServiceAtt sa)
			throws AppRuntimeException {
		input.put("imp_class_name", sa.getImpClass());
		String type = sa.getType();
		Output out = null;
		if (type.equalsIgnoreCase(ServiceAtt.type_Local)) {
			out = doLocal(input, sa);
		} else if (type.equalsIgnoreCase(ServiceAtt.type_Remote)) {
			out = doRemote(input, sa);
		} else if (type.equalsIgnoreCase(ServiceAtt.type_Web)) {
			throw new AppRuntimeException("sorry,not implement yet!");
		}
		return out;
	}

	private static Output doRemote(Input input, ServiceAtt sa)
			throws AppRuntimeException {
		Output out = null;
		String transAttribute = sa.getTransAttribute();
		if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_NotSupported)) {
			try {
				BusinessDelegate remote = BusinessDelegateFactory
						.createBusinessDelegate();
				out = remote.runServiceNotSupported(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		} else if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_Required)) {
			try {
				BusinessDelegate remote = BusinessDelegateFactory
						.createBusinessDelegate();
				out = remote.runServiceRequired(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		} else if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_Supports)) {
			try {
				BusinessDelegate remote = BusinessDelegateFactory
						.createBusinessDelegate();
				out = remote.runServiceSupports(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		}
		return out;
	}

	private static Output doLocal(Input input, ServiceAtt sa)
			throws AppRuntimeException {
		Output out = null;
		String transAttribute = sa.getTransAttribute();
		if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_NotSupported)) {
			try {
				BusinessDelegateLocal bdlocal = BusinessDelegateFactory
						.createBusinessDelegateLocal();
				out = bdlocal.runServiceNotSupported(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		} else if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_Required)) {
			try {
				BusinessDelegateLocal bdlocal = BusinessDelegateFactory
						.createBusinessDelegateLocal();
				out = bdlocal.runServiceRequired(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		} else if (transAttribute
				.equalsIgnoreCase(ServiceAtt.transAttribute_Supports)) {
			try {
				BusinessDelegateLocal bdlocal = BusinessDelegateFactory
						.createBusinessDelegateLocal();
				out = bdlocal.runServiceSupports(input);
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		}
		return out;
	}

	public static Map<String, ServiceAtt> getServiceInfo() {
		return serviceConfig;
	}

	public static ServiceAtt getServiceAtt(String srvid) {
		if (serviceConfig.isEmpty()) {
			loadConfig();
		}
		return (ServiceAtt) serviceConfig.get(srvid);
	}

}

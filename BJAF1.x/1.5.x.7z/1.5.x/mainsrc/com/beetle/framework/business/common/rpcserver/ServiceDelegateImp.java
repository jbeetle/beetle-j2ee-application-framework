/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.common.rpcserver;

import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.imp.PojoTarget;

public class ServiceDelegateImp implements IRpcService {
	public ServiceDelegateImp() {
	}

	/**
	 * perform
	 * 
	 * @param paramObj
	 *            Object
	 * @param executeFlag
	 *            int
	 * @return Object
	 * @throws RpcServerException
	 * @todo Implement this com.beetle.framework.business.rpcserver.IService
	 *       method
	 */
	public Object perform(Object paramObj, int executeFlag)
			throws RpcServerException {
		BsRequest input = (BsRequest) paramObj;
		switch (executeFlag) {
		case IRpcService.EXECUTE_WITH_TRANSACTION:
			return PojoTarget.getInstance().executeBusinessWithTransaction(
					input);
		case IRpcService.EXECUTE_WITHOUT_TRANSACTION:
			return PojoTarget.getInstance().executeBusiness(input);
		}
		throw new RpcServerException("can't match the executeFlag:"
				+ executeFlag);
	}
	/*
	 * private static Object convertObj(Object obj) { if (obj instanceof
	 * java.util.List) { return obj; } else if (obj instanceof java.util.Map) {
	 * return obj; } else { List l = new ArrayList(); //其它非集合对象都放入List传递
	 * 
	 * l.add(obj); obj = null; return l; } }
	 */
}

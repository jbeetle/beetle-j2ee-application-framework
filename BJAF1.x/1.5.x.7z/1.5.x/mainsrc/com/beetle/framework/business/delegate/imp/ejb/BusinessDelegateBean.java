/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp.ejb;

import com.beetle.framework.business.common.ejb.SessionEJBImp;
import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.BusinessException;
import com.beetle.framework.business.delegate.BusinessRollbackException;
import com.beetle.framework.business.delegate.IBusiness;
import com.beetle.framework.business.interrupt.ActionExecutor;
import com.beetle.framework.business.interrupt.ActionSignal;
import com.beetle.framework.business.service.IService;
import com.beetle.framework.business.service.Input;
import com.beetle.framework.business.service.Output;
import com.beetle.framework.business.service.ServiceException;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;

public class BusinessDelegateBean extends SessionEJBImp {
	private static SysLogger logger = SysLogger
			.getInstance(BusinessDelegateBean.class);
	private static ICache cacheSafeObj = new StrongCache();

	public BusinessDelegateBean() {
	}

	private static final long serialVersionUID = -19760224l;

	private static final void checkUrl(String businessURL) {
		if (businessURL == null) {
			throw new com.beetle.framework.AppRuntimeException(
					"the businessURL can not be null!");
		}
		try {
			if (!ReflectUtil.isContainMethod(Class.forName(businessURL),
					"execute")) {
				throw new com.beetle.framework.AppRuntimeException(
						"the class has not a execute method, is unlawful");
			}
		} catch (ClassNotFoundException ex) {
			throw new com.beetle.framework.AppRuntimeException(
					"the url is unlawful", ex);
		}
	}

	private static final Object getFromNative(String logicClass) {
		checkUrl(logicClass);
		Object localObject = null;
		try {
			localObject = ReflectUtil.newInstance(logicClass, null, null);
			return localObject;
		} catch (Exception t) {
			throw new com.beetle.framework.AppRuntimeException(
					"create service obj err!", t);
		}
	}

	public BsResponse executeBusinessWithTransaction(BsRequest params) {
		// begin point cut
		int procSignal = ActionExecutor.beginPointCutExecute(params, null);
		if (procSignal == ActionSignal.PROCESS_BREAK) {
			return new BsResponse();
		}
		// ////////////////////////////////////////////////////////////////
		BsResponse rd = null;
		try {
			IBusiness serviceObject = callServiceObj(params);
			rd = serviceObject.execute(params);
		} catch (BusinessException t) {
			this.setRollbackOnly();
			if (t instanceof BusinessRollbackException) {
				logger.info("rollback by hand!");
				BusinessRollbackException t2 = (BusinessRollbackException) t;
				return t2.getBs();
			} else {
				logger.error(t);
				return getErrResultObj(t.getMessage());
			}
		} catch (Exception e2) {
			this.setRollbackOnly();
			logger.error(e2);
			return getErrResultObj(e2.getMessage());
		}
		// ///////////////////////////////////////////
		ActionExecutor.endPointCutExecute(params, rd);
		return rd;
	}

	private final static BsResponse getErrResultObj(String errMsg) {
		BsResponse ro = new BsResponse();
		ro.setReturnFlag(BsResponse.FATAL_ERR_FLAG);
		ro.setReturnMsg(errMsg);
		return ro;
	}

	private final static IBusiness callServiceObj(BsRequest params) {
		IBusiness serviceObject = (IBusiness) cacheSafeObj.get(params
				.getBusinessURL());
		if (serviceObject == null) {
			serviceObject = (IBusiness) getFromNative(params.getBusinessURL());
			if (ReflectUtil.isThreadSafe(serviceObject.getClass())) {
				cacheSafeObj.put(params.getBusinessURL(), serviceObject);
			}
		}
		return serviceObject;
	}

	public BsResponse executeBusiness(BsRequest params) {
		// begin point cut
		int procSignal = ActionExecutor.beginPointCutExecute(params, null);
		if (procSignal == ActionSignal.PROCESS_BREAK) {
			return new BsResponse();
		}
		BsResponse rd = null;
		try {
			IBusiness serviceObject = callServiceObj(params);
			rd = serviceObject.execute(params);
		} catch (BusinessException t) {
			logger.error(t);
			return getErrResultObj(t.getMessage());
		}
		ActionExecutor.endPointCutExecute(params, rd); // end point cut
		return rd;
	}

	private final static IService genServiceObj(String srvId,
			String srvClassName) {
		IService serviceObject = (IService) cacheSafeObj.get(srvId);
		if (serviceObject == null) {
			serviceObject = (IService) getFromNative(srvClassName);
			if (ReflectUtil.isThreadSafe(serviceObject.getClass())) {
				cacheSafeObj.put(srvId, serviceObject);
			}
		}
		return serviceObject;
	}

	private final static Output getErrObj(String errMsg) {
		Output ro = new Output();
		ro.setReturnFlag(BsResponse.FATAL_ERR_FLAG);
		ro.setReturnMsg(errMsg);
		return ro;
	}

	public Output runServiceSupports(Input params) {
		String impclass = params.getValueAsString("imp_class_name");
		String srvid = params.getBusinessURL();
		IService is = genServiceObj(srvid, impclass);
		try {
			return is.execute(params);
		} catch (ServiceException ex) {
			this.setRollbackOnly();
			return getErrObj(ex.getMessage());
		} finally {
			/*
			 * if (params != null) { params.clear(); params = null; }
			 */
		}
	}

	public Output runServiceNotSupported(Input params) {
		String impclass = params.getValueAsString("imp_class_name");
		String srvid = params.getBusinessURL();
		IService is = genServiceObj(srvid, impclass);
		try {
			return is.execute(params);
		} catch (ServiceException ex) {// ...
			return getErrObj(ex.getMessage());
		} finally {
			/*
			 * if (params != null) { params.clear(); params = null; }
			 */
		}
	}

	public Output runServiceRequired(Input params) {
		return runServiceSupports(params);
	}
}

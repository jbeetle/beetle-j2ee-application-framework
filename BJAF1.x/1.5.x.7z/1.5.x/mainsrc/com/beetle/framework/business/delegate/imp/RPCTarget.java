/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp;

import java.net.MalformedURLException;

import com.beetle.framework.business.BusinessConfigReader;
import com.beetle.framework.business.common.rpcserver.IRpcService;
import com.beetle.framework.business.common.rpcserver.RpcClient;
import com.beetle.framework.business.common.rpcserver.RpcServerException;
import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.DelegateExecuteException;
import com.beetle.framework.business.delegate.IDelegateTarget;

public class RPCTarget
    implements IDelegateTarget {
  private String serviceName;
  private static IDelegateTarget instance = new RPCTarget();
  private RPCTarget() {
    serviceName = BusinessConfigReader.getDelegateLogicValue(
        "RPC_SERVICE_URL");
  }

  /**
   * executeBusiness
   *
   * @param params BsRequest
   * @return BsResponse
   * @throws DelegateExecuteException
   * @todo Implement this
   *   com.beetle.framework.business.delegate.IDelegateTarget method
   */
  public BsResponse executeBusiness(BsRequest params) throws
      DelegateExecuteException {
    IRpcService srv = null;
    try {
      srv = (IRpcService) RpcClient.getServiceObjectBackToClient(IRpcService.class,
          serviceName);
      Object obj = srv.perform(params, IRpcService.EXECUTE_WITHOUT_TRANSACTION);
      BsResponse response = (BsResponse) obj;
      return response;
    }
    catch (MalformedURLException ex1) {
      ex1.printStackTrace();
      throw new DelegateExecuteException(ex1);
    }
    catch (RpcServerException ex) {
      ex.printStackTrace();
      throw new DelegateExecuteException(ex);
    }
  }

  public static IDelegateTarget getInstance() {
    return instance;
  }

  public BsResponse executeBusinessWithTransaction(BsRequest params) throws
      DelegateExecuteException {
    IRpcService srv = null;
    try {
      srv = (IRpcService) RpcClient.getServiceObjectBackToClient(IRpcService.class,
          serviceName);
      Object obj = srv.perform(params, IRpcService.EXECUTE_WITH_TRANSACTION);
      BsResponse response = (BsResponse) obj;
      return response;
    }
    catch (MalformedURLException ex1) {
      ex1.printStackTrace();
      throw new DelegateExecuteException(ex1);
    }
    catch (RpcServerException ex) {
      ex.printStackTrace();
      throw new DelegateExecuteException(ex);
    }
  }
}

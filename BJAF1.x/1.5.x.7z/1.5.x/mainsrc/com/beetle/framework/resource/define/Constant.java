package com.beetle.framework.resource.define;

public class Constant {
	public static final String BUSINESS_CMD_TRANS = "BUSINESS_CMD_TRANS";
	public static final int COMMON_WATCHINFO_OBJECT_TYPE_TRANS = 10001;
}

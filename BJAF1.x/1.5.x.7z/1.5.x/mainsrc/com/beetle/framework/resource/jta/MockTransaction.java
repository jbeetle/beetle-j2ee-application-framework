package com.beetle.framework.resource.jta;

public class MockTransaction implements ITransaction {
	private MockTransaction() {
	}

	private static MockTransaction instance = new MockTransaction();

	public static MockTransaction getInstance() {
		return instance;
	}

	@Override
	public void begin() throws JTAException {
	}

	@Override
	public void commit() throws JTAException {
	}

	@Override
	public void rollback() throws JTAException {
	}

	@Override
	public void setRollbackOnly() throws JTAException {
	}

	@Override
	public int getStatus() throws JTAException {
		return 0;
	}

	@Override
	public void setTransactionTimeout(int timeout) throws JTAException {
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.resource;

/**
 * <p>Title: 框架设计</p>
 * <p>Description: 系统环境JNDI管理类</p>
 * <p>Copyright: Copyright (c) 2003</p>
 * <p>Company: 甲壳虫科技</p>
 * @author 余浩东
 * @version 1.0
 */
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.resource.define.CfgFileInfo;
import com.beetle.framework.util.OtherUtil;
import com.beetle.framework.util.ResourceLoader;
import com.beetle.framework.util.XMLProperties;

public class SysConfigReader {
	/**
	 * 根据属性id返回属性值
	 * 
	 * 
	 * @param 属性id
	 * @return 属性值
	 */
	private static Map<String, Map<?, ?>> containerTable = new HashMap<String, Map<?, ?>>(); 

	private static String sysconfigFileName = ResourceReader.getAPP_HOME()
			+ "config/SysConfig.xml";

	/**
	 * 获取容器相应的值
	 * 
	 * 
	 * @param tagname
	 *            --容器名称
	 * @param key
	 *            --值的名称
	 * @return
	 */
	public static String getContainValue(String tagname, String key) {
		if (!containerTable.containsKey(tagname)) {
			loadContainerTable(tagname);
		}
		Map<?, ?> m = (Map<?, ?>) containerTable.get(tagname);
		if (m == null) {
			return null;
		}
		return (String) m.get(key);
	}

	/**
	 * 获取容器定义的组的值
	 * 
	 * 
	 * @param tagname
	 *            --容器名称
	 * @return
	 */
	public static String getGroupNames(String tagname) {
		return getContainValue(tagname, "GROUP_NAMES");
	}

	public static void manualSetSysConfigFileName(String filename) {
		sysconfigFileName = filename;
	}

	/**
	 * 设置容器属性值
	 * 
	 * 
	 * @param tagname
	 *            --容器名称
	 * @param key
	 *            --属性名称
	 * 
	 * @throws Exception
	 */
	public static void setContainValue(String tagname, String key, String value)
			throws Exception {
		Document doc = XMLProperties.getXmlDoc(sysconfigFileName);
		Node node = doc.selectSingleNode(XMLProperties.convertPath(tagname));
		if (node != null) {
			Iterator it = node.selectNodes("item").iterator();
			while (it.hasNext()) {
				Element e = (Element) it.next();
				String id = e.valueOf("@name");
				if (id != null && id.equals(key)) {
					e.addAttribute("value", value);
					break;
				}
			}
		}
		File f = new File(sysconfigFileName);
		if (f.exists()) {
			OutputFormat format = OutputFormat.createPrettyPrint();
			FileOutputStream fos = new FileOutputStream(f);
			XMLWriter writer = new XMLWriter(fos, format);
			writer.write(doc);
			writer.close();
		} else {
			SysLogger.getInstance().error(SysConfigReader.class,
					"不支持jar包内xml文件修改");
		}
	}

	private static void markCfgInfo(File f, String filename) {
		String smfn = OtherUtil.removePath(filename);
		FrameworkContext ctx = FrameworkContext.getInstance();
		try {
			if (ctx.lookup(smfn) == null) {
				CfgFileInfo cfi = new CfgFileInfo();
				cfi.setFilename(smfn);
				cfi.setLastFileModifiedTime(f.lastModified());
				cfi.setLastReadTime(System.currentTimeMillis());
				cfi.setModifyCount(0);
				cfi.setPath(filename);
				ctx.bind(smfn, cfi);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 重置此文件
	 */
	public static void resetSysConfig() {
		synchronized (containerTable) {
			containerTable.clear();
			List l = getAllTagNameOfFile();
			for (int i = 0; i < l.size(); i++) {
				String s = (String) l.get(i);
				loadContainerTable(s);
			}
			l.clear();
		}
	}

	/**
	 * 获取此配置文件所有的标签名称
	 * 
	 * @return
	 */
	public static List getAllTagNameOfFile() {
		List names = new ArrayList();
		Document doc = null;
		try {
			doc = XMLProperties.getXmlDoc(sysconfigFileName);
		} catch (Exception e) {
			try {
				doc = XMLProperties.getXmlDoc("SysConfig.xml");
			} catch (Exception e1) {
				doc = null;
				e1.printStackTrace();
			}
		}
		if (doc != null) {
			List nodeList = doc.selectNodes("/Config/Containers/*");
			for (int i = 0; i < nodeList.size(); i++) {
				Node node = (Node) nodeList.get(i);
				names.add(node.getName());
			}
			nodeList.clear();
		}
		return names;
	}

	private static synchronized void loadContainerTable(String tagName) {
		Map m = null;
		File f = null;
		File f2 = null;
		f = new File(sysconfigFileName);
		if (f.exists()) {
			markCfgInfo(f, sysconfigFileName);
			m = XMLProperties.getProperties(sysconfigFileName,
					"Config.Containers." + tagName, "name", "value");
			SysLogger.getInstance().info(SysConfigReader.class,
					"from file:[" + f.getPath() + "]");
		} else {
			f2 = new File("SysConfig.xml");
			if (f2.exists()) {// 支持没有config的相对路径

				markCfgInfo(f2, "SysConfig.xml");
				m = XMLProperties.getProperties("SysConfig.xml",
						"Config.Containers." + tagName, "name", "value");
				SysLogger.getInstance().info(SysConfigReader.class,
						"from file:[" + f2.getPath() + "]");
			} else {
				try {
					m = XMLProperties.getProperties(
							ResourceLoader.getResAsStream(sysconfigFileName),
							"Config.Containers." + tagName, "name", "value");
					SysLogger.getInstance().info(
							SysConfigReader.class,
							"from resourceloader:["
									+ ResourceLoader.getClassLoader()
											.toString() + "]");
				} catch (IOException e) {
					try {
						m = XMLProperties
								.getProperties(ResourceLoader
										.getResAsStream("SysConfig.xml"),
										"Config.Containers." + tagName, "name",
										"value");
						SysLogger.getInstance().info(
								SysConfigReader.class,
								"from resourceloader:["
										+ ResourceLoader.getClassLoader()
												.toString() + "]");
					} catch (IOException e2) {
						e2.printStackTrace();
					}
				}
			}
		}
		if (m != null && !m.isEmpty()) {
			containerTable.put(tagName, m);
			// m.clear();
		}
		f = null;
		f2 = null;
	}

	// to test
	public static void main(String arg[]) throws Exception {
		// System.out.println(getContainValue("default", "URL_PKG_PREFIXES"));
		// setContainValue("xxx_name", "GROUP_NAMES", "cxcx");
		resetSysConfig();
		System.out.println(containerTable.size());
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.resource;

/**
 * 应用配置文件目录资源读取器
 * @author 余浩东（hdyu@beetlesoft.net）
 * @version 1.0
 */
import com.beetle.framework.AppProperties;

public final class ResourceReader {// extends PropertiesReader {
	private static String appHomePath = "";
	private static int resource_SYSCONFIG_MASK = 0;
	// private static String url = "com.beetle.framework.resource.resource";
	static {
		appHomePath = AppProperties.get("resource_APP_HOME", "");
		resource_SYSCONFIG_MASK = AppProperties.getAsInt(
				"resource_SYSCONFIG_MASK", 0);
	}

	public static int getSYSCONFIG_MASK() {
		return resource_SYSCONFIG_MASK;
	}

	public static void setSYSCONFIG_MASK(int sysconfig_mask) {
		resource_SYSCONFIG_MASK = sysconfig_mask;
	}

	public static String getResStr(String key) {
		// return ResourceReader.getValue(ResourceReader.getBundle(url), key);
		return AppProperties.get(key);
	}

	public static void setAPP_HOME(String app_home) {
		appHomePath = app_home;
	}

	public static String getAPP_HOME() {
		return appHomePath;
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access.operator;

/**
 * <p>Title: Beetle Persistence Framework</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: BeetleSoft</p>
 *
 * @author HenryYu (yuhaodong@gmail.com)
 * @version 1.0
 */
import java.util.List;

public interface ITableAccess {
	/**
	 * 通过主键查对应的记录对象
	 * 
	 * @param pk
	 *            主键对象
	 * @return 表对应的值对象
	 * @throws DBOperatorException
	 */
	Object selectByPrimaryKey(Object pk) throws DBOperatorException;

	/**
	 * 通过Where语句获查找表结果记录
	 * 
	 * @param whereStr
	 *            sql where条件语句
	 * @param Object
	 *            values[] 参数值，如果没有则可设置为空(null)
	 * @return List 表对应的值对象列表
	 * @throws DBOperatorException
	 */
	List selectByWhereCondition(String whereStr, Object values[])
			throws DBOperatorException;

	/**
	 * 插入一条记录
	 * 
	 * @param valueObject
	 *            表对应的值对象
	 * @throws DBOperatorException
	 */
	int insert(Object valueObject) throws DBOperatorException;

	/**
	 * 批量插入记录
	 * 
	 * @param valueObjectList
	 *            值对象列表,执行后此列表会自动清空
	 * @throws DBOperatorException
	 */
	int[] insertBatch(List valueObjectList) throws DBOperatorException;

	/**
	 * 通过主键删除记录
	 * 
	 * @param pk
	 *            Object
	 * @throws DBOperatorException
	 */
	int deleteByPrimaryKey(Object pk) throws DBOperatorException;

	/**
	 * 通过主键批量删除
	 * 
	 * @param pks
	 *            List
	 * @throws DBOperatorException
	 */
	int[] deleteBatchByPrimaryKey(List pks) throws DBOperatorException;

	/**
	 * 通过主键更新
	 * 
	 * @param valueObjectList
	 *            值对象列表
	 * @throws DBOperatorException
	 */
	int update(Object valueObject) throws DBOperatorException;

	/**
	 * 通过主键批量更新
	 * 
	 * @param valueObjectList
	 *            值对象列表
	 * @throws DBOperatorException
	 */
	int[] updateBatch(List valueObjectList) throws DBOperatorException;

	/**
	 * 生成表字段字符串
	 * 
	 * @return 格式：field1,field2,field3,...
	 */
	String generateFieldsString();

	/**
	 * 获取表名称
	 * 
	 * @return String
	 */
	String getTableName();

	/**
	 * 获取主键字段名称
	 * 
	 * @return String
	 */
	String getPrimaryKeyFieldName();
}

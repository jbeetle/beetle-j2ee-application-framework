package com.beetle.framework.persistence.storage.imp;

import java.io.File;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import jdbm.RecordManager;
import jdbm.RecordManagerFactory;
import jdbm.btree.BTree;
import jdbm.helper.StringComparator;
import jdbm.helper.Tuple;
import jdbm.helper.TupleBrowser;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.storage.IStorageAccess;
import com.beetle.framework.persistence.storage.StorageAccessException;
import com.beetle.framework.persistence.storage.StorageObj;
import com.beetle.framework.resource.ResourceReader;

public class PsDBMStorage implements IStorageAccess {
	private RecordManager recman;
	private String topPath = ResourceReader
			.getResStr("resource_STORAGE_SYSTEM");
	private String dbname = "StorageSystem";
	private String valueBtreerecname = "StorageObj_value";
	private String indexBtreecname = "StorageObj_index";
	private SysLogger logger;
	private BTree valuetree;
	private BTree indextree;
	private static PsDBMStorage instance = new PsDBMStorage();

	public static PsDBMStorage getInstance() {
		return instance;
	}

	private PsDBMStorage() {
		logger = SysLogger.getInstance(PsDBMStorage.class);
		// initRecMan();
	}

	private void initRecMan() {
		Properties props = new Properties();
		try {
			recman = RecordManagerFactory.createRecordManager(topPath + dbname,
					props);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
		}
	}

	public int create(StorageObj storageObj) {
		try {
			valuetree.insert(storageObj.getId(), storageObj.getObj(), true);
			StorageObj indexObj = new StorageObj();
			fillWeekObj(storageObj, indexObj);
			indextree.insert(indexObj.getId(), indexObj, true);
			indexObj = null;
			recman.commit();
			return 1;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}
	}

	private void fillWeekObj(StorageObj storageObj, StorageObj indexObj) {
		indexObj.setCreatetime(storageObj.getCreatetime());
		indexObj.setId(storageObj.getId());
		indexObj.setLasttime(storageObj.getLasttime());
		indexObj.setObjtype(storageObj.getObjtype());
		indexObj.setStatus(storageObj.getStatus());
		indexObj.setPlus(storageObj.getPlus());
	}

	public int[] createBatch(List storageObjList) {
		int a[] = { 1 };
		if (storageObjList != null && !storageObjList.isEmpty()) {
			try {
				for (int i = 0; i < storageObjList.size(); i++) {
					StorageObj o = (StorageObj) storageObjList.get(i);
					valuetree.insert(o.getId(), o.getObj(), true);
					StorageObj indexObj = new StorageObj();
					fillWeekObj(o, indexObj);
					indextree.insert(indexObj.getId(), indexObj, true);
					indexObj = null;
				}
				recman.commit();
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				a[0] = -1;
				return a;
			}
		}
		return a;
	}

	public void createIndex(String fieldName) {
		throw new AppRuntimeException("not supported!");
	}

	public int delete(String id) {
		try {
			Object o = valuetree.remove(id);
			indextree.remove(id);
			recman.commit();
			if (o == null) {
				return 0;
			} else {
				o = null;
				return 1;
			}
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}

	}

	// select id,createtime,lasttime,objtype,status,plus from storageobj where
	// id=?
	public int delete(String deleteExpression, Object[] values) {
		int dl = 0;
		List ls = parseExpress(deleteExpression, values);
		if (ls.size() == 0) {
			throw new StorageAccessException("not supported!");
		} else if (ls.size() == 1) {
			EPS eps = (EPS) ls.get(0);
			Tuple tuple = new Tuple();
			try {
				TupleBrowser browser = indextree.browse();
				while (browser.getNext(tuple)) {
					StorageObj so = (StorageObj) tuple.getValue();
					if (eps.getField().equalsIgnoreCase(fields[4])) {// status
						if (so.getStatus().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							indextree.remove(so.getId());
							valuetree.remove(so.getId());
						}
					} else if (eps.getField().equalsIgnoreCase(fields[3])) {// objtype
						if (so.getObjtype().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							indextree.remove(so.getId());
							valuetree.remove(so.getId());
						}
					} else if (eps.getField().equalsIgnoreCase(fields[0])) {// id
						if (indextree.find(eps.getValue()) != null) {
							indextree.remove(so.getId());
							valuetree.remove(so.getId());
						}
						break;
					} else if (eps.getField().equalsIgnoreCase(fields[1])) {// createtime
						if (so.getCreatetime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							indextree.remove(so.getId());
							valuetree.remove(so.getId());
						}
					} else if (eps.getField().equalsIgnoreCase(fields[2])) {// lasttime
						if (so.getLasttime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							indextree.remove(so.getId());
							valuetree.remove(so.getId());
						}
					} else {
						break;
					}
				}
			} catch (IOException e) {
				throw new StorageAccessException(e);
			} finally {
				ls.clear();
				try {
					recman.commit();
				} catch (IOException e) {
					//recman.rollback();
					throw new StorageAccessException(e);
				}
			}
		} else if (ls.size() == 2) {
			ls.clear();
			throw new StorageAccessException("not supported!");
		}
		return dl;
	}

	public int[] deleteBatch(List idList) {
		int r[] = { 0 };
		if (idList != null && !idList.isEmpty()) {
			try {
				for (int i = 0; i < idList.size(); i++) {
					String id = (String) idList.get(i);
					indextree.remove(id);
					valuetree.remove(id);
				}
				recman.commit();
				r[0] = 1;
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				r[0] = -1;
			}
		}
		return r;
	}

	public void dropIndex(String fieldName) {
		throw new AppRuntimeException("not supported!");
	}

	public synchronized void empty() {
		this.close();
		File f = new File(topPath + dbname + ".data");
		if (f.exists()) {
			f.delete();
		}
		File f2 = new File(topPath + dbname + ".log");
		if (f2.exists()) {
			f2.delete();
		}
		this.open();
	}

	public List filter(String filterExpression, Object[] values) {
		// id,createtime,lasttime,objtype,status,plus from storageobj
		// where status=?
		List res = new LinkedList();
		List ls = parseExpress(filterExpression, values);
		if (ls.size() == 0) {
			return res;
		} else if (ls.size() == 1) {
			EPS eps = (EPS) ls.get(0);
			Tuple tuple = new Tuple();
			try {
				TupleBrowser browser = indextree.browse();
				while (browser.getNext(tuple)) {
					StorageObj so = (StorageObj) tuple.getValue();
					if (eps.getField().equalsIgnoreCase(fields[4])) {// status
						if (so.getStatus().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[3])) {// objtype
						if (so.getObjtype().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[0])) {// id
						if (indextree.find(eps.getValue()) != null) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
						break;
					} else if (eps.getField().equalsIgnoreCase(fields[1])) {// createtime
						if (so.getCreatetime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[2])) {// lasttime
						if (so.getLasttime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
					} else {
						break;
					}
				}
			} catch (IOException e) {
				throw new StorageAccessException(e);
			} finally {
				ls.clear();
			}
		} else if (ls.size() == 2) {
			EPS eps0 = (EPS) ls.get(0);
			EPS eps1 = (EPS) ls.get(1);
			long begintime = ((Timestamp) eps0.getValue()).getTime();
			long endtime = ((Timestamp) eps1.getValue()).getTime();
			if (endtime > begintime) {
				Tuple tuple = new Tuple();
				try {
					TupleBrowser browser = indextree.browse();
					while (browser.getNext(tuple)) {
						StorageObj so = (StorageObj) tuple.getValue();
						long rectime = so.getCreatetime().getTime();
						if (rectime >= begintime && rectime <= endtime) {
							so.setObj(valuetree.find(so.getId()));
							res.add(so);
						}
					}
				} catch (IOException e) {
					throw new StorageAccessException(e);
				} finally {
					ls.clear();
				}
			}
		}
		return res;
	}

	public List filterByPage(String filterExpression, Object[] values,
			int pageNum, int pageSize) {
		throw new AppRuntimeException("not supported!");
	}

	private static final String[] fields = { "id", "createtime", "lasttime",
			"objtype", "status" };
	private static final String[] operates = { "=", ">=", "<=", ">", "<" };

	public int filterSize(String filterExpression, Object[] values) {
		// id,createtime,lasttime,objtype,status,plus from storageobj
		// where status=?
		int size = 0;
		List ls = parseExpress(filterExpression, values);
		if (ls.size() == 0) {
			return -1;
		} else if (ls.size() == 1) {
			EPS eps = (EPS) ls.get(0);
			Tuple tuple = new Tuple();
			try {
				TupleBrowser browser = indextree.browse();
				while (browser.getNext(tuple)) {
					StorageObj so = (StorageObj) tuple.getValue();
					if (eps.getField().equalsIgnoreCase(fields[4])) {// status
						if (so.getStatus().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							size = size + 1;
						}
					} else if (eps.getField().equalsIgnoreCase(fields[3])) {// objtype
						if (so.getObjtype().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							size = size + 1;
						}
					} else if (eps.getField().equalsIgnoreCase(fields[0])) {// id
						if (indextree.find(eps.getValue()) != null) {
							size = 1;
						} else {
							size = 0;
						}
						break;
					} else if (eps.getField().equalsIgnoreCase(fields[1])) {// createtime
						if (so.getCreatetime().getTime() == ((Timestamp) eps
								.getValue()).getTime()) {
							size = size + 1;
						}
					} else if (eps.getField().equalsIgnoreCase(fields[2])) {// lasttime
						if (so.getLasttime().getTime() == ((Timestamp) eps
								.getValue()).getTime()) {
							size = size + 1;
						}
					} else {
						size = 0;
						break;
					}
				}
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
			}
		} else if (ls.size() == 2) {
			EPS eps0 = (EPS) ls.get(0);
			EPS eps1 = (EPS) ls.get(1);
			long begintime = ((Timestamp) eps0.getValue()).getTime();
			long endtime = ((Timestamp) eps1.getValue()).getTime();
			if (endtime > begintime) {
				Tuple tuple = new Tuple();
				try {
					TupleBrowser browser = indextree.browse();
					int c1 = 0, c2 = 0, c3 = 0;
					while (browser.getNext(tuple)) {
						StorageObj so = (StorageObj) tuple.getValue();
						long rectime = so.getCreatetime().getTime();
						if (rectime == begintime) {
							c1 = c1 + 1;
						} else if (rectime == endtime) {
							c2 = c2 + 1;
						} else if (rectime > begintime && rectime < endtime) {
							c3 = c3 + 1;
						}
					}
					if (eps0.getOpt().equalsIgnoreCase(operates[1])
							&& eps1.getOpt().equalsIgnoreCase(operates[4])) {
						// >= and <
						size = c3 + c1;
					} else if (eps0.getOpt().equalsIgnoreCase(operates[1])
							&& eps1.getOpt().equalsIgnoreCase(operates[2])) {
						// >= and <=
						size = c2 + c1 + c3;
					} else if (eps0.getOpt().equalsIgnoreCase(operates[3])
							&& eps1.getOpt().equalsIgnoreCase(operates[4])) {
						// > and <
						size = c3;
					} else if (eps0.getOpt().equalsIgnoreCase(operates[3])
							&& eps1.getOpt().equalsIgnoreCase(operates[2])) {
						// > and <=
						size = c3 + c2;
					}
				} catch (IOException e) {
					logger.error(e.getMessage(), e);
				}
			}
		}
		ls.clear();
		return size;
	}

	public StorageObj peek(String id) {
		try {
			return (StorageObj) indextree.find(id);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public void rebuildIndex(String filedName) {
		throw new AppRuntimeException("not supported!");
	}

	public StorageObj retrieve(String id) {
		try {
			StorageObj so = (StorageObj) indextree.find(id);
			if (so != null) {
				so.setObj(valuetree.find(id));
			}
			return so;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return null;
		}
	}

	public int size() {
		return indextree.size();
	}

	public int update(StorageObj storageObj) {
		try {
			StorageObj so = (StorageObj) indextree.find(storageObj.getId());
			if (so == null) {
				return 0;
			}
			return create(storageObj);
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}
	}

	public List weakFilterByPage(String filterExpression, Object[] values,
			int pageNum, int pageSize) {
		throw new AppRuntimeException("not supported!");
	}

	public int weakUpdate(StorageObj storageObj) {
		try {
			StorageObj so = (StorageObj) indextree.find(storageObj.getId());
			if (so == null) {
				return 0;
			}
			StorageObj indexObj = new StorageObj();
			fillWeekObj(storageObj, indexObj);
			indextree.insert(indexObj.getId(), indexObj, true);
			indexObj = null;
			recman.commit();
			return 1;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}
	}

	public int[] weakUpdateBatch(List storageObjList) {
		int r[] = { 0 };
		if (storageObjList != null && !storageObjList.isEmpty()) {
			try {
				for (int i = 0; i < storageObjList.size(); i++) {
					StorageObj so = (StorageObj) storageObjList.get(i);
					StorageObj so2 = (StorageObj) indextree.find(so.getId());
					if (so2 == null) {
						continue;
					}
					StorageObj indexObj = new StorageObj();
					fillWeekObj(so, indexObj);
					indextree.insert(indexObj.getId(), indexObj, true);
					indexObj = null;
					so2 = null;
				}
				recman.commit();
				r[0] = 1;
			} catch (IOException e) {
				logger.error(e.getMessage(), e);
				r[0] = -1;
			}
		}
		return r;
	}

	public synchronized int close() {
		valuetree = null;
		indextree = null;
		if (recman != null) {
			// recman.commit();
			try {
				recman.close();
				if (logger.isDebugEnabled()) {
					logger.debug("Close ok");
				}
			} catch (IOException e) {
				e.printStackTrace();
				return -1;
			}
		}
		return 0;
	}

	public synchronized int open() {
		// try to reload an existing B+Tree
		initRecMan();
		try {
			long v_recid = recman.getNamedObject(this.valueBtreerecname);
			long i_recid = recman.getNamedObject(this.indexBtreecname);
			if (v_recid != 0 && i_recid != 0) {
				valuetree = BTree.load(recman, v_recid);
				indextree = BTree.load(recman, i_recid);
				if (logger.isDebugEnabled()) {
					logger.debug("Reloaded existing BTree with ["
							+ valuetree.size() + "] " + this.valueBtreerecname);
				}
			} else {
				// create a new B+Tree data structure and use a StringComparator
				// to order the records based on people's name.
				// tree = BTree.createInstance(recman, new ObjectBAComparator(
				// new StorageObjComparator()));
				valuetree = BTree
						.createInstance(recman, new StringComparator());
				recman.setNamedObject(valueBtreerecname, valuetree.getRecid());
				indextree = BTree
						.createInstance(recman, new StringComparator());
				recman.setNamedObject(indexBtreecname, indextree.getRecid());
				if (logger.isDebugEnabled()) {
					logger.debug("Created a new empty BTree");
				}
			}
			return 0;
		} catch (IOException e) {
			logger.error(e.getMessage(), e);
			return -1;
		}

	}

	private static String getOpt(String s, String f) {
		int i = s.indexOf(f);
		return s.substring(i + f.length()).trim();
	}

	private static class EPS {
		public String getField() {
			return field;
		}

		public void setField(String field) {
			this.field = field;
		}

		public String getOpt() {
			return opt;
		}

		public void setOpt(String opt) {
			this.opt = opt;
		}

		public Object getValue() {
			return value;
		}

		public void setValue(Object value) {
			this.value = value;
		}

		private String field;
		private String opt;
		private Object value;
	}

	private final static List parseExpress(String w, Object[] values) {
		w = w.toLowerCase();
		if (w.indexOf('?') == -1) {
			throw new AppRuntimeException("the [" + w
					+ "] expression not supported!");
		}
		String q[] = w.split("\\?");
		if (q.length > 2) {
			throw new AppRuntimeException("the [" + w
					+ "] expression not supported!");
		}
		List list = new ArrayList();
		if (q.length == 1) {
			for (int i = 0; i < fields.length; i++) {
				if (q[0].indexOf(fields[i]) > 0) {
					String opt = getOpt(q[0], fields[i]);
					if (opt.length() != 1 || opt.indexOf('=') == -1) {
						throw new AppRuntimeException("the [" + w
								+ "] expression not supported!");
					}
					EPS eps = new EPS();
					eps.setField(fields[i]);
					eps.setOpt(opt);
					eps.setValue(values[0]);
					list.add(eps);
					break;
				}
			}
		} else if (q.length == 2) {
			if (q[0].indexOf("createtime") == -1
					|| q[1].indexOf("createtime") == -1) {
				throw new AppRuntimeException("the [" + w
						+ "] expression not supported!");
			}
			EPS eps0 = new EPS();
			eps0.setField("createtime");
			eps0.setOpt(getOpt(q[0], "createtime"));
			eps0.setValue(values[0]);
			list.add(eps0);
			EPS eps1 = new EPS();
			eps1.setField("createtime");
			eps1.setOpt(getOpt(q[1], "createtime"));
			eps1.setValue(values[1]);
			list.add(eps1);
		}
		return list;
	}

	public List weakFilterByPage(String filterExpression, Object[] values)
			throws StorageAccessException {
		// id,createtime,lasttime,objtype,status,plus from storageobj
		// where status=?
		List res = new LinkedList();
		List ls = parseExpress(filterExpression, values);
		if (ls.size() == 0) {
			return res;
		} else if (ls.size() == 1) {
			EPS eps = (EPS) ls.get(0);
			Tuple tuple = new Tuple();
			try {
				TupleBrowser browser = indextree.browse();
				while (browser.getNext(tuple)) {
					StorageObj so = (StorageObj) tuple.getValue();
					if (eps.getField().equalsIgnoreCase(fields[4])) {// status
						if (so.getStatus().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[3])) {// objtype
						if (so.getObjtype().intValue() == ((Integer) eps
								.getValue()).intValue()) {
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[0])) {// id
						if (indextree.find(eps.getValue()) != null) {
							res.add(so);
						}
						break;
					} else if (eps.getField().equalsIgnoreCase(fields[1])) {// createtime
						if (so.getCreatetime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							res.add(so);
						}
					} else if (eps.getField().equalsIgnoreCase(fields[2])) {// lasttime
						if (so.getLasttime().getTime() >= ((Timestamp) eps
								.getValue()).getTime()) {
							res.add(so);
						}
					} else {
						break;
					}
				}
			} catch (IOException e) {
				throw new StorageAccessException(e);
			} finally {
				ls.clear();
			}
		} else if (ls.size() == 2) {
			EPS eps0 = (EPS) ls.get(0);
			EPS eps1 = (EPS) ls.get(1);
			long begintime = ((Timestamp) eps0.getValue()).getTime();
			long endtime = ((Timestamp) eps1.getValue()).getTime();
			if (endtime > begintime) {
				Tuple tuple = new Tuple();
				try {
					TupleBrowser browser = indextree.browse();
					while (browser.getNext(tuple)) {
						StorageObj so = (StorageObj) tuple.getValue();
						long rectime = so.getCreatetime().getTime();
						if (rectime >= begintime && rectime <= endtime) {
							res.add(so);
						}
					}
				} catch (IOException e) {
					throw new StorageAccessException(e);
				} finally {
					ls.clear();
				}
			}
		}
		return res;
	}
}

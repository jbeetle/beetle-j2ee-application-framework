/*
 * BJAF - Beetle J2EE Application Framework
 * �׿ǳ�J2EE��ҵӦ�ÿ������
 * ��Ȩ����2003-2009 ��ƶ� (www.beetlesoft.net)
 * 
 * ����һ����ѿ�Դ�������������ڡ��׿ǳ�J2EEӦ�ÿ�������ȨЭ�顷
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   ��GNU Lesser General Public License v3.0��
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>�ºϷ�ʹ�á��޸Ļ����·�����
 *
 * ��л��ʹ�á��ƹ㱾��ܣ����н�������⣬��ӭ�������ϵ��
 * �ʼ��� <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.storage.imp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.access.ConnectionException;
import com.beetle.framework.persistence.access.ConnectionFactory;
import com.beetle.framework.persistence.access.operator.DBOperatorException;
import com.beetle.framework.persistence.access.operator.QueryOperator;
import com.beetle.framework.persistence.access.operator.RsDataSet;
import com.beetle.framework.persistence.access.operator.SqlParameter;
import com.beetle.framework.persistence.access.operator.SqlParameterSet;
import com.beetle.framework.persistence.access.operator.UpdateOperator;
import com.beetle.framework.persistence.storage.IStorageAccess;
import com.beetle.framework.persistence.storage.StorageAccessException;
import com.beetle.framework.persistence.storage.StorageObj;
import com.beetle.framework.resource.ResourceReader;

/*
 create table storageobj (
 id varchar(100) not null,
 createtime timestamp, 
 lasttime timestamp,
 objtype integer,
 status integer,
 plus varchar(1000), 
 obj other
 );
 alter table storageobj add constraint primary_key_e primary key (id);
 */
public class PsH2Storage implements IStorageAccess {
	private SysLogger logger;
	private volatile static PsH2Storage instance = null;

	static class H2Pool {
		private static String initStr = null;
		private static String user = "yhd";
		private static String password = "19760224";
		private static String db_url = "/StorageSystem";

		public static Connection getConnection() throws ConnectionException {
			try {
				if (initStr == null) {
					initStr = initdriver();
				}
				return DriverManager.getConnection(initStr, user, password);
			} catch (Exception e) {
				e.printStackTrace();
				throw new ConnectionException(e.getMessage());
			}
		}

		private synchronized static String initdriver()
				throws InstantiationException, IllegalAccessException,
				ClassNotFoundException, SQLException {
			if (initStr != null) {
				return initStr;
			}
			org.h2.Driver.load();
			// Driver drv = (Driver)
			// Class.forName("org.h2.Driver").newInstance();
			// DriverManager.registerDriver(drv);
			String topPath = ResourceReader
					.getResStr("resource_STORAGE_SYSTEM");
			if (topPath == null || topPath.equals("")) {
				topPath = "storage";
			}
			return "jdbc:h2:" + topPath + db_url;
		}
	}

	public static PsH2Storage getInstance() {
		if (instance == null) {
			instance = new PsH2Storage();
		}
		return instance;
	}

	private PsH2Storage() {
		logger = SysLogger.getInstance(this.getClass());
		init();
	}

	private void init() {
		if (checkTableOK()) {
			logger.info("storage system is ok!");
		} else {
			logger.info("inital beetle storage system...");
			// callupdate("SET UNDO_LOG 0");
			callupdate("SET MAX_MEMORY_ROWS 1000");
			callupdate("SET MAX_MEMORY_UNDO 1000");
			callupdate("create table storageobj (id varchar(100) not null,createtime timestamp,lasttime timestamp,objtype integer,status integer,plus varchar(1000),obj other)");
			callupdate("alter table storageobj add constraint primary_key_e primary key (id)");
			callupdate("create index stg_status_index on storageobj(status)");
			callupdate("create index stg_createtime_index on storageobj(createtime)");
			logger.info("beetle storage system initialized.");
		}
	}

	private static void callupdate(String sql) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setPresentConnection(conn);
		uo.setUseOnlyConnectionFlag(true);
		uo.setSql(sql);
		try {
			uo.access();
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String insert_sql = "insert into storageobj (id,createtime,lasttime,objtype,status,plus,obj) values (?,?,?,?,?,?,?) ";

	public int create(StorageObj storageObj) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setPresentConnection(conn);
		uo.setUseOnlyConnectionFlag(true);
		uo.setSql(insert_sql);
		uo.addParameter(storageObj.getId());
		uo.addParameter(storageObj.getCreatetime());
		uo.addParameter(storageObj.getLasttime());
		uo.addParameter(storageObj.getObjtype());
		uo.addParameter(storageObj.getStatus());
		uo.addParameter(storageObj.getPlus());
		uo.addParameter(storageObj.getObj());
		try {
			uo.access();
			return uo.getEffectCounts();
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String delete_sql = "delete from storageobj where id=?";

	public int delete(String id) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setPresentConnection(conn);
		uo.setUseOnlyConnectionFlag(true);
		uo.setSql(delete_sql);
		uo.addParameter(id);
		try {
			uo.access();
			return uo.getEffectCounts();
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public List<StorageObj> filter(String filterExpression, Object[] values) {
		List<StorageObj> rd = new ArrayList<StorageObj>();
		Connection conn = H2Pool.getConnection();
		QueryOperator query = new QueryOperator();
		query.setPresentConnection(conn);
		query.setUseOnlyConnectionFlag(true);
		query.setSql("select * from storageobj " + filterExpression);
		int i = filterExpression.indexOf("?");
		if (i > 0) {
			for (int j = 0; j < values.length; j++) {
				query.addParameter(values[j]);
			}
		}
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				for (int ii = 0; ii < rs.rowCount; ii++) {
					StorageObj so = new StorageObj();
					rs.autoFillRow(so);
					rd.add(so);
					rs.next();
				}
				rs.clearAll();
			}
			return rd;
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String peek_sql = "select id,createtime,lasttime,objtype,status,plus from storageobj where id=?";

	public StorageObj peek(String id) {
		Connection conn = H2Pool.getConnection();
		QueryOperator query = new QueryOperator();
		query.setUseOnlyConnectionFlag(true);
		query.setPresentConnection(conn);
		query.setSql(peek_sql);
		query.addParameter(id);
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				StorageObj obj = new StorageObj();
				rs.autoFillRow(obj);
				rs.clearAll();
				return obj;
			} else {
				return null;
			}
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String retrieve_sql = "select id,createtime,lasttime,objtype,status,plus,obj from storageobj where id=?";

	public StorageObj retrieve(String id) {
		Connection conn = H2Pool.getConnection();
		QueryOperator query = new QueryOperator();
		query.setUseOnlyConnectionFlag(true);
		query.setPresentConnection(conn);
		query.setSql(retrieve_sql);
		query.addParameter(id);
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				StorageObj obj = new StorageObj();
				rs.autoFillRow(obj);
				rs.clearAll();
				return obj;
			} else {
				return null;
			}
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String size_sql = "select count(*) ct from storageobj ";

	private static boolean checkTableOK() {
		Connection conn = H2Pool.getConnection();
		QueryOperator qo = new QueryOperator();
		qo.setPresentConnection(conn);
		qo.setUseOnlyConnectionFlag(true);
		qo.setSql("select count(*) ct from information_schema.tables where table_name='STORAGEOBJ'");
		try {
			qo.access();
			RsDataSet rs = new RsDataSet(qo.getSqlResultSet());
			Long ct = rs.getFieldValueAsLong("ct");
			rs.clearAll();
			qo = null;
			if (ct.intValue() == 1) {
				return true;
			} else {
				return false;
			}
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public int size() {
		Connection conn = H2Pool.getConnection();
		QueryOperator qo = new QueryOperator();
		qo.setUseOnlyConnectionFlag(true);
		qo.setPresentConnection(conn);
		qo.setSql(size_sql);
		try {
			qo.access();
			RsDataSet rs = new RsDataSet(qo.getSqlResultSet());
			Long ct = rs.getFieldValueAsLong("ct");
			rs.clearAll();
			qo = null;
			return ct.intValue();
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String update_sql = "update storageobj set createtime=?,lasttime=?,status=?,plus=?,objtype=?,obj=? where id=?";

	public int update(StorageObj storageObj) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setUseOnlyConnectionFlag(true);
		uo.setPresentConnection(conn);
		uo.setSql(update_sql);
		uo.addParameter(storageObj.getCreatetime());
		uo.addParameter(storageObj.getLasttime());
		uo.addParameter(storageObj.getStatus());
		uo.addParameter(storageObj.getPlus());
		uo.addParameter(storageObj.getObjtype());
		uo.addParameter(storageObj.getObj());
		uo.addParameter(storageObj.getId());
		try {
			uo.access();
			int i = uo.getEffectCounts();
			uo = null;
			return i;
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private static final String wp_sql = "update storageobj set createtime=?,lasttime=?,status=?,plus=?,objtype=? where id=?";

	public int weakUpdate(StorageObj storageObj) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setUseOnlyConnectionFlag(true);
		uo.setPresentConnection(conn);
		uo.setSql(wp_sql);
		uo.addParameter(storageObj.getCreatetime());
		uo.addParameter(storageObj.getLasttime());
		uo.addParameter(storageObj.getStatus());
		uo.addParameter(storageObj.getPlus());
		uo.addParameter(storageObj.getObjtype());
		uo.addParameter(storageObj.getId());
		try {
			uo.access();
			int i = uo.getEffectCounts();
			uo = null;
			return i;
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public void empty() {
		callupdate("TRUNCATE TABLE storageobj");
	}

	public int filterSize(String filterExpression, Object[] values) {
		Connection conn = H2Pool.getConnection();
		QueryOperator query = new QueryOperator();
		query.setUseOnlyConnectionFlag(true);
		query.setPresentConnection(conn);
		query.setSql(size_sql + filterExpression);
		int i = filterExpression.indexOf("?");
		if (i > 0) {
			for (int j = 0; j < values.length; j++) {
				query.addParameter(values[j]);
			}
		}
		try {
			query.access();
			RsDataSet rs = new RsDataSet(query.getSqlResultSet());
			Long ct = rs.getFieldValueAsLong("ct");
			rs.clearAll();
			query = null;
			return ct.intValue();
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	private volatile static Connection queryWhole_conn = null;

	public List<StorageObj> filterByPage(String filterExpression,
			Object[] values, int pageNum, int pageSize) {
		// filterExpression=where objtype=? and status=?
		if (queryWhole_conn == null) {
			queryWhole_conn = H2Pool.getConnection();
		}
		List<StorageObj> l = new ArrayList<StorageObj>(pageSize);
		QueryOperator query = new QueryOperator();
		query.setUseOnlyConnectionFlag(true);
		query.setPresentConnection(queryWhole_conn);
		query.setSql("select id,createtime,lasttime,objtype,status,plus,obj from storageobj "
				+ filterExpression + " limit ?,?");
		if (values != null) {
			for (int i = 0; i < values.length; i++) {
				query.addParameter(new SqlParameter(values[i]));
			}
		}
		int pos = (pageNum - 1) * pageSize;
		query.addParameter(new SqlParameter(Integer.valueOf(pos)));
		query.addParameter(new SqlParameter(Integer.valueOf(pageSize)));
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				for (int i = 0; i < rs.rowCount; i++) {
					StorageObj sob = new StorageObj();
					sob.setCreatetime(rs.getFieldValueAsTimestamp("createtime"));
					sob.setId(rs.getFieldValueAsString("id"));
					sob.setLasttime(rs.getFieldValueAsTimestamp("lasttime"));
					sob.setObj(rs.getFieldValue("obj"));
					sob.setObjtype(rs.getFieldValueAsInteger("objtype"));
					sob.setPlus(rs.getFieldValueAsString("plus"));
					sob.setStatus(rs.getFieldValueAsInteger("status"));
					l.add(sob);
					rs.next();
				}
				rs.clearAll();
			}
		} catch (DBOperatorException e) {
			if (queryWhole_conn != null) {
				ConnectionFactory.closeConnection(queryWhole_conn);
				queryWhole_conn = null;
			}
		}
		return l;
	}

	public List<StorageObj> weakFilterByPage(String filterExpression,
			Object[] values, int pageNum, int pageSize) {
		List<StorageObj> l = new ArrayList<StorageObj>(pageSize);
		if (queryWhole_conn == null) {
			queryWhole_conn = H2Pool.getConnection();
		}
		QueryOperator query = new QueryOperator();
		query.setPresentConnection(queryWhole_conn);
		query.setUseOnlyConnectionFlag(true);
		query.setSql("select id,createtime,lasttime,objtype,status,plus from storageobj "
				+ filterExpression + " limit ?,?");
		if (values != null) {
			for (int i = 0; i < values.length; i++) {
				query.addParameter(new SqlParameter(values[i]));
			}
		}
		int pos = (pageNum - 1) * pageSize;
		query.addParameter(new SqlParameter(Integer.valueOf(pos)));
		query.addParameter(new SqlParameter(Integer.valueOf(pageSize)));
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				for (int i = 0; i < rs.rowCount; i++) {
					StorageObj sob = new StorageObj();
					sob.setCreatetime(rs.getFieldValueAsTimestamp("createtime"));
					sob.setId(rs.getFieldValueAsString("id"));
					sob.setLasttime(rs.getFieldValueAsTimestamp("lasttime"));
					sob.setObjtype(rs.getFieldValueAsInteger("objtype"));
					sob.setPlus(rs.getFieldValueAsString("plus"));
					sob.setStatus(rs.getFieldValueAsInteger("status"));
					l.add(sob);
					rs.next();
				}
				rs.clearAll();
			}
		} catch (DBOperatorException e) {
			if (queryWhole_conn != null) {
				ConnectionFactory.closeConnection(queryWhole_conn);
				queryWhole_conn = null;
			}
		}
		return l;
	}

	public int delete(String deleteExpression, Object[] values) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator uo = new UpdateOperator();
		uo.setPresentConnection(conn);
		uo.setUseOnlyConnectionFlag(true);
		uo.setSql("delete from storageobj " + deleteExpression);
		int i = deleteExpression.indexOf("?");
		if (i > 0) {
			for (int j = 0; j < values.length; j++) {
				uo.addParameter(values[j]);
			}
		}
		try {
			uo.access();
			int k = uo.getEffectCounts();
			uo = null;
			return k;
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public void createIndex(String fieldName) {
		callupdate("create index stg_" + fieldName + "_index on storageobj("
				+ fieldName + ")");
	}

	public void dropIndex(String fieldName) {
		callupdate("drop index stg_" + fieldName + "_index");
	}

	public void rebuildIndex(String filedName) {
		dropIndex(filedName);
		createIndex(filedName);
	}

	public int[] createBatch(List<StorageObj> storageObjList) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator update = new UpdateOperator();
		update.setPresentConnection(conn);
		update.setUseOnlyConnectionFlag(true);
		update.setSql(insert_sql);
		for (int i = 0; i < storageObjList.size(); i++) {
			StorageObj storageObj = storageObjList.get(i);
			SqlParameterSet r = new SqlParameterSet();
			//
			r.addParameter(storageObj.getId());
			r.addParameter(storageObj.getCreatetime());
			r.addParameter(storageObj.getLasttime());
			r.addParameter(storageObj.getObjtype());
			r.addParameter(storageObj.getStatus());
			r.addParameter(storageObj.getPlus());
			r.addParameter(storageObj.getObj());
			//
			update.addBatchParameter(r);
		}
		try {
			update.access();
			return update.getBatchEffectCounts();
		} catch (DBOperatorException ex) {
			throw new DBOperatorException(ex);
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public int[] deleteBatch(List<String> idList) {
		Connection cnn = H2Pool.getConnection();
		try {
			UpdateOperator uo = new UpdateOperator();
			uo.setPresentConnection(cnn);
			uo.setUseOnlyConnectionFlag(true);
			uo.setSql("delete from storageobj where id=?");
			for (int i = 0; i < idList.size(); i++) {
				SqlParameterSet r = new SqlParameterSet();
				r.addParameter(idList.get(i));
				uo.addBatchParameter(r);
			}
			uo.access();
			return uo.getBatchEffectCounts();
		} catch (Exception e) {
			throw new DBOperatorException(e);
		} finally {
			ConnectionFactory.closeConnection(cnn);
		}
		// return table.deleteBatchByPrimaryKey(idList);
	}

	public int[] weakUpdateBatch(List<StorageObj> storageObjList) {
		Connection conn = H2Pool.getConnection();
		UpdateOperator update = new UpdateOperator();
		update.setPresentConnection(conn);
		update.setUseOnlyConnectionFlag(true);
		update.setSql(wp_sql);
		for (int i = 0; i < storageObjList.size(); i++) {
			StorageObj storageObj = storageObjList.get(i);
			SqlParameterSet r = new SqlParameterSet();
			//
			r.addParameter(storageObj.getCreatetime());
			r.addParameter(storageObj.getLasttime());
			r.addParameter(storageObj.getStatus());
			r.addParameter(storageObj.getPlus());
			r.addParameter(storageObj.getObjtype());
			r.addParameter(storageObj.getId());
			//
			update.addBatchParameter(r);
		}
		try {
			update.access();
			return update.getBatchEffectCounts();
		} catch (DBOperatorException ex) {
			throw new DBOperatorException(ex);
		} finally {
			ConnectionFactory.closeConnection(conn);
		}
	}

	public int close() {
		// 每次操作一个连接，无需管理
		return 0;
	}

	public int open() {
		// 每次操作一个连接，无需管理
		return 0;
	}

	public List<StorageObj> weakFilterByPage(String filterExpression,
			Object[] values) throws StorageAccessException {
		List<StorageObj> l = new ArrayList<StorageObj>();
		if (queryWhole_conn == null) {
			queryWhole_conn = H2Pool.getConnection();
		}
		QueryOperator query = new QueryOperator();
		query.setPresentConnection(queryWhole_conn);
		query.setUseOnlyConnectionFlag(true);
		query.setSql("select id,createtime,lasttime,objtype,status,plus from storageobj "
				+ filterExpression);
		if (values != null) {
			for (int i = 0; i < values.length; i++) {
				query.addParameter(new SqlParameter(values[i]));
			}
		}
		try {
			query.access();
			if (query.resultSetAvailable()) {
				RsDataSet rs = new RsDataSet(query.getSqlResultSet());
				for (int i = 0; i < rs.rowCount; i++) {
					StorageObj sob = new StorageObj();
					sob.setCreatetime(rs.getFieldValueAsTimestamp("createtime"));
					sob.setId(rs.getFieldValueAsString("id"));
					sob.setLasttime(rs.getFieldValueAsTimestamp("lasttime"));
					sob.setObjtype(rs.getFieldValueAsInteger("objtype"));
					sob.setPlus(rs.getFieldValueAsString("plus"));
					sob.setStatus(rs.getFieldValueAsInteger("status"));
					l.add(sob);
					rs.next();
				}
				rs.clearAll();
			}
		} catch (DBOperatorException e) {
			if (queryWhole_conn != null) {
				ConnectionFactory.closeConnection(queryWhole_conn);
				queryWhole_conn = null;
			}
		}
		return l;
	}

}

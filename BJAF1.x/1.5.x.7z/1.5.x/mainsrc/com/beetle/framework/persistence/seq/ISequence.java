/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.seq;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: 序列号接口
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东
 * @version 1.0
 */
public interface ISequence {
	public static final int IMP_TYPE_COMMON = 1;

	public static final int IMP_TYPE_ORACLE = 2;

	public static final int IMP_TYPE_DB2 = 3;
	
	public static final int IMP_TYPE_POSTGRESQL = 4;

	public static final int IMP_TYPE_OTHER = 10;

	/**
	 * 返回数据库系统下一个序列号码
	 * 
	 * @param seqtype
	 *            SeqType序列号输入参数对象
	 * @return long
	 */
	long nextSequenceNum(SeqType seqtype);

	/**
	 * 返回实现类型
	 * 
	 * @return int
	 */
	int getImpType();

	/**
	 * 按Long类型返回序列
	 * 
	 * @param seqtype
	 *            序列类型
	 * @return Long
	 */
	Long nextSequenceNumAsLong(SeqType seqtype);

	/**
	 * 初始化序列的开始值
	 * 
	 * @param initValue
	 *            初始值
	 */
	void initSequenceValue(int initValue, SeqType seqtype);
}

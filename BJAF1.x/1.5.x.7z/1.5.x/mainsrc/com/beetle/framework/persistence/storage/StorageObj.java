/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.storage;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 * 存储数据对象类
 * 
 * @author YUHAODONG yuhaodong@gmail.com
 * 
 */
public class StorageObj implements Serializable {

	public String toString() {
		return "StorageObj [createtime=" + createtime + ", id=" + id
				+ ", lasttime=" + lasttime + ", obj=" + obj + ", objtype="
				+ objtype + ", plus=" + plus + ", status=" + status + "]";
	}

	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((createtime == null) ? 0 : createtime.hashCode());
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result
				+ ((lasttime == null) ? 0 : lasttime.hashCode());
		result = prime * result + ((obj == null) ? 0 : obj.hashCode());
		result = prime * result + ((objtype == null) ? 0 : objtype.hashCode());
		result = prime * result + ((plus == null) ? 0 : plus.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StorageObj other = (StorageObj) obj;
		if (createtime == null) {
			if (other.createtime != null)
				return false;
		} else if (!createtime.equals(other.createtime))
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lasttime == null) {
			if (other.lasttime != null)
				return false;
		} else if (!lasttime.equals(other.lasttime))
			return false;
		if (this.obj == null) {
			if (other.obj != null)
				return false;
		} else if (!this.obj.equals(other.obj))
			return false;
		if (objtype == null) {
			if (other.objtype != null)
				return false;
		} else if (!objtype.equals(other.objtype))
			return false;
		if (plus == null) {
			if (other.plus != null)
				return false;
		} else if (!plus.equals(other.plus))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -6623127328064493348L;
	/**
	 * 对象唯一标识（要保证在整个存储文件系统中唯一）
	 */
	private String id;
	/**
	 * 对象创建时间
	 */
	private Timestamp createtime;
	/**
	 * 对象最后修改时间
	 */
	private Timestamp lasttime;
	/**
	 * 对象操作状态位（数值可根据需要自行定义）
	 */
	private Integer status;
	/**
	 * 对象附加信息
	 */
	private String plus;
	/**
	 * 要存储的具体数据对象
	 */
	private Object obj;
	/**
	 * 对象类型
	 */
	private Integer objtype;

	public Integer getObjtype() {
		return objtype;
	}

	public void setObjtype(Integer objtype) {
		this.objtype = objtype;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Timestamp getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Timestamp createtime) {
		this.createtime = createtime;
	}

	public Timestamp getLasttime() {
		return lasttime;
	}

	public void setLasttime(Timestamp lasttime) {
		this.lasttime = lasttime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getPlus() {
		return plus;
	}

	public void setPlus(String plus) {
		this.plus = plus;
	}

	public Object getObj() {
		return obj;
	}

	public void setObj(Object obj) {
		this.obj = obj;
	}
}

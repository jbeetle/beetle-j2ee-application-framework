/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access.datasource;

import java.security.InvalidParameterException;
import java.sql.Connection;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.EmptyStackException;
import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.access.ConnectionException;
import com.beetle.framework.persistence.access.IConnPool;

/**
 * 通用连接池，依赖与相应的数据库驱动是否有pool(ConnectionPoolDataSource接口)的实现，<br>
 * 此连接池 只是一个面板<br>
 * 
 * @author HenryYu
 * 
 */
public class CommonPool implements IConnPool {
	/**
	 * A simple standalone JDBC connection pool manager.
	 * <p>
	 * The public methods of this class are thread-safe.
	 * <p>
	 * Author: Christian d'Heureuse (<a
	 * href="http://www.source-code.biz">www.source-code.biz</a>)<br>
	 * Multi-licensed: EPL/LGPL/MPL.
	 * <p>
	 * 2007-06-21: Constructor with a timeout parameter added.<br>
	 * 2008-05-03: Additional licenses added (EPL/MPL). 2009-06-24 Daniel
	 * Jurado: Changed from a Stack to a Queue so it is possible do recycle more
	 * efficiently.<br>
	 * 2009-06-25 Daniel Jurado: Timeout to handle and idle connection.<br>
	 * 2009-12-07 Carlos Vizcaino: Shutting timer on dispose, timer was
	 * preventing Tomcat from shutting down within 60 secs.<br>
	 * 2010-06-12 Christian d'Heureuse (thanks to Tal Liron): Timer task changed
	 * to use Iterator.remove() instead of LinkedList.remove() to prevent
	 * ConcurrentModificationException.
	 */
	static class MiniConnectionPoolManager {

		/**
		 * Object to hold the Connection under the queue, with a TimeStamp.
		 * 
		 * @author Daniel Jurado
		 */
		private class PCTS implements Comparable<PCTS> {
			private PooledConnection pconn;
			private Calendar timeStamp;

			private PooledConnection getPConn() {
				return this.pconn;
			}

			private Calendar getTimeStamp() {
				return this.timeStamp;
			}

			private PCTS(PooledConnection pconn) {
				this.timeStamp = Calendar.getInstance();
				this.pconn = pconn;
			}

			/*
			 * (non-Javadoc)
			 * 
			 * @see java.lang.Comparable#compareTo(java.lang.Object)
			 */
			@Override
			public int compareTo(PCTS other) {
				return (int) (other.getTimeStamp().getTimeInMillis() - this
						.getTimeStamp().getTimeInMillis());
			}
		}

		private class PoolConnectionEventListener implements
				ConnectionEventListener {
			public void connectionClosed(ConnectionEvent event) {
				PooledConnection pconn = (PooledConnection) event.getSource();
				pconn.removeConnectionEventListener(this);
				recycleConnection(pconn);
			}

			public void connectionErrorOccurred(ConnectionEvent event) {
				PooledConnection pconn = (PooledConnection) event.getSource();
				pconn.removeConnectionEventListener(this);
				disposeConnection(pconn);
			}
		}

		/**
		 * Looks for recycled connections older than the specified seconds.
		 * 
		 * @author Daniel Jurado
		 * 
		 */
		private class ConnectionMonitor extends TimerTask {
			private MiniConnectionPoolManager owner;

			private ConnectionMonitor(MiniConnectionPoolManager owner) {
				this.owner = owner;
			}

			@Override
			public void run() {
				Calendar now = Calendar.getInstance();
				synchronized (owner) {
					Iterator<PCTS> iterator = recycledConnections.iterator();
					while (iterator.hasNext()) {
						PCTS pcts = iterator.next();
						int delta = (int) ((now.getTimeInMillis() - pcts
								.getTimeStamp().getTimeInMillis()) / 1000);
						if (delta >= maxIdleConnectionLife) {
							closeConnectionNoEx(pcts.getPConn());
							iterator.remove();
						}
					}
				}
			}
		}

		/**
		 * Thrown in {@link #getConnection()} when no free connection becomes
		 * available within <code>timeout</code> seconds.
		 */
		public static class TimeoutException extends RuntimeException {
			private static final long serialVersionUID = 1;

			public TimeoutException() {
				super("Timeout while waiting for a free database connection.");
			}
		}

		private ConnectionPoolDataSource dataSource;
		private int maxConnections;
		private int maxIdleConnectionLife;
		private int timeout;
		private Semaphore semaphore;
		private Queue<PCTS> recycledConnections;
		private int activeConnections;

		private PoolConnectionEventListener poolConnectionEventListener;

		private boolean isDisposed;

		private Timer timer;

		/**
		 * Constructs a MiniConnectionPoolManager object with a timeout of 60
		 * seconds and 60 seconds of max idle connection life.
		 * 
		 * @param dataSource
		 *            the data source for the connections.
		 * @param maxConnections
		 *            the maximum number of connections.
		 */
		public MiniConnectionPoolManager(ConnectionPoolDataSource dataSource,
				int maxConnections) {
			this(dataSource, maxConnections, 60, 60);
		}

		/**
		 * Constructs a MiniConnectionPoolManager object.
		 * 
		 * @param dataSource
		 *            the data source for the connections.
		 * @param maxConnections
		 *            the maximum number of connections.
		 * @param timeout
		 *            the maximum time in seconds to wait for a free connection.
		 * @param maxIdleConnectionLife
		 *            the maximum time in seconds to keep an idle connection to
		 *            wait to be used.
		 */
		public MiniConnectionPoolManager(ConnectionPoolDataSource dataSource,
				int maxConnections, int timeout, int maxIdleConnectionLife) {
			if (dataSource == null)
				throw new InvalidParameterException("dataSource cant be null");
			if (maxConnections < 1)
				throw new InvalidParameterException(
						"maxConnections must be > 1");
			if (timeout < 1)
				throw new InvalidParameterException("timeout must be > 1");
			if (maxIdleConnectionLife < 1)
				throw new InvalidParameterException(
						"maxIdleConnectionLife must be > 1");

			this.dataSource = dataSource;
			this.maxConnections = maxConnections;
			this.maxIdleConnectionLife = maxIdleConnectionLife;
			this.timeout = timeout;
			semaphore = new Semaphore(maxConnections, true);
			recycledConnections = new PriorityQueue<PCTS>();
			poolConnectionEventListener = new PoolConnectionEventListener();

			// start the monitor
			timer = new Timer(getClass().getSimpleName(), true);
			timer.schedule(new ConnectionMonitor(this),
					this.maxIdleConnectionLife, this.maxIdleConnectionLife);
		}

		private void assertInnerState() {
			if (activeConnections < 0)
				throw new AssertionError();
			if (activeConnections + recycledConnections.size() > maxConnections)
				throw new AssertionError();
			if (activeConnections + semaphore.availablePermits() > maxConnections)
				throw new AssertionError();
		}

		private void closeConnectionNoEx(PooledConnection pconn) {
			try {
				pconn.close();
			} catch (SQLException e) {
				log("Error while closing database connection: " + e.toString());
			}
		}

		/**
		 * Closes all unused pooled connections.
		 */
		public synchronized void dispose() throws SQLException {
			if (isDisposed)
				return;
			isDisposed = true;
			SQLException e = null;
			while (!recycledConnections.isEmpty()) {
				PCTS pcts = recycledConnections.poll();
				if (pcts == null)
					throw new EmptyStackException();
				PooledConnection pconn = pcts.getPConn();
				try {
					pconn.close();
				} catch (SQLException e2) {
					if (e == null)
						e = e2;
				}
			}
			timer.cancel();
			if (e != null)
				throw e;
		}

		private synchronized void disposeConnection(PooledConnection pconn) {
			if (activeConnections < 0)
				throw new AssertionError();
			activeConnections--;
			semaphore.release();
			closeConnectionNoEx(pconn);
			assertInnerState();
		}

		/**
		 * Returns the number of active (open) connections of this pool. This is
		 * the number of <code>Connection</code> objects that have been issued
		 * by {@link #getConnection()} for which <code>Connection.close()</code>
		 * has not yet been called.
		 * 
		 * @return the number of active connections.
		 **/
		public synchronized int getActiveConnections() {
			return activeConnections;
		}

		/**
		 * Retrieves a connection from the connection pool. If
		 * <code>maxConnections</code> connections are already in use, the
		 * method waits until a connection becomes available or
		 * <code>timeout</code> seconds elapsed. When the application is
		 * finished using the connection, it must close it in order to return it
		 * to the pool.
		 * 
		 * @return a new Connection object.
		 * @throws TimeoutException
		 *             when no connection becomes available within
		 *             <code>timeout</code> seconds.
		 */
		public Connection getConnection() throws SQLException {
			// This routine is unsynchronized, because semaphore.tryAcquire()
			// may
			// block.
			synchronized (this) {
				if (isDisposed)
					throw new IllegalStateException(
							"Connection pool has been disposed.");
			}
			try {
				if (!semaphore.tryAcquire(timeout, TimeUnit.SECONDS))
					throw new TimeoutException();
			} catch (InterruptedException e) {
				throw new RuntimeException(
						"Interrupted while waiting for a database connection.",
						e);
			}
			boolean ok = false;
			try {
				Connection conn = getConnection2();
				ok = true;
				return conn;
			} finally {
				if (!ok)
					semaphore.release();
			}
		}

		private synchronized Connection getConnection2() throws SQLException {
			if (isDisposed)
				throw new IllegalStateException(
						"Connection pool has been disposed."); // test again
																// with
			// lock
			PooledConnection pconn;
			if (recycledConnections.size() > 0) {
				PCTS pcts = recycledConnections.poll();
				if (pcts == null)
					throw new EmptyStackException();
				pconn = pcts.getPConn();

			} else {
				pconn = dataSource.getPooledConnection();
			}
			Connection conn = pconn.getConnection();
			activeConnections++;
			pconn.addConnectionEventListener(poolConnectionEventListener);
			assertInnerState();
			return conn;
		}

		private void log(String msg) {
			SysLogger.getInstance(getClass()).error(msg);
		}

		private synchronized void recycleConnection(PooledConnection pconn) {
			if (isDisposed) {
				disposeConnection(pconn);
				return;
			}
			if (activeConnections <= 0)
				throw new AssertionError();
			activeConnections--;
			semaphore.release();
			recycledConnections.add(new PCTS(pconn));
			assertInnerState();
		}
	}

	private MiniConnectionPoolManager pool;
	private String driverName;
	private String conURL;
	private String username;
	private String password;
	private int min, max;
	private String testSql;

	public int getMax() {
		return max;
	}

	public int getMin() {
		return min;
	}

	public String getTestSql() {
		return testSql;
	}

	@Override
	public Connection getConnection() throws ConnectionException {
		try {
			return this.pool.getConnection();
		} catch (SQLException e) {
			throw new ConnectionException(e);
		}
	}

	@Override
	public void closeAllConnections() {
		throw new AppRuntimeException("not supported yet!");
	}

	@Override
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	@Override
	public void setConURL(String conURL) {
		this.conURL = conURL;
	}

	@Override
	public void setUsername(String username) {
		this.username = username;
	}

	@Override
	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public void setMin(int min) {
		this.min = min;

	}

	@Override
	public void setTestSql(String testSql) {
		this.testSql = testSql;

	}

	@Override
	public void setMax(int max) {
		this.max = max;

	}

	@Override
	public void start() {
		if (this.pool == null) {
			if (driverName == null || driverName.trim().length() == 0) {
				throw new AppRuntimeException("driverName can't be null!");
			}
			try {
				ConnectionPoolDataSource cpds = null;
				driverName = driverName.trim();
				if (driverName.startsWith("oracle.jdbc")) {
					oracle.jdbc.pool.OracleConnectionPoolDataSource cpdstmp = new oracle.jdbc.pool.OracleConnectionPoolDataSource();
					cpdstmp.setURL(conURL);
					cpdstmp.setUser(username);
					cpdstmp.setPassword(password);
					cpdstmp.setDriverType("thin");
					cpds = cpdstmp;
				} else if (driverName.startsWith("net.sourceforge.jtds")) {
					net.sourceforge.jtds.jdbcx.JtdsDataSource tmp = new net.sourceforge.jtds.jdbcx.JtdsDataSource();
					tmp.setUser(username);
					tmp.setPassword(password);
					//
					net.sourceforge.jtds.jdbc.Driver dr = new net.sourceforge.jtds.jdbc.Driver();
					DriverPropertyInfo di[] = dr.getPropertyInfo(conURL, null);
					for (int i = 0; i < di.length; i++) {
						DriverPropertyInfo d = di[i];
						if (d.name.equals("SERVERTYPE")) {
							tmp.setServerType(Integer.parseInt(d.value));
						} else if (d.name.equals("DATABASENAME")) {
							tmp.setDatabaseName(d.value);
						} else if (d.name.equals("SERVERNAME")) {
							tmp.setServerName(d.value);
						} else if (d.name.equals("PORTNUMBER")) {
							tmp.setPortNumber(Integer.parseInt(d.value));
						}
					}
					cpds = tmp;
					//
				} else if (driverName.startsWith("com.microsoft.sqlserver")) {
					// The sqljdbc 1.1 documentation, chapter
					// "Using Connection Pooling", recommends to use
					// SQLServerXADataSource
					// instead of SQLServerConnectionPoolDataSource.
					com.microsoft.sqlserver.jdbc.SQLServerXADataSource tmp = new com.microsoft.sqlserver.jdbc.SQLServerXADataSource();
					tmp.setURL(conURL);
					tmp.setUser(username);
					tmp.setPassword(password);
					cpds = tmp;
				} else if (driverName.startsWith("com.mysql.jdbc")) {
					com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSource tmp = new com.mysql.jdbc.jdbc2.optional.MysqlConnectionPoolDataSource();
					tmp.setUrl(conURL);
					tmp.setUser(username);
					tmp.setPassword(password);
					cpds = tmp;
				} else if (driverName.startsWith("org.h2")) {
					org.h2.jdbcx.JdbcDataSource tmp = new org.h2.jdbcx.JdbcDataSource();
					tmp.setUser(username);
					tmp.setPassword(password);
					tmp.setURL(conURL);
					cpds = tmp;
				} else {
					throw new AppRuntimeException("sorry,not support ["
							+ driverName + "]yet!");
				}
				this.pool = new MiniConnectionPoolManager(cpds, max, 60, 60);
			} catch (Exception e) {
				throw new AppRuntimeException(e);
			}
		}
	}

	@Override
	public void shutdown() {
		if (pool != null) {
			try {
				pool.dispose();
			} catch (SQLException e) {
				throw new AppRuntimeException(e);
			}
		}
	}

}

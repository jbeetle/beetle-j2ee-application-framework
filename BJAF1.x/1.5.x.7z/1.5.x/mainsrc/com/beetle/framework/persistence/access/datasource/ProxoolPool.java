/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.transaction.TransactionManager;

import org.logicalcobwebs.proxool.ProxoolException;
import org.logicalcobwebs.proxool.ProxoolFacade;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.persistence.access.ConnectionException;
import com.beetle.framework.persistence.access.IConnPool;

public class ProxoolPool implements IConnPool {
	private String alias2;
	private Properties info;
	private String poolurl;

	public ProxoolPool(int max, int min, String driverName, String conURL,
			String username, String password, String alias, String testSql) {
		this.alias2 = "proxool." + alias;
		info = new Properties();
		info.setProperty("proxool.maximum-connection-count",
				String.valueOf(max));
		info.setProperty("proxool.minimum-connection-count",
				String.valueOf(min));
		if (testSql != null && testSql.length() > 1) {
			info.setProperty("proxool.house-keeping-test-sql", testSql);
		}
		info.setProperty("user", username);
		info.setProperty("password", password);
		poolurl = "proxool." + alias + ":" + driverName + ":" + conURL;
		try {
			Class.forName("org.logicalcobwebs.proxool.ProxoolDriver");
			ProxoolFacade.registerConnectionPool(poolurl, info);
		} catch (Exception e) {
			e.printStackTrace();
			throw new AppRuntimeException(e);
		}

	}

	public void closeAllConnections() {
		try {
			ProxoolFacade.killAllConnections(this.alias2, "kill it by hand");
		} catch (ProxoolException e) {
			e.printStackTrace();
		}

	}

	protected void finalize() throws Throwable {
		this.closeAllConnections();
		ProxoolFacade.removeConnectionPool(this.alias2);
		super.finalize();
	}

	public Connection getConnection() throws ConnectionException {
		try {
			return DriverManager.getConnection(this.alias2);
		} catch (SQLException e) {
			throw new ConnectionException(e);
		}
	}

	public void setTransactionManager(TransactionManager tm) {
		throw new UnsupportedOperationException();
	}

	public void setConURL(String conURL) {

	}

	public void setDriverName(String driverName) {

	}

	public void setMax(int max) {

	}

	public void setMin(int min) {

	}

	public void setPassword(String password) {

	}

	public void setUsername(String username) {

	}

	public void shutdown() {
		this.closeAllConnections();
		try {
			ProxoolFacade.removeConnectionPool(this.alias2);
		} catch (ProxoolException e) {
			e.printStackTrace();
		}

	}

	public void start() {

	}

	@Override
	public void setTestSql(String testSql) {
	}

}

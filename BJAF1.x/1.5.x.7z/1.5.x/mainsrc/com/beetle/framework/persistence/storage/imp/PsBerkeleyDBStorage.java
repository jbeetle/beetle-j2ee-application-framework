/*
 * BJAF - Beetle J2EE Application Framework
 * �׿ǳ�J2EE��ҵӦ�ÿ������
 * ��Ȩ����2003-2009 ��ƶ� (www.beetlesoft.net)
 * 
 * ����һ����ѿ�Դ�������������ڡ��׿ǳ�J2EEӦ�ÿ�������ȨЭ�顷
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   ��GNU Lesser General Public License v3.0��
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>�ºϷ�ʹ�á��޸Ļ����·�����
 *
 * ��л��ʹ�á��ƹ㱾��ܣ����н�������⣬��ӭ�������ϵ��
 * �ʼ��� <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.storage.imp;

import java.util.List;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.persistence.storage.IStorageAccess;
import com.beetle.framework.persistence.storage.StorageAccessException;
import com.beetle.framework.persistence.storage.StorageObj;

public class PsBerkeleyDBStorage implements IStorageAccess {

	public int create(StorageObj storageObj) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int[] createBatch(List storageObjList) {
		throw new AppRuntimeException("not supported yet!");
	}

	public void createIndex(String fieldName) {
		throw new AppRuntimeException("not supported yet!");

	}

	public int delete(String id) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int delete(String deleteExpression, Object[] values) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int[] deleteBatch(List idList) {
		throw new AppRuntimeException("not supported yet!");
	}

	public void dropIndex(String fieldName) {
		throw new AppRuntimeException("not supported yet!");

	}

	public void empty() {
		throw new AppRuntimeException("not supported yet!");

	}

	public List filter(String filterExpression, Object[] values) {
		throw new AppRuntimeException("not supported yet!");
	}

	public List filterByPage(String filterExpression, Object[] values,
			int pageNum, int pageSize) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int filterSize(String filterExpression, Object[] values) {
		throw new AppRuntimeException("not supported yet!");
	}

	public StorageObj peek(String id) {
		throw new AppRuntimeException("not supported yet!");
	}

	public void rebuildIndex(String filedName) {
		throw new AppRuntimeException("not supported yet!");

	}

	public StorageObj retrieve(String id) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int size() {
		throw new AppRuntimeException("not supported yet!");
	}

	public int update(StorageObj storageObj) {
		throw new AppRuntimeException("not supported yet!");
	}

	public List weakFilterByPage(String filterExpression, Object[] values,
			int pageNum, int pageSize) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int weakUpdate(StorageObj storageObj) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int[] weakUpdateBatch(List storageObjList) {
		throw new AppRuntimeException("not supported yet!");
	}

	public int close() {
		throw new AppRuntimeException("not supported yet!");
	}

	public int open() {
		throw new AppRuntimeException("not supported yet!");
	}

	public List weakFilterByPage(String filterExpression, Object[] values)
			throws StorageAccessException {
		// TODO Auto-generated method stub
		return null;
	}

}

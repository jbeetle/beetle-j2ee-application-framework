package com.beetle.framework.persistence.storage;

import com.beetle.framework.AppRuntimeException;

public class StorageAccessException extends AppRuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public StorageAccessException(int errCode, String message, Throwable cause) {
		super(errCode, message, cause);
	}

	public StorageAccessException(int errCode, String message) {
		super(errCode, message);
	}

	public StorageAccessException(int errCode, Throwable cause) {
		super(errCode, cause);
	}

	public StorageAccessException(String message, Throwable cause) {
		super(message, cause);
	}

	public StorageAccessException(String message) {
		super(message);
	}

	public StorageAccessException(Throwable cause) {
		super(cause);
	}

}

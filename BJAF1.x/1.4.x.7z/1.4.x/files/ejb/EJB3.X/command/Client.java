package com.beetle.framework.business.ejb3.command;

/**
 * <p>Title: Beetleҵ���߼����</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: �׿ǳ�����</p>
 *
 * @author ��ƶ���yuhaodong@gmail.com��
 * @version 1.0
 */
import com.beetle.framework.resource.AppContext;
import javax.naming.*;
public class Client {
  public Client() {
    super();
  }

  public static void main(String[] args) {
  try {
    ICommand command = (ICommand) AppContext.getContainerContext().lookup(
        "CommandServerBean3/Remote");
    //command.executeCommand()
    //command.executeCommandWithTransaction()
  }
  catch (NamingException ex) {
  }
  }
}

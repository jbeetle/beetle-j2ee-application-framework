package com.beetle.framework.business.ejb3.command;

import com.beetle.framework.business.command.CommandImp;

/**
 * <p>Title: Beetleҵ���߼����</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2006</p>
 *
 * <p>Company: �׿ǳ�����</p>
 *
 * @author ��ƶ���yuhaodong@gmail.com��
 * @version 1.0
 */
public interface ICommand {
  public CommandImp executeCommandWithTransaction(CommandImp command);
  public CommandImp executeCommand(CommandImp command);
}

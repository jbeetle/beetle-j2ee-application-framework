package example.business;

import com.beetle.framework.business.command.CommandException;
import com.beetle.framework.business.command.CommandImp;

public class AccountCmd extends CommandImp {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String user;
	private String echo;

	public void process() throws CommandException {
		echo = "echo:" + user;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			throw new CommandException(e);
		}
	}

	public String getEcho() {
		return echo;
	}

	public void setUser(String user) {
		this.user = user;
	}

}

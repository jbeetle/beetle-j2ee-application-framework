package example.business;

import com.beetle.framework.business.command.CommandException;
import com.beetle.framework.business.command.CommandExecutor;
import com.beetle.framework.business.command.CommandImp;
import com.beetle.framework.business.command.ICommandCallBack;

public class TestCmd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		for (int i = 0; i < 20; i++) {
			t1(i);
		}
		System.out.println("OK");
	}

	private static void t1(int i) {
		AccountCmd cmd = new AccountCmd();
		cmd.setUser("Henry" + i);
		CommandExecutor.asynchroExecute(cmd, new ICommandCallBack() {
			public void handle(CommandImp resultCmd) throws CommandException {
				AccountCmd cmd2 = (AccountCmd) resultCmd;
				System.out.println(cmd2.getEcho());
			}
		});
	}

}

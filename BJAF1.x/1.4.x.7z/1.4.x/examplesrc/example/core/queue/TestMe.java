package example.core.queue;

import com.beetle.framework.util.cache.LifeCycleCache;

public class TestMe {
	private static class T extends LifeCycleCache.TimeOutEvent {

		public void deal(Object key, Object valueObj) {
			System.out.println("--begin--");
			System.out.println(key);
			System.out.println(valueObj);
			System.out.println("--end--");
		}

	}

	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		LifeCycleCache lcc = new LifeCycleCache(5000, 100, new T());
		// lcc.registerTimeOutEvent(new T());
		lcc.put("a", "cccc");
		System.out.println(lcc.get("a"));
		Thread.sleep(10000);
		System.out.println(lcc.get("a"));
		System.out.println("ok");
	}

}

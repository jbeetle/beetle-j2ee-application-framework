package example.core.observer;

import com.beetle.framework.util.pattern.observer.AbleImp;

public class Stock extends AbleImp {// 扩展AbleImp以便Stock对象的属性可监控

	public Stock() {
		super();
	}

	private Float price;// 股票价格

	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price, Float targetPrice) {
		this.price = price;
		if (this.price.floatValue() <= targetPrice.floatValue()) {// 报警条件（股价跌到目标价）
			this.observeOneObject(this.price);// 设置price字段对象为报警对象
		}
	}

}

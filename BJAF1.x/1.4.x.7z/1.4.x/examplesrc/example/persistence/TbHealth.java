package example.persistence;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class TbHealth {

	public String toString() {
		return "TbHealth [FLAT=" + FLAT + ", HAPPENTIME=" + HAPPENTIME
				+ ", INFO=" + INFO + ", JOBID=" + JOBID + "]";
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private BigDecimal JOBID;
	private Timestamp HAPPENTIME;
	private String INFO;
	private BigDecimal FLAT;

	public BigDecimal getJOBID() {
		return JOBID;
	}

	public void setJOBID(BigDecimal jOBID) {
		JOBID = jOBID;
	}

	public Timestamp getHAPPENTIME() {
		return HAPPENTIME;
	}

	public void setHAPPENTIME(Timestamp hAPPENTIME) {
		HAPPENTIME = hAPPENTIME;
	}

	public String getINFO() {
		return INFO;
	}

	public void setINFO(String iNFO) {
		INFO = iNFO;
	}

	public BigDecimal getFLAT() {
		return FLAT;
	}

	public void setFLAT(BigDecimal fLAT) {
		FLAT = fLAT;
	}
}

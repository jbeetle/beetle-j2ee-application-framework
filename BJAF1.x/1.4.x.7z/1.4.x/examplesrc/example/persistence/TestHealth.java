package example.persistence;

import java.util.ArrayList;
import java.util.List;

import com.beetle.framework.persistence.access.operator.QueryOperator;
import com.beetle.framework.persistence.access.operator.RsDataSet;

public class TestHealth {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List l = new ArrayList();
		QueryOperator q = new QueryOperator();
		q.setDataSourceName("SYSDATASOURCE_DEFAULT");
		q.setSql("select jobid,happentime,flat,info from tbhealth");
		q.access();
		RsDataSet rs = new RsDataSet(q.getSqlResultSet());
		try {
			for (int i = 0; i < rs.rowCount; i++) {
				TbHealth tjs = new TbHealth();
				System.out.println(rs.getRowValues(i));
				rs.autoFillRow(tjs);
				System.out.println(tjs);
				l.add(tjs);
				rs.next();
			}
		} finally {
			rs.clearAll();
		}
		System.out.println(l);
            try {
                Thread.sleep(100000);
            } catch (InterruptedException ex) {
            }
	}
}

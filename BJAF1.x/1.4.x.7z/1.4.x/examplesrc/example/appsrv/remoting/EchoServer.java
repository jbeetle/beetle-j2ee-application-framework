package example.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageServer;

public class EchoServer {

	public static void main(String[] args) {
		MessageServer ms = new MessageServer(9090);
		ms.registerServerAction(new EchoServerAction());
		ms.start();
	}

}

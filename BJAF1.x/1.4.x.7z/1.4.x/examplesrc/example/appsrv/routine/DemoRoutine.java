package example.appsrv.routine;

import com.beetle.framework.appsrv.SubRoutine;

public class DemoRoutine extends SubRoutine {

	public DemoRoutine(int maxBlockTime) { 
		super(maxBlockTime);// 采取超时参数构造函数
	}

	protected void routine() throws InterruptedException {
		while (true) {// 死循环
			System.out
					.println(System.currentTimeMillis() + "->do something...");
		}
	}

}

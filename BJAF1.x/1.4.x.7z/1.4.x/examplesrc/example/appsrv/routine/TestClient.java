package example.appsrv.routine;

import com.beetle.framework.appsrv.RoutinesPool;

public class TestClient {

	public static void main(String[] args) throws Throwable {
		// RoutineExecutor.runRoutineInCommonPool(new DemoRoutine(1));//
		// 最大阻塞时间为5秒

		// RoutineExecutor.runRoutineInCommonPool(new DemoRoutine(15));//
		// 最大阻塞时间为5秒

		DemoRoutine t = new DemoRoutine(20);
		RoutinesPool.runRoutineInCommonPool(t);
		// Thread.sleep(20000);
		// RoutinesPool.runRoutineInPool(t);
	}

}

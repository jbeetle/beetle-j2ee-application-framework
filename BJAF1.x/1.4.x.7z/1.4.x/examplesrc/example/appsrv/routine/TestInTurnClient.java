package example.appsrv.routine;

import com.beetle.framework.appsrv.RoutineExecutor;

public class TestInTurnClient {

	public static void main(String[] args) {
		// 构建一个子程序执行器
		RoutineExecutor re = new RoutineExecutor();
		re.addSubRoutine(new SR1());// 添加各个子程序到执行器队列
		re.addSubRoutine(new SR2());
		re.addSubRoutine(new SR3());
		re.runRoutineInTurn();// 串行执行，并阻塞，等待队列中所有子程序都结束才返回
		//re.runRoutineInTurnNoBlock();
		System.out.println("ok");
	}

}

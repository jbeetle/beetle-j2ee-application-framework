package example.appsrv.routine;

import java.util.ArrayList;
import java.util.List;

import com.beetle.framework.appsrv.SubRoutine;

public class HardWorkSR extends SubRoutine {

	protected void routine() throws InterruptedException {
		System.out.println("work-begin");
		List data = new ArrayList();
		sleep(10000);// 假设此任务要计算10秒
		data.add("AAA");
		data.add("BBB");
		this.setResult(data);// 设置结果以便返回
		System.out.println("word-end");
	}

}

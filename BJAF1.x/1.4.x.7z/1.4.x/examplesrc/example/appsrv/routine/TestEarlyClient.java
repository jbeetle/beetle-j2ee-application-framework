package example.appsrv.routine;

import java.util.List;

import com.beetle.framework.appsrv.RoutineExecutor;

public class TestEarlyClient {

	public static void main(String[] args) {
		RoutineExecutor re = new RoutineExecutor();
		re.addSubRoutine(new HardWorkSR());
		re.runRoutineEarly();// 提早执行
		// ...继续处理其它任务
		System.out.println("do other work...");
		// 处理完其它任务后，再来拿结果
		List result = (List) re.getResult();// 会阻塞一定等到任务处理完毕有结果返回为止
		System.out.println(result);
		System.out.println("ok");
	}

}

package example.appsrv.routine;

import com.beetle.framework.appsrv.SubRoutine;

public class SR3 extends SubRoutine {

	protected void routine() throws InterruptedException {
		System.out.println("sr3-begin");
		sleep(1000);
		System.out.println("sr3-end");

	}

}

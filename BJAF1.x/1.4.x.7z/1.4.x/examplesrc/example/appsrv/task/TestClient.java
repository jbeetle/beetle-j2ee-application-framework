package example.appsrv.task;

import com.beetle.framework.appsrv.scheduler.TaskScheduler;

public class TestClient {

	public static void main(String[] args) {
		// 获取计划执行器
		TaskScheduler scheduler = TaskScheduler.getInstance();
		// 定义计划任务（每日23时59分执行此任务）
		scheduler.scheduleDialy(DemoTask.class, "DemoTask", 23, 59);
		// 启动这个计划
		scheduler.start();

	}

}

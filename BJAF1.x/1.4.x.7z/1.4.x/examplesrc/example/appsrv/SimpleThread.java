package example.appsrv;

import com.beetle.framework.appsrv.AppThreadImp;

public class SimpleThread extends AppThreadImp {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SimpleThread(int interval) {
		super(interval);
	}

	private int i = 0;

	protected void workProc() {// 工作方法，会自动循环执行，间隔时间interval毫秒
		System.out.println(System.currentTimeMillis() + "-->do something...");
		i++;
		if (i > 4) {
			this.stopNow();
		}
	}

	protected void end() {// 线程结束时，触发的事件
		System.out.println(System.currentTimeMillis() + "-->end");
	}

}

package test.business;

import test.persistence.dao.IMyTableDao;
import test.persistence.vo.MyTable;

import com.beetle.framework.business.command.CommandException;
import com.beetle.framework.business.command.CommandImp;
import com.beetle.framework.persistence.dao.DaoFactory;

public class TestTransCmd extends CommandImp {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private MyTable table1;
	private MyTable table2;

	public void setTable1(MyTable table1) {
		this.table1 = table1;
	}

	public void setTable2(MyTable table2) {
		this.table2 = table2;
	}

	public void process() throws CommandException {
		IMyTableDao dao = (IMyTableDao) DaoFactory.getDaoObject("IMyTableDao");
		dao.insertTable1(table1);
		dao.insertTable2(table2);
	}

}

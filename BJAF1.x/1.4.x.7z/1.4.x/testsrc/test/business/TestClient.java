package test.business;

import com.beetle.framework.business.command.CommandExecutor;

import test.persistence.vo.MyTable;

public class TestClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyTable t1=new MyTable();
		t1.setId("10001");
		t1.setVl("aaaaaaaaa");
		MyTable t2=new MyTable();
		t2.setId("20001");
		t2.setVl("bbbbbbbbbb");
		TestTransCmd cmd=new TestTransCmd();
		cmd.setTable1(t1);
		cmd.setTable2(t2);
		cmd=(TestTransCmd)CommandExecutor.executeWithTransaction(cmd);
		System.out.println(cmd.getReturnFlag());
		System.out.println(cmd.getReturnMsg());
	}

}

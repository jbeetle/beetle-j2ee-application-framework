package test.core.example.test.pattern;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import com.opensymphony.oscache.general.GeneralCacheAdministrator;

public class CacheOsTestMe {
	
	public static void main2(String[] args) {
		Properties pro = new Properties();
		pro
				.setProperty("cache.persistence.class",
						"com.opensymphony.oscache.plugins.diskpersistence.DiskPersistenceListener");
		pro.setProperty("cache.path", "d:\\myapp\\cache2");
		pro.setProperty("cache.unlimited.disk", "true");
		pro.setProperty("cache.memory", "false");
		GeneralCacheAdministrator gca = new GeneralCacheAdministrator(pro);
		Map m = new HashMap();
		m.put("name", "Henry");
		m.put("pro", pro);
		for (int i = 0; i < 10; i++) {
			gca.putInCache("myMap" + i, m);
			gca.flushAll();
		}
		gca.destroy();
		System.out.println("ok");
	}

	public static void main(String[] args) throws Exception {
		Properties pro = new Properties();
		pro
				.setProperty("cache.persistence.class",
						"com.opensymphony.oscache.plugins.diskpersistence.DiskPersistenceListener");
		pro.setProperty("cache.path", "d:\\myapp\\cache2");
		pro.setProperty("cache.unlimited.disk", "true");
		pro.setProperty("cache.memory", "false");
		GeneralCacheAdministrator gca = new GeneralCacheAdministrator(pro);
		Map m = (Map) gca.getFromCache("myMap2");
		//System.out.println(m.get("name"));
		System.out.println(m.get("pro"));
	}

}

package test.core.example.test.pattern.observ;

/**
 * <p>Title: J2EE��ܺ��Ĺ��߰�</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: �׿ǳ�����</p>
 *
 * @author ��ƶ���hdyu@beetlesoft.net��
 * @version 1.0
 */
public class TestMe {
  public TestMe() {
    super();
  }

  public static void main(String[] args) {
    Obj o = new Obj();
    o.setValue(null);
    o.addOneObserver(new ObjTrigger());
    System.out.println("ok2");
    o.setValue("hi2");
    System.out.println("ok");
    o.setValue("hi22");
  }
}

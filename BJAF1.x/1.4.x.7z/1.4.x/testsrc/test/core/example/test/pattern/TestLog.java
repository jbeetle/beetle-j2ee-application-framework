package test.core.example.test.pattern;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.TypeConvert;

public class TestLog {
	private static SysLogger logger = SysLogger.getInstance(TestLog.class);

	public static void main(String[] args) {
		String a = TypeConvert.dateFormat(new java.util.Date(System
				.currentTimeMillis()), "yyyyMMdd");
		System.out.println(a);
		logger.debug(a);
	}

}

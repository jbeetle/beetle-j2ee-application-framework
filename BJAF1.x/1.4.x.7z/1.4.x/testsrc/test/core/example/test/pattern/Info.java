package test.core.example.test.pattern;

import java.io.Serializable;

public class Info implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 5121457491459780878L;

	private String loginUser;

	private int password;

	private java.util.Date loginTime;

	private java.sql.Timestamp time;

	public java.sql.Timestamp getTime() {
		return time;
	}

	public void setTime(java.sql.Timestamp time) {
		this.time = time;
	}

	public java.util.Date getLoginTime() {
		return loginTime;
	}

	public void setLoginTime(java.util.Date loginTime) {
		this.loginTime = loginTime;
	}

	public String getLoginUser() {
		return loginUser;
	}

	public void setLoginUser(String loginUser) {
		this.loginUser = loginUser;
	}

	public int getPassword() {
		return password;
	}

	public void setPassword(int password) {
		this.password = password;
	}

}

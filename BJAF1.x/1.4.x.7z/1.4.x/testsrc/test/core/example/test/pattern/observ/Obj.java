package test.core.example.test.pattern.observ;

import com.beetle.framework.util.pattern.observer.AbleImp;

/**
 * <p>Title: J2EE��ܺ��Ĺ��߰�</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: �׿ǳ����</p>
 *
 * @author ��ƶ���hdyu@beetlesoft.net��
 * @version 1.0
 */
public class Obj
    extends AbleImp {
  private String value;
  public Obj() {
    super();
  }

  public String getValue() {
    return value;
  }

  public void setValue(String value) {
    this.value = value;
    this.observeOneObject(this.value);
  }
}

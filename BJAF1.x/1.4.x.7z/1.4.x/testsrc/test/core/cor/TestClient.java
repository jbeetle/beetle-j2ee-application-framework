package test.core.cor;

import com.beetle.framework.util.pattern.cor.ChainExecutor;
import com.beetle.framework.util.pattern.cor.ChainNode;

public class TestClient {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		MyReq req = new MyReq();
		req.setName("Henry");
		req.setDate(new java.util.Date(System.currentTimeMillis()));
		ChainNode node1 = new ChainNode(new Handler1());
		ChainNode node2 = new ChainNode(new Handler2());
		ChainNode node3 = new ChainNode(new Handler3());
		ChainExecutor executer = new ChainExecutor();
		executer.addNode(node1);
		executer.addNode(node2);
		executer.addNode(node3);
		executer.start(req);
		executer.clearAll();
	}

}

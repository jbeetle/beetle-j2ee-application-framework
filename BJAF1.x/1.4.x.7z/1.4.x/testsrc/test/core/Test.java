package test.core;

import com.beetle.framework.log.SysLogger;

public class Test {
	//注册一个日志记录器
	private static SysLogger logger = SysLogger.getInstance();

	public static void main(String[] args) {
		logger.debug("test...");
		//...
	}

}

package test;

public class TestClient {
	// private volatile int i;
	private int i;

	public int getI() {
		return i;
	}

	public synchronized  void inc() {
		i = i + 1;
	}

	public void dec() {
		i = i - 1;
	}

	public static void main(String[] args) {
		final TestClient t = new TestClient();
		for (int k = 0; k < 50; k++) {
			new Thread(new Runnable() {
				public void run() {
					for (int j = 0; j < 100; j++) {
						t.inc();
						try {
							Thread.sleep(10);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
			}).start();
		}
		new Thread(new Runnable() {
			public void run() {
				while (true) {
					System.out.println(t.getI());
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}).start();
	}
}
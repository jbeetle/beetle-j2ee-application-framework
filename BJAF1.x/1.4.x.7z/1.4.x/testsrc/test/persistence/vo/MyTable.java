package test.persistence.vo;

import java.io.Serializable;

public class MyTable implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5310437302750460840L;
	private String id;
	private String vl;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getVl() {
		return vl;
	}
	public void setVl(String vl) {
		this.vl = vl;
	}
	

}

package test.persistence.vo;

import java.math.BigDecimal;
import java.sql.Timestamp;

public class TbTBJOB {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String JOBNAME;
	private String JARNAME;
	private BigDecimal JOBID;
	private String USERNAME;
	private BigDecimal JOBSTATUS;
	private BigDecimal JOBTYPE;
	private BigDecimal JOBOWNER;
	private Timestamp NEXTRUN;
	private String DESINFO;
	private Timestamp CREATETIME;
	private String JOBEXPRESS;

	public TbTBJOB() {
	}

	public String getJOBNAME() {
		return this.JOBNAME;
	}

	public String getJARNAME() {
		return this.JARNAME;
	}

	public BigDecimal getJOBID() {
		return this.JOBID;
	}

	public String getUSERNAME() {
		return this.USERNAME;
	}

	public BigDecimal getJOBSTATUS() {
		return this.JOBSTATUS;
	}

	public BigDecimal getJOBTYPE() {
		return this.JOBTYPE;
	}

	public BigDecimal getJOBOWNER() {
		return this.JOBOWNER;
	}

	public Timestamp getNEXTRUN() {
		return this.NEXTRUN;
	}

	public String getDESINFO() {
		return this.DESINFO;
	}

	public Timestamp getCREATETIME() {
		return this.CREATETIME;
	}

	public String getJOBEXPRESS() {
		return this.JOBEXPRESS;
	}

	public void setJOBNAME(String JOBNAME) {
		this.JOBNAME = JOBNAME;
	}

	public void setJARNAME(String JARNAME) {
		this.JARNAME = JARNAME;
	}

	public void setJOBID(BigDecimal JOBID) {
		this.JOBID = JOBID;
	}

	public void setUSERNAME(String USERNAME) {
		this.USERNAME = USERNAME;
	}

	public void setJOBSTATUS(BigDecimal JOBSTATUS) {
		this.JOBSTATUS = JOBSTATUS;
	}

	public void setJOBTYPE(BigDecimal JOBTYPE) {
		this.JOBTYPE = JOBTYPE;
	}

	public void setJOBOWNER(BigDecimal JOBOWNER) {
		this.JOBOWNER = JOBOWNER;
	}

	public void setNEXTRUN(Timestamp NEXTRUN) {
		this.NEXTRUN = NEXTRUN;
	}

	public void setDESINFO(String DESINFO) {
		this.DESINFO = DESINFO;
	}

	public void setCREATETIME(Timestamp CREATETIME) {
		this.CREATETIME = CREATETIME;
	}

	public void setJOBEXPRESS(String JOBEXPRESS) {
		this.JOBEXPRESS = JOBEXPRESS;
	}

	/**
	 * Constructs a <code>String</code> with all attributes in name = value
	 * format.
	 * 
	 * @return a <code>String</code> representation of this object.
	 */
	public String toString() {
		final String TAB = "\n";
		StringBuffer retValue = new StringBuffer();
		retValue.append("TbTBJOB ( ").append("JOBNAME = ").append(this.JOBNAME)
				.append(TAB).append("JARNAME = ").append(this.JARNAME).append(
						TAB).append("JOBID = ").append(this.JOBID).append(TAB)
				.append("USERNAME = ").append(this.USERNAME).append(TAB)
				.append("JOBSTATUS = ").append(this.JOBSTATUS).append(TAB)
				.append("JOBTYPE = ").append(this.JOBTYPE).append(TAB).append(
						"JOBOWNER = ").append(this.JOBOWNER).append(TAB)
				.append("NEXTRUN = ").append(this.NEXTRUN).append(TAB).append(
						"DESINFO = ").append(this.DESINFO).append(TAB).append(
						"CREATETIME = ").append(this.CREATETIME).append(TAB)
				.append("JOBEXPRESS = ").append(this.JOBEXPRESS).append(TAB)
				.append(" )");
		return retValue.toString();
	}

}

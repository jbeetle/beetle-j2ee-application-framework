package test;

import com.beetle.framework.AppProperties;
import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.util.AesEncrypt;
import com.beetle.framework.util.OtherUtil;

public class TestMe {
	private static class SelectorVO {

		public int getI() {
			return i;
		}

		public SelectorVO() {
			x = OtherUtil.randomLong(100, 2000);
			i = 0;
		}

		private final Object lock = new Object();
		private long x;
		private int i;

		public long getX() {
			return x;
		}

		public void add() {
			i = i + 1;
		}

		public Object getLock() {
			return lock;
		}

		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((lock == null) ? 0 : lock.hashCode());
			return result;
		}

	}

	static SelectorVO ss[];
	private static int post = 0;

	private static SelectorVO roundRobin() {
		synchronized (ss) {
			SelectorVO svo = ss[post];
			post++;
			if (post >= ss.length) {
				post = 0;
			}
			return svo;
		}
	}

	private static class T extends AppThreadImp {

		public T(String threadName, int interval) {
			super(threadName, interval);
		}

		protected void workProc() {
			final SelectorVO vo = roundRobin();
			synchronized (vo.getLock()) {
				System.out.println("--begin[" + this.getName() + "]");
				System.out.println("id-" + vo.getX());
				vo.add();
				// System.out.println(vo.hashCode());
				System.out.println(AesEncrypt.encrypt("999999999999999999"
						+ vo.getI()));
				System.out.println(vo.getI());
				System.out.println("--end[" + this.getName() + "]");
			}
		}

	}

	public static void main(String arg[]) {
		int size=AppProperties.getAsInt("routinespool_POOL_MAX_SIZE");
		String test=AppProperties.get("test");
	}

	public static void main3(String arg[]) {
		ss = new SelectorVO[2];
		ss[0] = new SelectorVO();
		ss[1] = new SelectorVO();
		for (int i = 0; i < 100; i++) {
			new T("t" + i, 10).startNow();
		}
	}
}

package test.net;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;

public class TestHttp {

	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		URL url = new URL("http://localhost:7602/views/login.html");
		HttpURLConnection http = (HttpURLConnection) url.openConnection();
		http.setAllowUserInteraction(false);
		//http.setFollowRedirects(false);
		http.setInstanceFollowRedirects(false);
		http.setDoOutput(true);
		http.setDoInput(true);
		http.addRequestProperty("Connection", "Keep-Alive");
		//http.setRequestMethod("GET");
		//http.setRequestMethod("HEAD");
		//bSystem.out.println(http.getHeaderFields());
		http.setRequestMethod("GET");
		InputStream buffer = new BufferedInputStream(http.getInputStream());
		Reader reader = new InputStreamReader(buffer);
		int i;
		while ((i = reader.read()) != -1) {
			System.out.print((char) i);
		}
		http.disconnect();
	}

}

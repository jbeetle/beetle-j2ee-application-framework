package test.appsrv;

import com.beetle.framework.appsrv.RoutineExecutor;

public class TestParallel {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RoutineExecutor re = new RoutineExecutor();
		re.addSubRoutine(new TimeoutRoutine(1));
		re.addSubRoutine(new TimeoutRoutine(2));
		re.addSubRoutine(new TimeoutRoutine(3));
		re.addSubRoutine(new TimeoutRoutine(4));
		re.addSubRoutine(new TimeoutRoutine(5));
		re.addSubRoutine(new TimeoutRoutine(6));
		re.runRoutineParalleJoin();
		System.out.println("ok");
	}

}

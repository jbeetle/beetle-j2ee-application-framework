package test.appsrv;

import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;

public class T3 extends SubRoutine {
	protected void end() {
		System.out.println("end");
		super.end();
	}

	private static IQueue q = new BlockQueue();

	public T3(int i) {
		super(i);
		//this.setName("t[" + i + "]");
	}

	protected void routine() throws InterruptedException {
		System.out.println(System.currentTimeMillis());
		System.out.println(q.pop());// block;
		System.out.println("oooo");
	}

}

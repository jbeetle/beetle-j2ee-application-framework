package test.appsrv;

import com.beetle.framework.appsrv.AppRunnable;
import com.beetle.framework.appsrv.Counter;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.RoutinesPool;
import com.beetle.framework.appsrv.SubRoutine;

import edu.emory.mathcs.backport.java.util.concurrent.SynchronousQueue;
import edu.emory.mathcs.backport.java.util.concurrent.ThreadPoolExecutor;
import edu.emory.mathcs.backport.java.util.concurrent.TimeUnit;

public class TestA {
	private static Counter counter = new Counter(0);

	private static class A extends AppRunnable {

		protected void end() {
		

		}

		public void run() {
			while (true) {
				System.out.println(counter.getCurrentValue());
				sleep(2000);
			}

		}

	}

	private static class T extends SubRoutine {

		protected void end() {
			counter.decrease();
			super.end();
		}

		protected void routine() throws InterruptedException {
			counter.increase();
			// sleep(1000);
		}

	}

	public static void mainx(String[] args) throws Throwable {
		ThreadPoolExecutor ee = new ThreadPoolExecutor(10, 20, 1000 * 60,
				TimeUnit.MILLISECONDS, new SynchronousQueue());
		ee.prestartCoreThread();
		for (int i = 0; i < 100; i++) {
			System.out.println(ee.getPoolSize());
			Thread.sleep(500);
		}
		System.out.println("ok");
	}

	public static void main(String[] args) throws Throwable {
		RoutineExecutor.runRoutineInCommonPool(new T());
		RoutineExecutor.getRoutinesPool();
		for (int i = 0; i < 100; i++) {
			System.out.println(RoutinesPool.commonPoolIsFullNow());
			Thread.sleep(500);
		}
		System.out.println("ok");
	}

	public static void main2(String[] args) throws Throwable {
		for (int i = 0; i < 1000; i++) {
			RoutineExecutor.runRoutineInCommonPool(new T());
		}
		new A().startNow();
		System.out.println("ok");
	}

}

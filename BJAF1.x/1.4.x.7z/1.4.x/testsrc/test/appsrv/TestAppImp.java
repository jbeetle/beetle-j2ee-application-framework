package test.appsrv;

import java.util.Iterator;
import java.util.Vector;

import com.beetle.framework.appsrv.AppThreadImp;

public class TestAppImp extends AppThreadImp {

	public TestAppImp(int flag, int MaixIdle, int interval) {
		super(MaixIdle, interval);
		this.i = flag;
	}

	// private static IQueue queue = new NoBlockQueue();
	private static Vector mylist = new Vector();
	private int i = 0;

	public TestAppImp(int flag, String threadName, int MaixIdle, int interval) {
		super(threadName, MaixIdle, interval);
		this.i = flag;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void workProc() {
		if (i != 10000) {
			// queue.push(new T3());
			mylist.add(new T3(i));
			// System.out.println(mylist.size());
		} else {
			synchronized (mylist) {
				Iterator it = mylist.iterator();
				while (it.hasNext()) {
					T3 t = (T3) it.next();
					// System.out.println(t.getThreadName());
				}
				mylist.clear();
			}

		}
	}

	protected void end() {
		System.out.println("end");

	}

	public static void main(String arg[]) throws Throwable {
		for (int i = 0; i < 50; i++) {
			// TestAppImp ti = new TestAppImp(i, "in" + i, 5, 1000);
			TestAppImp ti = new TestAppImp(i, 5, 1000);
			ti.startNow();
		}
		Thread.sleep(3000);
		TestAppImp ti = new TestAppImp(10000, "out", 5, 1000);
		ti.startNow();
		System.out.println("ok");

	}
}

package test.appsrv.app;

import com.beetle.framework.appsrv.AppThreadImp;

public class ModuleDemo extends AppThreadImp {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ModuleDemo(String threadName, int MaixIdle, int interval) {
		super(threadName, MaixIdle, interval);
	}

	protected void workProc() {
		System.out.println("module work...");
	}

	protected void end() {
		System.out.println("end");

	}

}

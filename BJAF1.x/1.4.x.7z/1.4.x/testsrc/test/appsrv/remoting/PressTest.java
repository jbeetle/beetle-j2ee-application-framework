package test.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageClient;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;

public class PressTest {
	private static MessageClient client = null;// synchronized

	public static String callIt() {
		if (client == null) {
			client = new MessageClient();
			try {
				client.connect("10.25.17.68:9090", "Henry", "888888");
			} catch (MessageCommunicateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		MsgReq req = new MsgReq();
		req.setValueWithString("word", "dsjkfjsdlfkj");
		MsgRes res = null;
		try {
			res = client.invoke(req);
		} catch (MessageCommunicateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(res);
		return res.getValueAsString("echo");
	}

	public static void callIt3() {
		if (client == null) {
			client = new MessageClient();
			try {
				client.connect("10.25.17.68:9090", "Henry", "888888");
			} catch (MessageCommunicateException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		MsgReq req = new MsgReq();
		req.setValueWithString("word", "dsjkfjsdlfkj");
		try {
			client.send(req);
		} catch (MessageCommunicateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// System.out.println(res);

	}

	public static String callIt2() throws MessageCommunicateException {
		MessageClient mc = new MessageClient();
		mc.connect("10.25.17.68:9090", "Henry", "888888");
		MsgReq req = new MsgReq();
		req.setValueWithString("word", "dsjkfjsdlfkj");
		MsgRes res = mc.invoke(req);
		mc.disconnect();
		return res.getValueAsString("echo");
	}

	public static void main(String arg[]) {
		long l1 = System.currentTimeMillis();
		try {
			for (int i = 0; i < 100; i++) {
				 t();
				//System.out.println(i + ":" + callIt2());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		client.disconnect();
		System.out.println(System.currentTimeMillis() - l1 + "ms");
	}

	private static void t() {
		long l1 = System.currentTimeMillis();
		// callIt3();
		System.out.println(callIt());
		System.out.println(System.currentTimeMillis() - l1);
	}
}

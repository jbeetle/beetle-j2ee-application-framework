package test.appsrv.remoting;

import com.beetle.framework.appsrv.remoting.MessageClient;
import com.beetle.framework.appsrv.remoting.MessageCommunicateException;
import com.beetle.framework.appsrv.remoting.MsgReq;
import com.beetle.framework.appsrv.remoting.MsgRes;

public class EchoClient {
	private static class Rev implements Runnable {
		MessageClient client;

		public Rev(MessageClient client) {
			this.client = client;
		}

		public void run() {
			while (true) {
				MsgRes res = client.receive();
				System.out.println(res.getHeader());
				System.out.println(res);
			}
		}

	}

	private static class Invoke implements Runnable {
		MessageClient client;

		public Invoke(MessageClient client) {
			this.client = client;
		}

		public void run() {
			while (true) {
				try {
					MsgReq req = new MsgReq();
					req.setValueWithString("word", "Hi,I am Henry."
							+ System.currentTimeMillis());
					long l1 = System.currentTimeMillis();
					MsgRes res = client.invoke(req);
					// System.out.println(res.getHeader());
					System.out.println(System.currentTimeMillis() - l1 + "ms["
							+ res + "]");
					// Thread.sleep(10);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	private static class Ct extends MessageClient.ClientAction {

		protected void connectionBreakEvent()
				throws MessageCommunicateException {
			System.out.print("mmmm");
			super.connectionBreakEvent();
		}

	}

	public static void main(String[] args) throws MessageCommunicateException {
		MessageClient client = new MessageClient();
		client.registerClientAction(new Ct());
		//boolean f = client.connect("10.25.17.68:9090", "Henry", "888888");
		boolean f = client.connect("127.0.0.1:9090", "Henry", "888888");
		if (f) {
			MsgReq req = new MsgReq();
			req.setValueWithString("word", "Hi,I am Henry.");
			MsgRes res = client.invoke(req);
			if (res != null) {
				String echo = res.getValueAsString("echo");
				System.out.println(echo);
			}
			// new Thread(new Rev(client)).start();
			new Thread(new Invoke(client)).start();
			// client.disconnect();
		}
		// System.exit(0);
	}

}

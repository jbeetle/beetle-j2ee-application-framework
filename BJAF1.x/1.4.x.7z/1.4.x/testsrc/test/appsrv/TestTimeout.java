package test.appsrv;

import com.beetle.framework.appsrv.RoutineExecutor;

public class TestTimeout {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		RoutineExecutor re = new RoutineExecutor();
		re.addSubRoutine(new TimeoutRoutine(3));
		re.runRoutine();
	}

}

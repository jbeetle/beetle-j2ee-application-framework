package test.appsrv.lock;

public final class Mutex

{

	public Mutex() {
		locked = false;
	}

	public synchronized void acquire() {
		while (locked)
			try {
				wait();
			} catch (InterruptedException interruptedexception) {
				notify();
			}
		locked = true;
	}

	public synchronized boolean attempt() {
		if (locked) {
			return false;
		} else {
			locked = true;
			return true;
		}
	}

	public synchronized void release() {
		locked = false;
		notify();
	}

	public boolean isLocked() {
		return locked;
	}

	private boolean locked;
}

package test.appsrv.lock;

import com.beetle.framework.appsrv.Locker;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.SubRoutine;

public class TestMutex {
	private static class T extends SubRoutine {
		private int i;

		public T(int i) {
			this.i = i;
		}

		protected void routine() throws InterruptedException {
			fk(i);

		}

	}

	private static class Goh extends SubRoutine {
		private Locker lock;
		private int i;

		public Goh(Locker lock, int i) {
			this.lock = lock;
			this.i = i;
		}

		protected void routine() throws InterruptedException {
			Thread.sleep(2000);
			// lock.lockForTime(1);
			System.out.println(lock.toString() + "[" + i + "]goh");
			lock.unlock();
		}
	}

	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main2(String[] args) throws Throwable {
		Locker mtx = new Locker();
		mtx.lockForTime(10000);
		System.out.println("ok");
	}

	public static void main(String[] args) throws Throwable {
		for (int i = 0; i < 10; i++) {
			RoutineExecutor.runRoutineInCommonPool(new T(i));
		}
		System.out.println("ok");
	}

	private static void fk(int i) throws InterruptedException {
		Locker lock = new Locker();
		RoutineExecutor.runRoutineInCommonPool(new Goh(lock, i));
		lock.lockForTime(30000);
		// lock.lock();
		System.out.println(lock.toString() + "[" + i + "]fk");
	}
}

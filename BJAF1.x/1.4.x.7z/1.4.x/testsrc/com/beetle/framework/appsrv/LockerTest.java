package com.beetle.framework.appsrv;

public class LockerTest {
	private static class T extends AppThreadImp {
		private Locker locker;
		private int i = 0;

		public T(int interval, Locker locker) {
			super(interval);
			this.locker = locker;
		}

		protected void workProc() {
			i++;
			if (i > 4) {
				this.locker.unlock();
				System.out.println("unlock");
				this.stopNow();
			} else {
				System.out.println("working");
			}
		}

	}

	public static void main(String arg[]) {
		Locker locker = new Locker();
		new T(2000, locker).startNow();
		try {
			 locker.lockForTime(6000);
			//locker.lock();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("OK");
	}

}

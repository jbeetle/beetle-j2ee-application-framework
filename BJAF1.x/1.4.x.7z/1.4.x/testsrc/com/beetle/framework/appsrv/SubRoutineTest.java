package com.beetle.framework.appsrv;

import com.beetle.framework.appsrv.RoutinesPool.WorkThreadPool;

public class SubRoutineTest {
	private static class T extends SubRoutine {

		void terminated() {
			System.out.println("terminated");
			clearSystemStream();
			System.exit(0);
		}

		public T(int maxBlockTime) {
			super(maxBlockTime);
		}

		protected void routine() throws InterruptedException {
			while (true) {
				// System.out.println(System.currentTimeMillis());
				this.sleep(5100);
				// Thread.sleep(1000);
			}
		}

	}

	private static void clearSystemStream() {
		try {
			if (System.in != null) {
				System.in.close();
			}
			if (System.out != null) {
				System.out.close();
			}
			if (System.err != null) {
				System.err.close();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String arg[]) {
		WorkThreadPool wtp = new WorkThreadPool(2, 2, 60 * 1000, 1);
		// RoutineExecutor re = new RoutineExecutor(wtp);
		// re.addSubRoutine(new T(5).killThreadWhenTimeout());
		// re.runRoutine();
		wtp.runInPool(new T(5));
		System.out.println("ok1");
		wtp.runInPool(new T(5));
		System.out.println("ok2");
		wtp.runInPool(new T(5));
		System.out.println("ok3");
		// RoutinesPool.runRoutineInPool(new T(5).killThreadWhenTimeout());
	}

	public static void main3(String arg[]) {
		RoutinesPool.runRoutineInCommonPool(new T(5));
	}
}

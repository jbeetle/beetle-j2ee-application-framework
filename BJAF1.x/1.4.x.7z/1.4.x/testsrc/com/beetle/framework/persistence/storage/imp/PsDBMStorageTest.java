package com.beetle.framework.persistence.storage.imp;

import junit.framework.TestCase;

public class PsDBMStorageTest extends TestCase {

	public PsDBMStorageTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testGetInstance() {
		fail("Not yet implemented");
	}

	public void testCreate() {
		fail("Not yet implemented");
	}

	public void testCreateBatch() {
		fail("Not yet implemented");
	}

	public void testCreateIndex() {
		fail("Not yet implemented");
	}

	public void testDeleteString() {
		fail("Not yet implemented");
	}

	public void testDeleteStringObjectArray() {
		fail("Not yet implemented");
	}

	public void testDeleteBatch() {
		fail("Not yet implemented");
	}

	public void testDropIndex() {
		fail("Not yet implemented");
	}

	public void testEmpty() {
		fail("Not yet implemented");
	}

	public void testFilter() {
		fail("Not yet implemented");
	}

	public void testFilterByPage() {
		fail("Not yet implemented");
	}

	public void testFilterSize() {
		fail("Not yet implemented");
	}

	public void testPeek() {
		fail("Not yet implemented");
	}

	public void testRebuildIndex() {
		fail("Not yet implemented");
	}

	public void testRetrieve() {
		fail("Not yet implemented");
	}

	public void testSize() {
		fail("Not yet implemented");
	}

	public void testUpdate() {
		fail("Not yet implemented");
	}

	public void testWeakFilterByPageStringObjectArrayIntInt() {
		fail("Not yet implemented");
	}

	public void testWeakUpdate() {
		fail("Not yet implemented");
	}

	public void testWeakUpdateBatch() {
		fail("Not yet implemented");
	}

	public void testClose() {
		fail("Not yet implemented");
	}

	public void testOpen() {
		fail("Not yet implemented");
	}

	public void testWeakFilterByPageStringObjectArray() {
		fail("Not yet implemented");
	}

}

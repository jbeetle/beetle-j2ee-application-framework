package com.beetle.framework.persistence.storage.imp;

import java.sql.Timestamp;
import java.util.List;

import test.persistence.vo.MyTable;

import com.beetle.framework.persistence.storage.StorageObj;

public class TestClient {
	// id,createtime,lasttime,objtype,status,plus from storageobj
	public static void main2(String[] args) throws Throwable {
		PsDBMStorage ps = PsDBMStorage.getInstance();
		ps.open();
		ps.empty();
		ps.close();
	}

	public static void main0(String[] args) throws Throwable {
		PsDBMStorage ps = PsDBMStorage.getInstance();
		ps.open();
		ps.delete("where status=?", new Object[] { new Integer(100) });
		ps.close();
	}

	public static void main(String[] args) throws Throwable {
		PsDBMStorage ps = PsDBMStorage.getInstance();
		ps.open();
		System.out.println(ps.size());
		Object os[] = new Object[2];
		os[0] = Timestamp.valueOf("2010-07-05 15:01:40");
		os[1] = new Timestamp(System.currentTimeMillis());
		List l = ps.filter("where createtime >=? and createtime <=?", os);
		for (int i = 0; i < l.size(); i++) {
			System.out.println(i + "-" + l.get(i));
		}
		ps.close();
	}

	public static void main4(String[] args) throws Throwable {
		PsDBMStorage ps = PsDBMStorage.getInstance();
		ps.open();
		int k = 0;
		String id = "";
		for (int i = 0; i < 50000; i++) {
			StorageObj so = new StorageObj();
			so.setId(id + i);
			so.setPlus("ccccz");
			MyTable my = new MyTable();
			my.setId("xxx");
			my.setVl("dsjfldsjflkjdflkjdlskfj");
			so.setStatus(new Integer(100));
			so.setObj(my);
			so.setCreatetime(new Timestamp(System.currentTimeMillis()));
			so.setLasttime(new Timestamp(System.currentTimeMillis()));
			ps.create(so);
			k++;
			if (k > 100) {
				Thread.sleep(3000);
				System.gc();
				k = 0;
			}
			System.out.println(i);
		}
		ps.close();
	}

}

package com.beetle.framework.log;

public class SysLoggerTest {
	private static SysLogger logger = SysLogger.getInstance("demo");

	public static void main(String arg[]) {
		int i = 0;
		int k = 1;
		try {
			System.out.println(k / i);
		} catch (Exception e) {
			String x=logger.getErrStackTraceInfo(e);
			//System.out.println(x);
			logger.error("xx",e);
		}
	}
}

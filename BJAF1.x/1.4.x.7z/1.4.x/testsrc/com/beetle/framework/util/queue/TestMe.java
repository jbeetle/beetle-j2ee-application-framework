package com.beetle.framework.util.queue;

import java.io.IOException;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.appsrv.Counter;

public class TestMe {
	private static Counter counter = new Counter();

	private static class TW extends AppThreadImp {
		private PersistQueue pq;

		public TW(int interval, PersistQueue pq) {
			super(interval);
			this.pq = pq;
		}

		protected void workProc() {
			// pq.push(String.valueOf(System.currentTimeMillis()));
			counter.increase();
			pq.push(String.valueOf(counter.getCurrentValue()));
		}
	}

	private static class TR extends AppThreadImp {
		public TR(int interval, PersistQueue pq) {
			super(interval);
			this.pq = pq;
		}

		private PersistQueue pq;

		protected void workProc() {
			// System.out.println(pq.size());
			System.out.println(pq.pop());
		}

	}

	public static void main2(String[] args) throws Throwable {
		PersistQueue pq = new PersistQueue(true, 100, 1500, "d:\\tmp\\pq.tmp2");
		long l = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			pq.push(String.valueOf(System.currentTimeMillis()));
		}
		System.out.println(System.currentTimeMillis() - l);
	}

	public static void main(String[] args) {
		try {
			PersistQueue pq = new PersistQueue(true, 10, 0, "d:\\tmp\\pq.tmp2c");
			for (int i = 0; i < 50; i++) {
				new TW(50, pq).startNow();
			}
			for (int i = 0; i < 10; i++) {
				new TR(100, pq).startNow();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}

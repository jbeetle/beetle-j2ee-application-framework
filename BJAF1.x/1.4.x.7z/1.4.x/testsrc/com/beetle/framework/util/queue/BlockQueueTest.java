package com.beetle.framework.util.queue;

public class BlockQueueTest {
	public static void main(String arg[]) {
		BlockQueue q = new BlockQueue();
		System.out.println("x");
		Object o = q.pop(10000);
		System.out.println(o);
	}
}

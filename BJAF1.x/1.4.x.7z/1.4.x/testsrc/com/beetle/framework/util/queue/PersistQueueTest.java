package com.beetle.framework.util.queue;

import junit.framework.TestCase;

public class PersistQueueTest extends TestCase {
	private PersistQueue q;

	public PersistQueueTest(String name) {
		super(name);
	}

	protected void setUp() throws Exception {
		super.setUp();
		q = new PersistQueue(true, 10, 0, "d:\\tmp\\pq.tmp");
	}

	protected void tearDown() throws Exception {
		super.tearDown();
	}

	public void testPersistQueue() {
		assertTrue(true);
	}

	public void testPush() {
		q.push("xxx");
		assertTrue(true);
	}

	public void testPop() {
		assertEquals("xxx", (String) q.pop());
	}

	public void testIsEmpty() {
		q.isEmpty();
		assertTrue(true);
	}

	public void testClear() {
		q.clear();
		assertTrue(true);
	}

	public void testSize() {
		q.size();
		assertTrue(true);
	}

}

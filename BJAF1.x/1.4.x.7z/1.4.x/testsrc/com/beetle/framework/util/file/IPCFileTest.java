package com.beetle.framework.util.file;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.beetle.framework.appsrv.remoting.MsgReq;

public class IPCFileTest {
	public static void main(String[] args) {
		try {
			IPCFile ipc = new IPCFile("d:\\jobs_err_info.tmp2", 1024 * 100);
			ipc.empty();
			ipc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main3(String[] args) {
		try {
			IPCFile ipc = new IPCFile("d:\\jobs_err_info.tmp2", 1024 * 100);
			HashMap m = new HashMap();
			TbTBJOB job = new TbTBJOB();
			job.setCREATETIME(new Timestamp(System.currentTimeMillis()));
			job.setJARNAME("xxxx");
			job.setJOBSTATUS(new BigDecimal(1000));
			MsgReq rq = new MsgReq();
			rq.setValueWithObject("xxx", job);
			m.put(new BigDecimal(100), rq);
			ipc.write(m);
			ipc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main2(String[] args) {
		try {
			IPCFile ipc = new IPCFile("d:\\jobs_err_info.tmp2", 1024 * 100);
			while (true) {
				if (ipc.tryLock()) {
					HashMap m = (HashMap) ipc.read();
					System.out.println(m);
					if (m != null) {
						Iterator it = m.entrySet().iterator();
						while (it.hasNext()) {
							Map.Entry kv = (Map.Entry) it.next();
							BigDecimal jobid = (BigDecimal) kv.getKey();
							// MsgReq req = (MsgReq) kv.getValue();
							/*
							 * JobLog tjrl = (JobLog)
							 * req.getValueAsObject(CommonUtil.CLIENT_LOG_KEY);
							 * if (tjrl.getDealflag() !=
							 * CommonUtil.LOG_DEAL_FLAG_VIEW) {
							 * tjrl.setEXEID(Config.getTJSInstanceName());
							 * System.out.println("true"); }
							 */
							System.out.println(kv.getValue());
						}
						m.clear();
						ipc.write(m);
						break;
					}
				}
			}
			ipc.unlock();
			ipc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

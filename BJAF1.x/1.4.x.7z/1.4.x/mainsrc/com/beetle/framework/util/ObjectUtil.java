/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.util;

import java.beans.Introspector;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONObject;

import com.beetle.framework.log.SysLogger;

public class ObjectUtil {
	private static SysLogger logger = SysLogger.getInstance();

	private static Map cache = new WeakHashMap();

	static String decapitalize(String fieldName) {
		return Introspector.decapitalize(fieldName);
	}

	/**
	 * ��һ�����ת����base64������ַ�
	 * 
	 * @param obj
	 * @return
	 */
	public final static String objToBase64Str(Object obj) {
		Base64 b64 = new Base64();
		byte[] bytes = b64.encode(OtherUtil.objToBytes(obj));
		b64 = null;
		return new String(bytes);
	}

	/**
	 * ��base64������ַ�ת���ɶ���
	 * 
	 * @param b64Str
	 * @return
	 */
	public final static Object base64StrToObject(String b64Str) {
		Base64 b64 = new Base64();
		byte[] bytes = b64.decode(b64Str.getBytes());
		return OtherUtil.bytesToObj(bytes);
	}

	/**
	 * ��һ����ֵ����ת�����ַ�(json��ʽ)
	 * 
	 * @param obj
	 * @return
	 */
	public final static String objectToStr(Object obj) {
		JSONObject j = new JSONObject();
		j.put("class_Name", obj.getClass().getName());
		Map oldm = describe(obj);
		Set kvs = oldm.entrySet();
		Iterator it = kvs.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			String key = kv.getKey().toString();
			Object o = kv.getValue();
			Class type = ObjectUtil.getType(key, obj);
			String tstr = type.toString();
			if (tstr.equals(java.util.Date.class.toString())) {
				// System.out.println(o.getClass());
				// System.out.println(o);
				long time = ((java.util.Date) o).getTime();
				j.put(key, time);
			} else if (tstr.equals(java.sql.Timestamp.class.toString())) {
				long time = ((java.sql.Timestamp) o).getTime();
				j.put(key, time);
			} else {
				j.put(key, o);
			}
			tstr = null;
			type = null;
		}
		String str = j.toString();
		emptyJsonObject(oldm, j);
		j = null;
		oldm.clear();
		return str;

	}

	/**
	 * ���������Listת����json��ʽ�ַ�
	 * 
	 * @param l
	 * @return
	 */
	public final static String listToStr(List l) {
		JSONArray a = new JSONArray(l);
		String s = a.toString();
		l.clear();
		return s;
	}

	/**
	 * ��json��ʽת��List
	 * 
	 * @param str
	 * @return
	 */
	public final static List strToList(String str) {
		List l = new ArrayList();
		JSONArray a;
		try {
			a = new JSONArray(str);
			for (int i = 0; i < a.length(); i++) {
				l.add(a.get(i));
			}
		} catch (ParseException e) {
			str = null;
			e.printStackTrace();
		}
		return l;
	}

	/**
	 * object �ַ�ת�ɶ���list
	 * 
	 * @param str
	 * @param objClass
	 *            --Ҫת������
	 * @return
	 */
	public final static List strToObjList(String str, Class objClass) {
		List l = new ArrayList();
		JSONArray a;
		try {
			a = new JSONArray(str);
			for (int i = 0; i < a.length(); i++) {
				Object o = objClass.newInstance();
				String s = a.get(i).toString();
				strToObj(s, o);
				l.add(o);
				s = null;
			}
		} catch (Exception e) {
			str = null;
			e.printStackTrace();
		}
		return l;
	}

	public final static List strToObjList(String str) {
		List l = new ArrayList();
		JSONArray a;
		try {
			a = new JSONArray(str);
			for (int i = 0; i < a.length(); i++) {
				String s = a.get(i).toString();
				l.add(strToObj(s));
				s = null;
			}
		} catch (Exception e) {
			str = null;
			e.printStackTrace();
		}
		return l;
	}

	/**
	 * ֵ�����б�ת����json��ʽ�ַ�
	 * 
	 * @param l
	 * @return
	 */
	public final static String objListToStr(List l) {
		JSONArray a = new JSONArray();
		for (int i = 0; i < l.size(); i++) {
			Object o = l.get(i);
			String s = objectToStr(o);
			a.put(s);
			o = null;
		}
		String r = a.toString();
		l.clear();
		return r;
	}

	private static void emptyJsonObject(Map oldm, JSONObject j) {
		Set kvs = oldm.entrySet();
		Iterator it = kvs.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			j.remove(kv.getKey().toString());
		}
	}

	/**
	 * ��һ�����json��ʽ���ַ�ת���ɶ���
	 * 
	 * @param str
	 *            --����json��ʽ���ַ�
	 * @param obj
	 *            --������ֵ����
	 */
	public final static void strToObj(String str, Object obj) {
		try {
			JSONObject j = new JSONObject(str);
			Iterator it = j.keys();
			Map m = new HashMap();
			while (it.hasNext()) {
				String key = (String) it.next();
				Object v = j.get(key);
				m.put(key, v);
			}
			populate(obj, m);
			emptyJsonObject(m, j);
			j = null;
			m.clear();
			m = null;
		} catch (ParseException e) {
			e.printStackTrace();
			// str = null;
		}
	}

	public final static Object strToObj(String str) {
		try {
			JSONObject j = new JSONObject(str);
			Iterator it = j.keys();
			Map m = new HashMap();
			while (it.hasNext()) {
				String key = (String) it.next();
				Object v = j.get(key);
				m.put(key, v);
			}
			String cn = (String) m.remove("class_Name");
			Object obj = Class.forName(cn).newInstance();
			populate(obj, m);
			emptyJsonObject(m, j);
			j = null;
			m.clear();
			m = null;
			cn = null;
			return obj;
		} catch (Exception e) {
			e.printStackTrace();
			str = null;
			return null;
		}
	}

	/**
	 * ��һ��ֵ����ת����һ��map key=�������� value=����ֵ
	 * 
	 * @param target
	 *            ��Ҫת���Ķ���
	 * @return Map
	 */
	public final static Map describe(Object target) {
		Map retMap = new HashMap();
		List retList = new LinkedList();
		Method[] methods = (Method[]) cache.get(target.getClass());
		if (methods == null) {
			methods = target.getClass().getMethods();
			cache.put(target.getClass(), methods);
		}
		for (int i = 0; i < methods.length; i++) {
			String method = methods[i].getName();
			if (method.indexOf("set") == 0 || method.indexOf("get") == 0) {
				retList.add(method.substring(3, method.length()));
			} else if (method.indexOf("is") == 0) {
				retList.add(method.substring(2, method.length()));
			}
		}
		Collections.sort(retList);
		Object[] props = retList.toArray();
		retList.clear();
		for (int i = 0; i < props.length - 1; i++) {
			if (props[i].equals(props[i + 1])) {
				String prop = decapitalize(props[i].toString());
				retMap.put(prop, getValue(prop, target));
			}
		}
		retList = null;
		return retMap;
	}

	/**
	 * ��Map����»�һ�����Map���ᱻ���
	 * 
	 * @param obj
	 *            --�����Ķ���
	 * @param map
	 *            --�������ݵ�Map
	 */
	public final static void populate(Object obj, Map map) {
		Set s = map.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			String key = "";
			Object o = null;
			Map.Entry me = (Map.Entry) it.next();
			try {
				key = me.getKey().toString();
				o = me.getValue();
				if (o == null) {
					continue;
				}
				setValue(key, obj, o);
			} catch (IllegalArgumentException e) {
				Class type = ObjectUtil.getType(key, obj);
				String tstr = type.toString();
				if (tstr.equals(Integer.class.toString())) {
					ObjectUtil
							.setValue(key, obj, Integer.valueOf(o.toString()));
				} else if (tstr.equals(Long.class.toString())) {
					ObjectUtil.setValue(key, obj, Long.valueOf(o.toString()));
				} else if (tstr.equals(Float.class.toString())) {
					ObjectUtil.setValue(key, obj, Float.valueOf(o.toString()));
				} else if (tstr.equals(Double.class.toString())) {
					ObjectUtil.setValue(key, obj, Double.valueOf(o.toString()));
				} else if (tstr.equals(Short.class.toString())) {
					ObjectUtil.setValue(key, obj, Short.valueOf(o.toString()));
				} else if (tstr.equals(Byte.class.toString())) {
					ObjectUtil.setValue(key, obj, Byte.valueOf(o.toString()));
				} else if (tstr.equals(Date.class.toString())) {
					if (o instanceof Date) {
						ObjectUtil.setValue(key, obj, (Date) o);
					} else {
						long time = ((Double) o).longValue();
						ObjectUtil.setValue(key, obj, new Date(time));
					}
				} else if (tstr.equals(java.sql.Timestamp.class.toString())) {
					if (o instanceof java.sql.Timestamp) {
						ObjectUtil.setValue(key, obj, (Date) o);
					} else {
						long time = ((Double) o).longValue();
						ObjectUtil.setValue(key, obj, new java.sql.Timestamp(
								time));
					}
				} else {
					throw e;
				}
				tstr = null;
				type = null;
			}
		}
	}

	public final static Class getType(String property, Object target) {

		Class ret = Object.class;
		property = "set" + property;

		Method[] methods = (Method[]) cache.get(target.getClass());
		if (methods == null) {
			methods = target.getClass().getMethods();
			cache.put(target.getClass(), methods);
		}

		for (int i = 0; i < methods.length; i++) {

			if (property.equalsIgnoreCase(methods[i].getName())) {

				Class[] paramClass = methods[i].getParameterTypes();
				if (paramClass.length == 1) {
					return paramClass[0];
				}

			}

		}

		return ret;

	}

	/**
	 * ������Ի�ȡ��Ӧ��ֵ
	 * 
	 * @param property
	 *            String
	 * @param target
	 *            Object
	 * @return Object
	 */
	public final static Object getValue(String property, Object target) {

		String get = "get" + property;
		String is = "is" + property;

		Method[] methods = (Method[]) cache.get(target.getClass());
		if (methods == null) {
			methods = target.getClass().getMethods();
			cache.put(target.getClass(), methods);
		}

		for (int i = 0; i < methods.length; i++) {

			if (get.equalsIgnoreCase(methods[i].getName())
					|| is.equalsIgnoreCase(methods[i].getName())) {

				try {
					return methods[i].invoke(target, (Object[]) null);
				} catch (Exception ex) {
					logger.error(ex);
				}
			}
		}
		return null;

	}

	/**
	 * ����һ��������Ե�ֵ
	 * 
	 * @param property
	 *            �������
	 * @param target
	 *            Ŀ�����
	 * @param value
	 *            ����ֵ
	 */
	public final static void setValue(String property, Object target,
			Object value) {
		property = "set" + property;
		Method[] methods = (Method[]) cache.get(target.getClass());
		if (methods == null) {
			methods = target.getClass().getMethods();
			cache.put(target.getClass(), methods);
		}
		for (int i = 0; i < methods.length; i++) {
			if (property.equalsIgnoreCase(methods[i].getName())) {
				Class[] paramClass = methods[i].getParameterTypes();
				if (paramClass.length == 1) {
					try {
						methods[i].invoke(target, new Object[] { value });
					} catch (IllegalArgumentException ille) {
						throw ille;
					} catch (Exception ex) {
						logger.error(ex);
					}
				}
			}
		}
	}

	protected static List getFields(Class clazz) throws Exception {
		List fieldList = new ArrayList();
		Class clazzin = clazz;

		do {
			if (clazzin == null) {
				break;
			}

			fieldList.addAll(Arrays.asList(clazzin.getDeclaredFields()));

			clazzin = clazzin.getSuperclass();
		} while (true);

		return fieldList;
	}

	public static String toString(Object visitable) {
		try {
			if (Boolean.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Byte.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Character.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Class.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Double.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Float.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Integer.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Long.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Number.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Short.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (String.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (StringBuffer.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Void.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (List.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}
			if (Map.class.isAssignableFrom(visitable.getClass())) {
				return visitable.toString();
			}

			List fields = getFields(visitable.getClass());

			StringBuffer buffer = new StringBuffer();

			// Visitar los campos declarados en la clase visitable
			if (fields != null) {
				Field field = null;
				final int size = fields.size();
				for (int i = 0; i < size; i++) {
					field = (Field) fields.get(i);

					// No toma en cuenta el objeto ObjectUtil, ni atributos
					// estaticos
					if (ObjectUtil.class.isAssignableFrom(field.getType())
							|| Modifier.isStatic(field.getModifiers())) {
						continue;
					}

					field.setAccessible(true);

					buffer.append(field.getName() + "=" + field.get(visitable)
							+ ",");
				}
			}

			if (buffer.length() > 0) {
				buffer.deleteCharAt(buffer.length() - 1);

			}
			return "{" + buffer.toString() + "}";
		} catch (Exception ignore) {
			logger.error(ignore);
			return "";
		}
	}

	/**
	 * Indica si algun otro objeto es igual al objeto especificado basandose en
	 * las reglas del metodo <code>equals</code> de la clase <code>Object</code>
	 * 
	 * @param visitable
	 *            - Objeto que se compara
	 * @param obj
	 *            - Objeto con el que se compara
	 * @return <code>True</code> si los objetos son iguales y <code>false</code>
	 *         si son distintos
	 */
	public static boolean equals(Object visitable, Object obj) {
		try {
			Field field = null;
			List fields = getFields(visitable.getClass());

			if (fields != null) {
				final int size = fields.size();
				for (int i = 0; i < size; i++) {
					field = (Field) fields.get(i);

					// No toma en cuenta el objeto ObjectUtil
					if (ObjectUtil.class.isAssignableFrom(field.getType())) {
						continue;
					}

					field.setAccessible(true);

					if (!isEquals(field, visitable, obj)) {
						return false;
					}
				}
			}

			return true;
		} catch (Exception ignore) {
			logger.error(ignore);

			return false;
		}
	}

	protected static boolean isEquals(Field field, Object visitable, Object obj) {
		try {
			String fieldName = field.getName();
			String methodName = "get"
					+ (fieldName.substring(0, 1).toUpperCase() + fieldName
							.substring(1));

			Class[] methodParamTypes = new Class[] {};
			Object[] methodParamValues = new Object[] {};

			Method method1 = visitable.getClass().getMethod(methodName,
					methodParamTypes);
			method1.setAccessible(true);
			Object o1 = method1.invoke(visitable, methodParamValues);

			Method method2 = obj.getClass().getMethod(methodName,
					methodParamTypes);
			method2.setAccessible(true);
			Object o2 = method2.invoke(obj, methodParamValues);

			return o1 == null ? o2 == null : o1.equals(o2);
		} catch (Exception e) {
			e.printStackTrace();
			logger.error(e);
			return false;
		}
	}

	/**
	 * Permite liberar los recursos del sistema o limpiar las variables locales
	 * del objeto especificado segun las reglas definidas en el metodo
	 * <code>finalize</code> de la clase <code>Object</code>
	 * 
	 * @param visitable
	 *            - Objeto del que se liberan sus recursos
	 */
	public static void finalize(Object visitable) {
		try {
			Field field = null;
			List fields = getFields(visitable.getClass());

			if (fields != null) {
				final int size = fields.size();
				for (int i = 0; i < size; i++) {
					field = (Field) fields.get(i);

					// No toma en cuenta el objeto ObjectUtil
					if (ObjectUtil.class.isAssignableFrom(field.getType())) {
						continue;
					}

					field.setAccessible(true);

					if (!field.getType().isPrimitive()) {
						field.set(visitable, null);
					}
				}
			}

			return;
		} catch (Exception ignore) {
			logger.error(ignore);
			return;
		}
	}

	/**
	 * Obtiene el valor hashcode del objeto especificado basandose en las reglas
	 * definidas para el metodo <code>hashCode</code> de la clase
	 * <code>Object</code>
	 * 
	 * @param visitable
	 *            - Objeto a obtener el hashCode
	 * @return El valor hashCode para el objeto visitado
	 */
	public static int hashCode(Object visitable) {
		try {
			Field field = null;
			List fields = getFields(visitable.getClass());
			int hashcode = 0;
			Object obj = null;

			if (fields != null) {
				final int size = fields.size();
				for (int i = 0; i < size; i++) {
					field = (Field) fields.get(i);

					// No toma en cuenta el objeto ObjectUtil, ni atributos
					// estaticos
					if (ObjectUtil.class.isAssignableFrom(field.getType())) {
						continue;
					}

					field.setAccessible(true);

					obj = field.get(visitable);
					hashcode = hashcode ^ (obj != null ? obj.hashCode() : 0);
				}
			}

			return hashcode;
		} catch (Exception ignore) {
			logger.error(ignore);
			return 0;
		}
	}

	public static String arrayToShallowString(Object[] array) {
		try {
			if (array == null) {
				return null;
			}

			StringBuffer buffer = new StringBuffer();

			buffer.append("{");
			for (int i = 0; i < array.length; i++) {
				if (i + 1 == array.length) {
					buffer.append(array[i]);
				} else {
					buffer.append(array[i]).append(",");
				}
			}
			buffer.append("}");

			return buffer.toString();
		} catch (Exception ignore) {
			logger.error(ignore);
			return "";
		}
	}

	public static String arrayToString(Object[] array) {
		try {
			if (array == null) {
				return null;
			}

			StringBuffer buffer = new StringBuffer();

			buffer.append("{");
			for (int i = 0; i < array.length; i++) {
				if (array[i] == null) {
					buffer.append("null");
				} else {
					if (i + 1 == array.length) {
						buffer.append(array[i].getClass().getName() + "="
								+ ObjectUtil.toString(array[i]));
					} else {
						buffer.append(
								array[i].getClass().getName() + "="
										+ ObjectUtil.toString(array[i]))
								.append(",");
					}
				}
			}
			buffer.append("}");

			return buffer.toString();
		} catch (Exception ignore) {
			logger.error(ignore);
			return "";
		}
	}

	public static boolean isEmpty(Object visitable) {
		try {
			List fields = getFields(visitable.getClass());
			if (fields == null) {
				return false;
			}

			Field field = null;
			final int size = fields.size();
			for (int i = 0; i < size; i++) {
				field = (Field) fields.get(i);

				// No toma en cuenta el objeto ObjectUtil
				if (ObjectUtil.class.isAssignableFrom(field.getType())) {
					continue;
				}

				// Se marca como accesible el atributo de la clase
				field.setAccessible(true);

				Object value = field.get(visitable);

				if (value != null) {
					return false;
				}
			}

			return true;
		} catch (Exception ignore) {
			logger.error(ignore);
			return false;
		}
	}
}

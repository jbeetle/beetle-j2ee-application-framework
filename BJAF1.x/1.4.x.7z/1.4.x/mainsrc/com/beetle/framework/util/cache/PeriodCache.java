/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.util.cache;

import java.util.Collection;
import java.util.Set;

import com.beetle.framework.AppRuntimeException;
import com.opensymphony.oscache.base.NeedsRefreshException;
import com.opensymphony.oscache.general.GeneralCacheAdministrator;
import com.opensymphony.oscache.web.filter.ExpiresRefreshPolicy;

public class PeriodCache implements ICache {
	private GeneralCacheAdministrator ga;

	private int period; // sec

	public PeriodCache(int period) {
		ga = new GeneralCacheAdministrator();
		this.period = period;
	}

	/**
	 * Removes all mappings from this cache.
	 * 
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public void clear() {
		ga.flushAll();
		ga.destroy();
	}

	/**
	 * Returns true if this cache contains a mapping for the specified key.
	 * 
	 * @param key
	 *            key whose presence in this cache is to be tested.
	 * @return true if this cache contains a mapping for the specified key.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public boolean containsKey(Object key) {
		try {
			Object o = ga.getFromCache(key.toString());
			if (o != null) {
				return true;
			} else {
				return false;
			}
		} catch (NeedsRefreshException ex) {
			return false;
		}
	}

	/**
	 * Returns the value to which cache maps the specified key.
	 * 
	 * @param key
	 *            key whose associated value is to be returned.
	 * @return the value to which this cache maps the specified key, or null if
	 *         the cache contains no mapping for this key.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public Object get(Object key) {
		try {
			return ga.getFromCache(key.toString(), period);
		} catch (NeedsRefreshException ex) {
			Object obj = ex.getCacheContent();
			if (obj != null)
				obj = null;
			ga.cancelUpdate(key.toString());
			ga.removeEntry(key.toString());
			return null;
		}
	}

	public Object getRecently(Object key) {
		try {
			return ga.getFromCache(key.toString(), period);
		} catch (NeedsRefreshException ex) {
			Object obj = ex.getCacheContent();
			ga.cancelUpdate(key.toString());
			return obj;
		}
	}

	/**
	 * Returns true if this cache contains no key-value mappings.
	 * 
	 * @return true if this cache contains no key-value mappings.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public boolean isEmpty() {
		throw new AppRuntimeException("not implement yet!");
	}

	/**
	 * Returns a set view of the keys contained in this cache.
	 * 
	 * @return a set view of the keys contained in this cache.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public Set keySet() {
		throw new AppRuntimeException("not implement yet!");
	}

	/**
	 * Associates the specified value with the specified key in this cache.
	 * 
	 * @param key
	 *            key with which the specified value is to be associated.
	 * @param value
	 *            value to be associated with the specified key.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public void put(Object key, Object value) {
		ga.putInCache(key.toString(), value, new ExpiresRefreshPolicy(
				this.period));
	}

	/**
	 * Removes the mapping for this key from this cache if it is present.
	 * 
	 * @param key
	 *            key whose mapping is to be removed from the cache.
	 * @todo Implement this com.beetle.framework.util.cache.ICache method
	 */
	public void remove(Object key) {
		ga.cancelUpdate(key.toString());
		ga.removeEntry(key.toString());
	}

	/*
	 * (non-Javadoc) not implement yet
	 */
	public int size() {
		// Cache c=ga.getCache();
		// return c.getSize();
		throw new AppRuntimeException("not implement yet!");
	}

	/*
	 * not implement yet
	 */
	public Set entrySet() {
		throw new AppRuntimeException("not implement yet!");
	}

	/*
	 * not implement yet
	 */
	public Collection values() {
		throw new AppRuntimeException("not implement yet!");
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv;

import com.beetle.framework.AppProperties;
import com.beetle.framework.log.SysLogger;

/**
 * 内存监控器，防止服务器由于内存过低而瘫痪
 * 
 * 
 * @author HenryYu
 * 
 */
public class AppMemoryWatcher extends AppThreadImp {

	public AppMemoryWatcher(int interval) {
		super(interval);
		init(interval);
	}

	private float gcRate;
	private SysLogger logger;
	private int counter;
	private int gcTime;
	private boolean gcFlag;

	public AppMemoryWatcher(String threadName, int MaixIdle, int interval) {
		super(threadName, MaixIdle, interval);
		init(interval);
	}

	private void init(int interval) {
		// this.gcRate =
		// Float.parseFloat(ResourceReader.getParameter("mem-rate"));
		this.gcRate = AppProperties.getAsFloat("routinespool_MEM_RATE", 0.8f);
		this.logger = SysLogger.getInstance();
		this.counter = 0;
		int gcInterval = 1000 * 60 * 10;
		this.gcTime = gcInterval / interval;
		this.gcFlag = false;
	}

	protected void workProc() {
		float memused = memoryUsedRate();
		if (memused >= gcRate) {
			if (!gcFlag) {
				gcFlag = true;
				counter = 0;
				Runtime.getRuntime().gc();
				if (logger.isInfoEnabled()) {
					logger.info(AppMemoryWatcher.class,
							"system jvm called gc()");
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug(AppMemoryWatcher.class, "gcRate=" + gcRate
					+ ",memoryUsedRate=" + memused);
		}
		counter++;
		if (counter >= gcTime) {
			counter = 0;
			gcFlag = false;
		}
	}

	private static float memoryUsedRate() {
		long free = Runtime.getRuntime().freeMemory();
		long total = Runtime.getRuntime().totalMemory();
		return (float) (total - free) / (float) total;
	}

	protected void end() {// 只有调用stopNow方法才触发
		logger.info("[AppMemoryWatcher]" + "stopped.");
	}

}

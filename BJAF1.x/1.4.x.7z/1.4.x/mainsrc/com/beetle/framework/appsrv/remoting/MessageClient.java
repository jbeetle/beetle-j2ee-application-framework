/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.remoting;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

import com.beetle.framework.appsrv.AppRunnable;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.RoutineRunException;
import com.beetle.framework.appsrv.RoutinesPool;
import com.beetle.framework.appsrv.RoutinesPool.WorkThreadPool;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.AesEncrypt;
import com.beetle.framework.util.UUIDGenerator;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;

/**
 * 消息客户端
 * 
 * 
 */
public final class MessageClient {
	/**
	 * 检查连接是否健康
	 * 
	 * 
	 * @return
	 */
	public boolean isAlive() {
		if (socketChannel == null) {
			return false;
		}
		boolean f = socketChannel.socket().isClosed();
		if (f) {
			return false;
		}
		return alive;
	}

	private int threadPoolSizeMinValue;
	private int threadPoolSizeMaxValue;
	private SocketChannel socketChannel = null;
	private ByteBuffer receiveBuffer = null;
	private Selector selector;
	// private OutputStream outStream;
	// private PipedInputStream pipedInputStream;
	private PipedStream pipedStream;
	private final static SysLogger logger = SysLogger
			.getInstance(MessageClient.class);
	private PollWorker pollworker = null;
	private RevWorker revWorker = null;
	private IQueue resOtherQueue;
	private IQueue resInvokeQueue;
	private BlockQueue resSendQueue;
	private volatile boolean alive;
	private RoutinesPool.WorkThreadPool wtp;
	private String sessionId;// 会话id
	private ClientAction clientAction;
	private LinkedHashSet execeptionReqSet;// 存储异常情况下的mid以便容错处理

	public String getSessionId() {
		return sessionId;
	}

	public void registerClientAction(ClientAction clientAction) {
		this.clientAction = clientAction;
	}

	/**
	 * 封装所有客户端需要处理的动作或事件
	 */
	public static abstract class ClientAction {

		/**
		 * 连接中断触发的事件
		 * 
		 * 
		 * @throws MessageCommunicateException
		 */
		protected void connectionBreakEvent()
				throws MessageCommunicateException {
		}

		/**
		 * 服务端响应消息到达事件
		 * 
		 * 
		 * @param msgRes
		 *            ，注意：如果此msgRes被消费掉（清空消息体或设置为null），那么receive方法不会检索到此消息.
		 *            send方式才注册事件
		 * 
		 * @throws MessageCommunicateException
		 */
		protected void msgResArrivedEvent(MsgRes msgRes)
				throws MessageCommunicateException {
		}
	}

	private class RevWorker extends AppRunnable {// 从流里面读数据放入队列以便receive查询

		public RevWorker() {
			super("RevWorker");
		}

		public void run() {
			while (!this.getStopFlag()) {
				try {
					MsgRes res = toMsgRes(pipedStream.getInputStream());// 阻塞
					if (logger.isDebugEnabled()) {
						logger.debug("RevWorker running");
						logger.debug(res);
					}
					if (res == null) {
						continue;
					}
					Header header = res.getHeader();
					if (header != null
							&& header.getMethod().equals(Header.METHOD_SEND)) {// 只有针对send方式才注册事件
						if (clientAction != null) {
							clientAction.msgResArrivedEvent(res);
						}
					}
					if (res != null && !res.isEmpty()) {
						if (header == null || header.getMethod() == null) {
							resOtherQueue.push(res);
						} else {
							if (header.getMethod().equals(Header.METHOD_SEND)) {
								resSendQueue.push(res);
							} else if (header.getMethod().equals(
									Header.METHOD_INVOKE)) {
								resInvokeQueue.push(res);
							} else {
								resOtherQueue.push(res);
							}
						}
					}
				} catch (Exception mce) {
					logger.error("RevWorker err", mce);
					// break;
				}
			}
		}

	}

	/**
	 * 从通道里面往out流写入数据
	 */
	private class PollWorker extends AppRunnable {

		public PollWorker() {
			super("PollWorker");
		}

		public void run() {
			try {
				poll(this.getStopFlag());
			} catch (MessageCommunicateException e) {
				logger.error("PollWorker err", e);
				// throw new AppRuntimeException(e);
			} finally {
				logger.warn("PollWorker end!");
			}
		}

	}

	/**
	 * 指定client端线程池的最小值及最大值。 使用MessageClient()构造函数，默认为5-250
	 * 
	 * @param threadPoolSizeMinValue
	 * @param threadPoolSizeMaxValue
	 */
	public MessageClient(int threadPoolSizeMinValue, int threadPoolSizeMaxValue) {
		super();
		this.threadPoolSizeMinValue = threadPoolSizeMinValue;
		this.threadPoolSizeMaxValue = threadPoolSizeMaxValue;
	}

	/**
	 * 设置扫描流数据的频率
	 * 
	 * @param time
	 *            --毫秒ms，默认为10ms
	 */
	public void scanStreamDataRate(long time) {
		PipedStream.setCheck_data_interval(time);
	}

	public MessageClient() {
		this.threadPoolSizeMaxValue = 250;
		this.threadPoolSizeMinValue = 10;
	}

	private static MsgRes toMsgRes(InputStream is) {
		ObjectInputStream ois = null;
		try {
			ois = new ObjectInputStream(is);
			Object obj = ois.readObject();
			return (MsgRes) obj;
		} catch (Exception e) {
			// logger.error("toMsgRes err", e);
			return null;
		}
	}

	private void receive(SelectionKey key) throws IOException {// poll接收数据
		SocketChannel socketChannel = (SocketChannel) key.channel();
		int count = socketChannel.read(receiveBuffer);
		if (count > 0) {// 有东西
			receiveBuffer.flip();
			byte[] data = new byte[count];
			receiveBuffer.get(data, 0, count);// 读到data数组里面
			OutputStream outStream = pipedStream.getOutputStream();
			outStream.write(data);
			outStream.flush();
		} else if (count < 0) {// 没有了就结束
			// key.cancel();
			socketChannel.close();
			// selector.close();
		}
		receiveBuffer.clear();
	}

	private void poll(boolean stopflag) throws MessageCommunicateException {
		SelectionKey key = null;
		try {
			while (selector.select() > 0 && !stopflag) {
				Set readyKeys = selector.selectedKeys();
				Iterator it = readyKeys.iterator();
				while (it.hasNext()) {
					key = (SelectionKey) it.next();
					it.remove();
					if (key.isReadable()) {
						if (logger.isDebugEnabled()) {
							logger.debug("isReadable...");
						}
						receive(key);
						if (logger.isDebugEnabled()) {
							logger.debug("receive done.");
						}
					} else if (key.isWritable()) {// 保留应该不会触发此事件
						// ...
						if (logger.isDebugEnabled()) {
							logger.debug("isWritable...");
						}
					}
				}
				this.alive = true;
			}
		} catch (Exception e) {
			this.alive = false;
			try {
				if (clientAction != null) {
					clientAction.connectionBreakEvent();
				}
				if (key != null) {
					key.cancel();
					key.channel().close();
				}
			} catch (Exception ex) {
				e.printStackTrace();
			}
			throw new MessageCommunicateException(e);
		}
	}

	private void init(String hostname, int port) throws IOException {
		pipedStream = new PipedStream();
		PipedStream.startConsumerThread(1, false);
		this.wtp = new WorkThreadPool(threadPoolSizeMinValue,
				threadPoolSizeMaxValue, 60 * 1000);
		receiveBuffer = ByteBuffer.allocate(PipedStream.ByteBufferSize);
		socketChannel = SocketChannel.open();
		InetAddress ia = InetAddress.getByName(hostname);
		InetSocketAddress isa = new InetSocketAddress(ia, port);
		socketChannel.connect(isa);
		socketChannel.configureBlocking(false);
		selector = Selector.open();
		// socketChannel.register(selector, SelectionKey.OP_READ
		// | SelectionKey.OP_WRITE);
		socketChannel.register(selector, SelectionKey.OP_READ);
		// PipedOutputStream pos = new PipedOutputStream();
		// pipedInputStream = new PipedInputStream(pos);
		// outStream = new BufferedOutputStream(pos, 1024);
		this.pollworker = new PollWorker();
		pollworker.startAsDaemon();
		this.revWorker = new RevWorker();
		this.revWorker.startAsDaemon();
		this.alive = true;
		// this.resQueue = new BlockQueue();
		this.execeptionReqSet = new LinkedHashSet();
		this.resOtherQueue = new BlockQueue();
		this.resInvokeQueue = new BlockQueue();
		this.resSendQueue = new BlockQueue();
	}

	private final Object sendLock = new Object();

	/**
	 * 发送完req不会clear return mid
	 * 
	 * @param key
	 * @param req
	 */
	private String send(SocketChannel socketChannel, MsgReq req)
			throws MessageCommunicateException {
		synchronized (sendLock) {
			String mid = req.getMessageId();
			if (mid == null || mid.length() == 0) {
				mid = UUIDGenerator.generatePrefixHostUUID(req) + "@mid";// 产生messagid
				req.setMessageId(mid);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("mid:" + mid);
			}
			ByteArrayOutputStream bos = new ByteArrayOutputStream(
					PipedStream.ByteBufferSize);
			ObjectOutputStream oos = null;
			try {
				oos = new ObjectOutputStream(bos);
				oos.writeObject(req);
			} catch (IOException e) {
				// logger.error("req msg convert to byte stream err!", e);
				closeOutputStream(oos);
				closeOutputStream(bos);
				// req.clear();
				throw new MessageCommunicateException(
						"req msg convert to byte stream err!", e);
			}
			ByteBuffer sbuf = ByteBuffer.wrap(bos.toByteArray());
			try {
				while (sbuf.hasRemaining()) {
					try {
						socketChannel.write(sbuf);
					} catch (IOException e) {
						sbuf.clear();
						throw new MessageCommunicateException(
								"socket write buffer err!", e);
					} finally {
						closeOutputStream(oos);
						closeOutputStream(bos);
						// req.clear();
					}
				}
			} finally {
				// sbuf.rewind();
				sbuf.clear();
			}
			return mid;
		}
	}

	private static void closeOutputStream(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			os = null;
		}
	}

	private static void closeInputStream(InputStream is) {
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			is = null;
		}
	}

	/**
	 * 连接服务器
	 * 
	 * 
	 * @param serverAddress
	 *            --A String specifying the server's address in the form
	 *            hostname:portNumber
	 * @param user
	 * @param password
	 * @return true--连接成功；false--连接失败
	 * @throws MessageCommunicateException
	 */
	public boolean connect(java.lang.String serverAddress,
			java.lang.String user, java.lang.String password)
			throws MessageCommunicateException {
		if (serverAddress == null || serverAddress.length() == 0) {
			throw new MessageCommunicateException(
					"serverAddress must be setted!");
		} else {
			if (serverAddress.indexOf(":") < 0) {
				throw new MessageCommunicateException(
						"serverAddress format err! example:hostname:portNumber");
			}
		}
		if (user == null || user.length() == 0) {
			throw new MessageCommunicateException("user must be setted!");
		}
		if (password == null || password.length() == 0) {
			throw new MessageCommunicateException(
					"password must be setted!,can't not be empty");
		}
		String hs[] = serverAddress.split(":");
		try {
			init(hs[0].trim(), Integer.parseInt(hs[1].trim()));
			Header header = new Header();
			// header.setVender("beetleframework1.3.x");
			header.setUser(user);
			header.setPassword(AesEncrypt.encrypt(password));
			this.sessionId = UUIDGenerator.generatePrefixHostUUID(header)
					+ "@sid";
			header.setSessionId(sessionId);
			if (logger.isDebugEnabled()) {
				logger.debug("user:" + user);
				logger.debug("sessionId:" + sessionId);
			}
			MsgReq req = new MsgReq();
			req.setHeader(header);
			// MsgRes res = invoke(req);
			deal(req, Header.METHOD_SEND);
			MsgRes res = receive(1000 * 60);
			if (res == null) {
				throw new MessageCommunicateException(
						"sorry,connect to server timeout!");
			}
			if (logger.isDebugEnabled()) {
				logger.debug("flag:" + res.getReturnFlag());
				logger.debug("msg:" + res.getReturnMsg());
			}
			if (res.getReturnFlag() < 0) {
				this.disconnect();
				return false;
			} else {
				return true;
			}
		} catch (Throwable e) {
			this.disconnect();
			throw new MessageCommunicateException(e);
		}
	}

	/**
	 * 接受服务器正常推送的结果; 此方法会阻塞
	 * 
	 * @return
	 */
	public MsgRes receive() {
		return (MsgRes) resSendQueue.pop();
	}

	/**
	 * 接受服务器正常推送的结果，<br>
	 * 在给定的 timeout时间内会阻塞
	 * 
	 * @param timeout
	 *            --超时时间，单位毫秒ms
	 * @return 等待结果，过了timeout时间返回为null
	 */
	public MsgRes receive(long timeout) {
		return (MsgRes) resSendQueue.pop(timeout);
	}

	/**
	 * 接受服务器非正常推送的不明消息; 此方法会阻塞
	 * 
	 * @return
	 */
	public MsgRes receiveMistyMsg() {
		return (MsgRes) resOtherQueue.pop();
	}

	/**
	 * 直接调用 此方法会阻塞等待结果，如果60s没有结果返回，超时，抛出MessageCommunicateException
	 * 
	 * @param req
	 *            --消息
	 * @return--响应消息
	 * @throws MessageCommunicateException
	 */
	public MsgRes invoke(MsgReq req) throws MessageCommunicateException {
		String mid = deal(req, Header.METHOD_INVOKE);
		MsgRes res = null;
		/*
		 * MsgRes res = receive(); if (res.getMessageId() == null) {
		 * resQueue.push(res); } else { if (res.getMessageId().equals(mid)) {
		 * return res; } else { resQueue.push(res); } }
		 */
		RoutineExecutor re = new RoutineExecutor(this.wtp);
		re.addSubRoutine(new Invoker_T(60, mid));
		try {
			if (logger.isDebugEnabled()) {
				logger.debug("runRoutineForTime-begin[" + mid + "]");
			}
			res = (MsgRes) re.runRoutineForTime();
			if (logger.isDebugEnabled()) {
				logger.debug(res);
				logger.debug("runRoutineForTime-end[" + mid + "]");
			}
			return res;
		} catch (RoutineRunException rre) {
			execeptionReqSet.add(mid);
			throw new MessageCommunicateException(rre);
		} finally {
			re = null;
		}
	}

	/**
	 * 方法同上，可自定义超时时间
	 * 
	 * 
	 * @param req
	 * @param timeout
	 *            -单位是秒s
	 * @return
	 * @throws MessageCommunicateException
	 */
	public MsgRes invoke(MsgReq req, int timeout)
			throws MessageCommunicateException {
		String mid = deal(req, Header.METHOD_INVOKE);
		MsgRes res = null;
		/*
		 * MsgRes res = receive(); if (res.getMessageId() == null) {
		 * resQueue.push(res); } else { if (res.getMessageId().equals(mid)) {
		 * return res; } else { resQueue.push(res); } }
		 */
		RoutineExecutor re = new RoutineExecutor(this.wtp);
		re.addSubRoutine(new Invoker_T(mid));
		try {
			res = (MsgRes) re.runRoutineForTime(timeout);
			return res;
		} catch (RoutineRunException rre) {
			execeptionReqSet.add(mid);
			throw new MessageCommunicateException(rre);
		} finally {
			re = null;
		}
	}

	private class Invoker_T extends SubRoutine {
		public Invoker_T(String mid) {
			super();
			this.mid = mid;
		}

		private String mid;

		public Invoker_T(int maxBlockTime, String mid) {
			super(maxBlockTime);
			this.mid = mid;
		}

		protected void routine() throws InterruptedException {
			MsgRes res = null;
			while (true) {
				res = (MsgRes) resInvokeQueue.pop();
				if (logger.isDebugEnabled()) {
					logger.debug("get res out of queue[resInvokeQueue]");
					logger.debug(res);
				}
				if (res.getMessageId().equals(mid)) {
					if (logger.isDebugEnabled()) {
						logger.debug("res match[" + mid + "],return result");
					}
					this.setResult(res);
					break;
				} else {
					if (logger.isDebugEnabled()) {
						logger.debug(res);
						logger.debug("res not match[" + mid
								+ "],reput queue again!");
					}
					// 若出现异常导致某个请求返回中断，是否会导致此返回一直停留在队列里面
					// 永远没有不会再被消费，成了垃圾数据；必须清理
					if (execeptionReqSet.contains(res.getMessageId())) {
						execeptionReqSet.remove(res.getMessageId());
						logger.warn("due to invoke exception,message["
								+ res.getMessageId() + "] response result["
								+ res.toString() + "] was abandoned");
						res.clear();
					} else {
						resInvokeQueue.push(res);
					}
				}
			}
		}
	}

	/**
	 * 是否有响应结果。 这个结果是服务器推送回来的 (服务器是否有消息返回)
	 * 
	 * @return-true有；false没有
	 */
	public boolean hasArrivedMessage() {
		if (this.resSendQueue == null) {
			return false;
		}
		if (resSendQueue.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 发送消息,req不会清空
	 * 
	 * @param req
	 * @return mid--消息唯一编号
	 * @throws MessageCommunicateException
	 */
	public String send(MsgReq req) throws MessageCommunicateException {
		return deal(req, Header.METHOD_SEND);
	}

	private String deal(MsgReq req, String method)
			throws MessageCommunicateException {
		if (req != null && !req.isEmpty()) {
			makeheader(req, method);
		} else {
			throw new MessageCommunicateException(
					"req can't be null or is empty!");
		}
		return send(this.socketChannel, req);
	}

	private void makeheader(MsgReq req, String method) {
		Header header = req.getHeader();
		if (header == null) {
			header = new Header();
			header.setMethod(method);
			header.setSessionId(getSessionId());
			req.setHeader(header);
		} else {
			header.setMethod(method);
			req.setHeader(header);
		}
	}

	/**
	 * 断开连接，并释放资源
	 */
	public void disconnect() {
		try {
			this.sessionId = null;
			PipedStream.stopConsumerThread();
			if (this.pollworker != null) {
				this.pollworker.stopNow();
			}
			if (this.revWorker != null) {
				this.revWorker.stopNow();
			}
			if (this.socketChannel != null) {
				this.socketChannel.close();
			}
			if (this.receiveBuffer != null) {
				this.receiveBuffer.clear();
			}
			if (this.selector != null) {
				selector.wakeup();
				selector.close();
			}
			if (this.resSendQueue != null) {
				this.resSendQueue.clear();
				this.resSendQueue = null;
			}
			if (this.resOtherQueue != null) {
				this.resOtherQueue.clear();
				this.resOtherQueue = null;
			}
			if (this.resInvokeQueue != null) {
				this.resInvokeQueue.clear();
				this.resInvokeQueue = null;
			}
			this.alive = false;
			if (clientAction != null) {
				clientAction.connectionBreakEvent();
			}
		} catch (Throwable e) {
			logger.error("disconnect", e);
		} finally {
			closeOutputStream(this.pipedStream.getOutputStream());
			closeInputStream(this.pipedStream.getInputStream());
			if (this.wtp != null) {
				this.wtp.shutdownNow();
				this.wtp = null;
			}
		}
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.remoting;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.util.UUIDGenerator;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;

class PipedStream {

	private final PipedOutputStream pipedOS = new PipedOutputStream();
	private volatile boolean doneflag = false;
	private final static IQueue pairQueue = new BlockQueue();
	private final static List consumerList = new ArrayList();
	private String id;
	private static long check_data_interval = 10l;
	public static final int ByteBufferSize = 2048;

	public static void setCheck_data_interval(long checkDataInterval) {
		check_data_interval = checkDataInterval;
	}

	private static class QueueConsumer extends AppThreadImp {

		private IQueue q;
		private boolean workWithRoutine;

		private static class Routiner extends SubRoutine {
			public Routiner(PairValue rpv) {
				super();
				this.rpv = rpv;
			}

			private PairValue rpv;

			protected void routine() throws InterruptedException {
				rpv.copy();
			}

		}

		public QueueConsumer(IQueue q, boolean workWithRoutine, int i) {
			super("QueueConsumer[" + i + "]");
			this.q = q;
			this.workWithRoutine = workWithRoutine;
		}

		protected void workProc() {
			PairValue pv = (PairValue) q.pop();
			if (!pv.isClose()) {
				if (workWithRoutine) {
					Routiner rt = new Routiner(pv);
					if (!RoutineExecutor.runRoutineInCommonPool(rt)) {
						rt.run();
						rt = null;
					}
				} else {
					pv.copy();
				}
			}
		}

	}

	private static class PairValue {
		public PairValue(String id, PipedStream ps) {
			super();
			this.id = id;
			this.ps = ps;
		}

		public boolean isClose() {
			return ps.doneflag;
		}

		public void copy() {
			if (ps.byteArrayOS.size() > 0) {
				byte[] buffer = null;
				synchronized (ps.byteArrayOS) {
					buffer = ps.byteArrayOS.toByteArray();
					ps.byteArrayOS.reset(); // 清除缓冲区
				}
				try {
					// 把提取到的数据发送给PipedOutputStream
					ps.pipedOS.write(buffer, 0, buffer.length);
					ps.pipedOS.flush();
				} catch (Exception e) {
				}
			} else {// 没数据等一下?
				/*
				 * try { OtherUtil.blockSomeTime(this, check_data_interval); }
				 * catch (InterruptedException e) { e.printStackTrace(); }
				 */
				try {
					Thread.sleep(check_data_interval);
				} catch (InterruptedException e) {
				}
			}
			if (!isClose()) {
				pairQueue.push(this);
			}
		}

		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((id == null) ? 0 : id.hashCode());
			return result;
		}

		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			PairValue other = (PairValue) obj;
			if (id == null) {
				if (other.id != null)
					return false;
			} else if (!id.equals(other.id))
				return false;
			return true;
		}

		private String id;
		private PipedStream ps;

	}

	final ByteArrayOutputStream byteArrayOS = new ByteArrayOutputStream() {
		public void close() {
			doneflag = true;
			try {
				super.close();
				pipedOS.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	};

	private final PipedInputStream pipedIS = new PipedInputStream() {
		public void close() {
			doneflag = true;
			try {
				super.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	};

	public PipedStream() throws IOException {
		pipedOS.connect(pipedIS);
		this.id = UUIDGenerator.generate();
		pairQueue.push(new PairValue(id, this));
		// startConsumerThread(consuemrs);
	}

	public InputStream getInputStream() {
		return pipedIS;
	}

	public OutputStream getOutputStream() {
		return byteArrayOS;
	}

	/**
	 * 启动消费者
	 * 
	 * @param consuemrs
	 *            --消费者个数
	 * @param workWithRoutine
	 *            --是否用routine执行还是线程自身执行
	 */
	public static void startConsumerThread(int consuemrs,
			boolean workWithRoutine) {
		synchronized (consumerList) {
			for (int i = 0; i < consuemrs; i++) {
				QueueConsumer qc = new QueueConsumer(pairQueue,
						workWithRoutine, i);
				qc.startAsDaemon();
				consumerList.add(qc);
			}
		}
	}

	public static void stopConsumerThread() {
		synchronized (consumerList) {
			for (int i = 0; i < consumerList.size(); i++) {
				QueueConsumer qc = (QueueConsumer) consumerList.get(i);
				qc.stopNow();
			}
			consumerList.clear();
		}
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.pubsub;

import java.util.Map;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.RoutinesPool.WorkThreadPool;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;

public final class Publisher {
	private IQueue docQueue;
	private static SysLogger logger = SysLogger.getInstance(Publisher.class);
	private RoutineExecutor re;
	private long pubWorkerAmount;
	private Map docSubWorkerMap;

	static Publisher newInstance(int count, Map docSubWorkerMap) {
		return new Publisher(count, docSubWorkerMap);
	}

	private Publisher(int count, Map docSubWorkerMap) {
		this.pubWorkerAmount = 0;
		this.docQueue = new BlockQueue();
		this.docSubWorkerMap = docSubWorkerMap;
		this.re = new RoutineExecutor(new WorkThreadPool(count, count,
				5 * 1000 * 60, 2));
	}

	long getPubWorkerAmount() {
		return pubWorkerAmount;
	}

	void runAndWaitForDone() {
		re.runRoutineParalleJoin();
	}

	void clear() {
		re.shutdownPool();
	}

	void addWorker(PubWorker worker) {
		this.pubWorkerAmount++;
		re.addSubRoutine(worker.setParams(this.docQueue, this.docSubWorkerMap));
	}

	/**
	 * 文档发布者
	 * 
	 */
	public abstract static class PubWorker extends SubRoutine {
		PubWorker setParams(IQueue docQueue, Map docSubWorkerMap) {
			this.docQueue = docQueue;
			this.docSubWorkerMap = docSubWorkerMap;
			return this;
		}

		private Map docSubWorkerMap;
		private IQueue docQueue;

		public PubWorker() {
			super();
		}

		/**
		 * 制造一个Document，以便消费者消费
		 * 
		 * @return
		 * @throws AppRuntimeException
		 */
		protected abstract Document produceDocument()
				throws AppRuntimeException;

		protected void routine() throws InterruptedException {
			Document doc = null;
			try {
				doc = produceDocument();
				if (doc.isLegal(docSubWorkerMap)) {
					this.docQueue.push(doc);
				} else {
					doc.clear();
					logger.warn("this doc is illegal,Document is cleared");
					throw new InterruptedException(
							"this doc is illegal,Document is cleared");
				}
			} catch (Exception e) {
				logger.error(e);
				if (doc != null) {
					doc.clear();
				}
				logger.warn("produce mothod err,Document is cleared");
				throw new InterruptedException(e.getMessage());
			}
		}

	}

	IQueue getDocQueue() {
		return docQueue;
	}

}

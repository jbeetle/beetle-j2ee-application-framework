/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.remoting;

import java.util.HashMap;

/**
 * 消息头数据
 */
public final class Header extends HashMap {

	public String getSessionId() {
		return (String) this.get(beetle_message_sessionid);
	}

	public void setSessionId(String sessionId) {
		this.put(beetle_message_sessionid, sessionId);
	}

	public String getUser() {
		return (String) this.get(beetle_message_user);
	}

	public void setUser(String user) {
		this.put(beetle_message_user, user);
	}

	public String getPassword() {
		return (String) this.get(beetle_message_password);
	}

	public void setPassword(String password) {
		this.put(beetle_message_password, password);
	}

	public Header() {
		super();
		this.setVender(vender);
	}

	private static final String beetle_message_vender = "BEETLE_MESSAGE_VENDER";
	private static final String beetle_message_user = "BEETLE_MESSAGE_USER";
	private static final String beetle_message_password = "BEETLE_MESSAGE_PASSWORD";
	private static final String beetle_message_sessionid = "BEETLE_MESSAGE_SESSIONID";
	private static final long serialVersionUID = 1L;
	private static final String beetle_message_method = "BEETLE_MESSAGE_METHOD";
	private static final String vender = "BeetleJ2EEFramework-1.4.x";
	public static final String METHOD_SEND = "send";
	public static final String METHOD_INVOKE = "invoke";

	public void setMethod(String method) {
		this.put(beetle_message_method, method);
	}

	public String getMethod() {
		return (String) this.get(beetle_message_method);
	}

	private void setVender(String vender) {
		this.put(beetle_message_vender, vender);
	}

	public String getVender() {
		return (String) this.get(beetle_message_vender);
	}
}

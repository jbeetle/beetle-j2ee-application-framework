/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.appsrv.remoting;

import java.util.HashMap;
import java.util.Map;

import com.beetle.framework.resource.define.BaseDTO;

/**
 * 消息响应值对象
 * 
 */
public final class MsgRes extends BaseDTO {
	public static final int FATAL_ERR_FLAG = -1000;

	public static final int SUCCEED_FLAG = 0;

	public static final String SUCCEED_MSG = "ok";

	private static final String beetle_return_flag = "BEETLE_RETURN_FLAG";

	private static final String beetle_return_msg = "BEETLE_RETURN_MSG";

	private static final String beetle_message_id = "BEETLE_MESSAGE_ID";
	private static final String beetle_message_header = "BEETLE_MESSAGE_HEADER";

	public MsgRes() {
		super();
		this.setReturnFlag(SUCCEED_FLAG);
		this.setReturnMsg(SUCCEED_MSG);
	}

	public String getMessageId() {
		return this.getValueAsString(beetle_message_id);
	}

	public void setHeader(Header header) {
		HashMap map = new HashMap();
		map.putAll(header);
		this.setValueWithMap(beetle_message_header, map);
		header.clear();
	}

	public Header getHeader() {
		Map m = getValueAsMap(beetle_message_header);
		Header header = new Header();
		header.putAll(m);
		//m.clear();
		return header;
	}

	public void setMessageId(String messageId) {
		this.setValueWithString(beetle_message_id, messageId);
	}

	private static final long serialVersionUID = 1L;

	/**
	 * 设置处理结果状态
	 * 
	 * @param returnFlag
	 */
	public void setReturnFlag(int returnFlag) {
		this.setValueWithInteger(beetle_return_flag, new Integer(returnFlag));
	}

	public int getReturnFlag() {
		return this.getValueAsInteger(beetle_return_flag).intValue();
	}

	public String getReturnMsg() {
		return this.getValueAsString(beetle_return_msg);
	}

	/**
	 * 描述处理结果说明
	 * 
	 * @param returnMsg
	 */
	public void setReturnMsg(String returnMsg) {
		this.setValueWithString(beetle_return_msg, returnMsg);
	}

}

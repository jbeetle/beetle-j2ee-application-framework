/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.pagination;

/**
 * <p>Title: Beetle Persistence Framework</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: BeetleSoft</p>
 *
 * @author HenryYu (yuhaodong@gmail.com)
 * @version 1.0
 */
import java.util.ArrayList;
import java.util.List;

public class PageResult {
	/**
	 * 当前页号
	 */
	private int curPageNumber;

	private int nextPageNumber;

	private int prePageNumber;

	private int pageAmount;

	private int curPos;

	/**
	 * 当前页面大小
	 */
	private int curPageSize;

	private int recordAmount;

	public PageResult() {
		this.sqlResultSet = new ArrayList();
	}

	/**
	 * 获取当前页面的数据集
	 * 
	 * @return List
	 */
	public List getSqlResultSet() {
		return sqlResultSet;
	}

	/**
	 * 获取当前页号
	 * 
	 * @return int
	 */
	public int getCurPageNumber() {
		return curPageNumber;
	}

	/**
	 * 获取当前页面大小
	 * 
	 * @return int
	 */
	public int getCurPageSize() {
		return curPageSize;
	}

	/**
	 * 获取总记录数
	 * 
	 * @return int
	 */
	public int getRecordAmount() {
		return recordAmount;
	}

	/**
	 * 获取下一页的页号
	 * 
	 * @return int
	 */
	public int getNextPageNumber() {
		return nextPageNumber;
	}

	/**
	 * 获取总页数
	 * 
	 * 
	 * @return int
	 */
	public int getPageAmount() {
		return pageAmount;
	}

	/**
	 * 获取前页号
	 * 
	 * 
	 * @return int
	 */
	public int getPrePageNumber() {
		return prePageNumber;
	}

	/**
	 * 获取当前记录位置
	 * 
	 * @return int
	 */
	public int getCurPos() {
		return curPos;
	}

	/**
	 * 首页页号，为常数1
	 * 
	 * @return int
	 */
	public int getFirstPageNumber() {
		return 1;
	}

	/**
	 * 最后页号
	 * 
	 * 
	 * @return int
	 */
	public int getLastPageNumber() {
		return pageAmount;
	}

	public void setSqlResultSet(List sqlResultSet) {
		if (sqlResultSet != null) {
			this.sqlResultSet.addAll(sqlResultSet);
		}
		// this.sqlResultSe = sqlResultSe.
	}

	public void setCurPageNumber(int curPageNumber) {
		this.curPageNumber = curPageNumber;
	}

	public void setCurPageSize(int curPageSize) {
		this.curPageSize = curPageSize;
	}

	public void setRecordAmount(int recordAmount) {
		this.recordAmount = recordAmount;
	}

	public void setNextPageNumber(int nextPageNumber) {
		this.nextPageNumber = nextPageNumber;
	}

	public void setPageAmount(int pageAmount) {
		this.pageAmount = pageAmount;
	}

	public void setPrePageNumber(int prePageNumber) {
		this.prePageNumber = prePageNumber;
	}

	public void setCurPos(int curPos) {
		this.curPos = curPos;
	}

	/**
	 * 结果集列表
	 */
	private List sqlResultSet;

	/**
	 * 清除内存查询结果
	 */
	public void clearAll() {
		if (!this.sqlResultSet.isEmpty()) {
			this.sqlResultSet.clear();
			this.sqlResultSet = null;
		}

	}
}

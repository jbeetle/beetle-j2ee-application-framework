/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.access.datasource.DriverPool;
import com.beetle.framework.persistence.access.datasource.GenePool;
import com.beetle.framework.persistence.access.datasource.ProxoolPool;
import com.beetle.framework.persistence.access.datasource.XaPool;
import com.beetle.framework.resource.AppContext;
import com.beetle.framework.resource.watch.WatchHelper;
import com.beetle.framework.resource.watch.WatchInfo;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;

/**
 * <p>
 * Title: ConnectionFactory
 * </p>
 * <p>
 * Description: 数据库连接工厂
 * 
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: beetlesoft
 * </p>
 * 
 * @author HenryYu
 * @version 1.0
 */
public class ConnectionFactory {
	private static SysLogger logger = SysLogger
			.getInstance(ConnectionFactory.class);

	private static ICache dsCache = new StrongCache();

	/**
	 * 获取框架实现的数据库缓存器
	 * 
	 * 
	 * @return
	 */
	public static ICache getAllFrameworkDBPool() {
		if (dsCache.isEmpty()) {
			closeConnection(getConncetion("SYSDATASOURCE_DEFAULT")); // to
			// init
		}
		return dsCache;
	}

	/**
	 * 根据数据源（参见DBConfig.xml配置）名称获取 一个数据库连接 （此方法会自动初始化相对应的数据源连接池，从池中返回连接）
	 * 
	 * 
	 * @param dataSourceName
	 * @return
	 * @throws ConnectionException
	 */
	public static Connection getConncetion(String dataSourceName)
			throws ConnectionException {
		Connection conn = null;
		if (WatchHelper.isNeedWatch()) {
			WatchInfo wi = WatchHelper.currentWatch();
			if (wi != null) {
				if (wi.getResourceType() == 1) {
					Object obj = wi.getResourceByName(dataSourceName);
					if (obj != null) {
						conn = (Connection) obj;
						try {
							if (conn != null && !conn.isClosed()) {
								if (logger.isDebugEnabled()) {
									logger.debug("==get connention from cache");
								}
								return conn;
							} else {
								if (logger.isDebugEnabled()) {
									logger.debug("conn.isClosed() case,create new connection");
								}
								conn = null;
								conn = getConncetion_(dataSourceName);
								wi.setResource(dataSourceName, conn);
								return conn;
							}
						} catch (SQLException ex) {
							logger.error(ex);
							throw new ConnectionException(ex);
						}
					} else {
						conn = getConncetion_(dataSourceName);
						wi.setResource(dataSourceName, conn);
						return conn;
					}
				}
			} else {
				conn = getConncetion_(dataSourceName);
			}
		} else {
			conn = getConncetion_(dataSourceName);
		}
		return conn;
	}

	/**
	 * 与getConnection方法类似，支持从此方法返回的数据库连接不参与 beetle的Command业务框架的共享连接池的优化处理
	 * 
	 * 
	 * @param dataSourceName
	 * @return
	 */
	public static Connection newDsConncetion(String dataSourceName) {
		return getConncetion_(dataSourceName);
	}

	private static Connection getConncetion_(String dataSourceName)
			throws ConnectionException {
		if (logger.isDebugEnabled()) {
			logger.debug("==create new connention:" + dataSourceName);
		}
		Connection conn = null;
		int flag = Integer.parseInt(DBConfig
				.getAtWorkValue(DBConfig.DATASOURCE_USE_FLAG));
		switch (flag) {
		case 2:
			conn = fromFramework(dataSourceName);
			break;
		case 3:
			conn = getDebugConn();
			break;
		case 1:
			conn = fromContain(dataSourceName);
			break;
		default: // 1
			conn = fromContain(dataSourceName);
		}
		return conn;
	}

	private static Connection fromFramework(String dataSourceName)
			throws ConnectionException {
		IConnPool pool;
		if (dsCache.containsKey(dataSourceName)) {
			pool = (IConnPool) dsCache.get(dataSourceName);
			return pool.getConnection();
		} else {
			int pool_type = DBConfig.getFrameworkDBType(dataSourceName);
			switch (pool_type) {
			case 1:
				pool = getDriverPool(dataSourceName);
				break;
			case 2:
				pool = getGenePool(dataSourceName);
				break;
			case 3:
				pool = getXaPool(dataSourceName);
				break;
			case 4:
				pool = getProXoolPool(dataSourceName);
				break;
			default:
				String imp = DBConfig.getFrameworkDS(dataSourceName,
						DBConfig.pool_imp);
				pool = getOtherPool(dataSourceName, imp);
			}
			return pool.getConnection();
		}
	}

	private static Connection fromContain(String dataSourceName)
			throws ConnectionException {
		DataSource ds = (DataSource) dsCache.get(dataSourceName);
		if (ds == null) {
			ds = initDatasource(dataSourceName);
		}
		Connection conn = null;
		try {
			conn = ds.getConnection();
		} catch (SQLException ex) {
			dsCache.remove(dataSourceName); // ��գ�����һ��

			ds = initDatasource(dataSourceName);
			try {
				conn = ds.getConnection();
			} catch (SQLException e) {
				logger.error(e);
				throw new ConnectionException(e);
			}
		}
		return conn;
	}

	private synchronized static DataSource initDatasource(String dataSourceName) {
		Context ctx = null;
		try {
			ctx = AppContext.getLocalEJBContainerContext();
			DataSource ds = (DataSource) ctx.lookup(DBConfig
					.getAtWorkValue(dataSourceName.trim()));
			dsCache.put(dataSourceName, ds);
			return ds;
		} catch (NamingException ename) {
			if (ctx != null) {// �Ա����쳣���³�ʼ��context
				try {
					ctx.close();
				} catch (NamingException e) {
					logger.error(e);
				} finally {
					ctx = null;
				}
			}
			AppContext.clearLocalEJBContexts();// ����context����
			logger.error(ename);
			throw new ConnectionException(ename);
		}
	}

	private synchronized static IConnPool getDriverPool(String dataSourceName) {
		IConnPool GeneConnPool = (IConnPool) dsCache.get(dataSourceName);
		if (GeneConnPool == null) {
			int minsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-minsize"));
			int maxsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-maxsize"));
			String drvName = DBConfig.getFrameworkDS(dataSourceName,
					"driver-class");
			String url = DBConfig.getFrameworkDS(dataSourceName,
					"connection-url");
			String user = DBConfig.getFrameworkDS(dataSourceName, "user-name");
			String passwd = DBConfig.getDatasourcePassword(dataSourceName);
			GeneConnPool = new DriverPool(maxsize, minsize, drvName, url, user,
					passwd);
			dsCache.put(dataSourceName, GeneConnPool);
			System.out.println(dataSourceName + "'s driverPool Started!");
		}
		return GeneConnPool;
	}

	private synchronized static IConnPool getOtherPool(String dataSourceName,
			String impStr) {
		IConnPool GeneConnPool = (IConnPool) dsCache.get(dataSourceName);
		if (GeneConnPool == null) {
			int minsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-minsize"));
			int maxsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-maxsize"));
			String drvName = DBConfig.getFrameworkDS(dataSourceName,
					"driver-class");
			String url = DBConfig.getFrameworkDS(dataSourceName,
					"connection-url");
			String user = DBConfig.getFrameworkDS(dataSourceName, "user-name");
			String passwd = DBConfig.getDatasourcePassword(dataSourceName);
			try {
				GeneConnPool = (IConnPool) Class.forName(impStr).newInstance();
				GeneConnPool.setConURL(url);
				GeneConnPool.setDriverName(drvName);
				GeneConnPool.setMax(maxsize);
				GeneConnPool.setMin(minsize);
				GeneConnPool.setUsername(user);
				GeneConnPool.setPassword(passwd);
				GeneConnPool.start();
				dsCache.put(dataSourceName, GeneConnPool);
				System.out.println(dataSourceName + "'s " + impStr
						+ " Started!");
			} catch (Exception e) {
				throw new ConnectionException(e);
			}
		}
		return GeneConnPool;
	}

	private synchronized static IConnPool getProXoolPool(String dataSourceName) {
		IConnPool GeneConnPool = (IConnPool) dsCache.get(dataSourceName);
		if (GeneConnPool == null) {
			int minsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-minsize"));
			int maxsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-maxsize"));
			String drvName = DBConfig.getFrameworkDS(dataSourceName,
					"driver-class");
			String url = DBConfig.getFrameworkDS(dataSourceName,
					"connection-url");
			String user = DBConfig.getFrameworkDS(dataSourceName, "user-name");
			String passwd = DBConfig.getDatasourcePassword(dataSourceName);
			String test_sql = DBConfig.getFrameworkDS(dataSourceName,
					"test-sql");
			GeneConnPool = new ProxoolPool(maxsize, minsize, drvName, url,
					user, passwd, dataSourceName, test_sql);
			dsCache.put(dataSourceName, GeneConnPool);
			System.out.println(dataSourceName + "'s proxoolPool Started!");
		}
		return GeneConnPool;
	}

	private synchronized static IConnPool getGenePool(String dataSourceName) {
		IConnPool GeneConnPool = (IConnPool) dsCache.get(dataSourceName);
		if (GeneConnPool == null) {
			int minsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-minsize"));
			int maxsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-maxsize"));
			String drvName = DBConfig.getFrameworkDS(dataSourceName,
					"driver-class");
			String url = DBConfig.getFrameworkDS(dataSourceName,
					"connection-url");
			String user = DBConfig.getFrameworkDS(dataSourceName, "user-name");
			String passwd = DBConfig.getDatasourcePassword(dataSourceName);
			GeneConnPool = new GenePool(maxsize, minsize, drvName, url, user,
					passwd);
			dsCache.put(dataSourceName, GeneConnPool);
			System.out.println(dataSourceName + "'s genePool Started!");
		}
		return GeneConnPool;
	}

	private static ICache driverCache = new StrongCache();

	/**
	 * 根据数据源（参见DBConfig.xml配置）名称获取 一个数据库连接
	 * (此方法不会初始化对应的连接池，每次都是通过driver创建一个新的数据库连接返回)
	 * 
	 * @param dataSourceName
	 * @return
	 */
	public static Connection newDriverConn(String dataSourceName) {
		try {
			/*
			 * Driver drv = (Driver) Class.forName(
			 * DBConfig.getFrameworkDS(dataSourceName, "driver-class"))
			 * .newInstance(); DriverManager.registerDriver(drv);
			 */
			if (!driverCache.containsKey(dataSourceName)) {
				Class.forName(DBConfig.getFrameworkDS(dataSourceName,
						"driver-class"));
				driverCache
						.put(dataSourceName, DBConfig.getFrameworkDS(
								dataSourceName, "driver-class"));
			}
			return DriverManager.getConnection(
					DBConfig.getFrameworkDS(dataSourceName, "connection-url"),
					DBConfig.getFrameworkDS(dataSourceName, "user-name"),
					DBConfig.getFrameworkDS(dataSourceName, "password"));
		} catch (Exception e) {
			driverCache.remove(dataSourceName);
			throw new ConnectionException(e.getMessage(), e);
		}
	}

	private synchronized static IConnPool getXaPool(String dataSourceName) {
		XaPool XaConnPool = (XaPool) dsCache.get(dataSourceName);
		if (XaConnPool == null) {
			int minsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-minsize"));
			int maxsize = Integer.parseInt(DBConfig.getFrameworkDS(
					dataSourceName, "pool-maxsize"));
			String drvName = DBConfig.getFrameworkDS(dataSourceName,
					"driver-class");
			String url = DBConfig.getFrameworkDS(dataSourceName,
					"connection-url");
			String user = DBConfig.getFrameworkDS(dataSourceName, "user-name");
			String passwd = DBConfig.getDatasourcePassword(dataSourceName);
			XaConnPool = new XaPool(maxsize, minsize, drvName, url, user,
					passwd);
			dsCache.put(dataSourceName, XaConnPool);
			System.out.println(dataSourceName + "'s xaPool Started!");
		}
		return XaConnPool;
	}

	/**
	 * 回收相关资源
	 * 
	 * @param conn
	 *            Connection
	 * @param stm
	 *            Statement
	 * @param res
	 *            ResultSet
	 * @throws ConnectionException
	 */
	public static void closeAll(Connection conn, Statement stm, ResultSet res)
			throws ConnectionException {
		try {
			if (res != null) {
				res.close();
			}
			if (stm != null) {
				stm.close();
			}
		} catch (SQLException ex) {
			throw new ConnectionException(ex);
		} finally {
			if (conn != null) {
				if (!WatchHelper.isNeedWatch()) {
					try {
						conn.close();
					} catch (SQLException e) {
						throw new ConnectionException(e);
					}
				} else {
					WatchInfo wi = WatchHelper.currentWatch();
					if (wi == null) {
						try {
							conn.close();
						} catch (SQLException e) {
							throw new ConnectionException(e);
						}
					}
				}
			}
		}
	}

	/**
	 * 关闭数据库连接
	 * 
	 * 
	 * @param conn
	 *            Connection
	 * @throws ConnectionException
	 */
	public static void closeConnection(Connection conn)
			throws ConnectionException {
		closeAll(conn, null, null);
	}

	private static Connection getDebugConn() {
		try {
			Driver drv = (Driver) Class.forName(
					DBConfig.getDebugDBValue("driver-class")).newInstance();
			DriverManager.registerDriver(drv);
			return DriverManager.getConnection(
					DBConfig.getDebugDBValue("connection-url"),
					DBConfig.getDebugDBValue("user-name"),
					DBConfig.getDebugDBValue("password"));
		} catch (Exception e) {
			e.printStackTrace();
			throw new ConnectionException(e.getMessage());
		}
	}
}

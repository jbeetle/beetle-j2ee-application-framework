/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access;

import java.sql.Connection;
import java.sql.SQLException;

import javax.transaction.Status;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: jdbc事务处理类
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东
 * @version 1.0
 */
public class DBTransaction {
	private int status = Status.STATUS_NO_TRANSACTION;

	private boolean isTranFlag;

	private Connection conn;

	/**
	 * 构造函数
	 * 
	 * @param conn
	 *            数据库连接对象
	 */
	public DBTransaction(Connection conn) {
		this.conn = conn;
		this.isTranFlag = getSupport();
	}

	/**
	 * 提交事务
	 * 
	 * @throws DBTransException
	 */
	public void commit() throws DBTransException {
		try {
			if (conn != null) {
				conn.commit();
			}
			status = Status.STATUS_COMMITTED;
		} catch (SQLException e) {
			throw new DBTransException(e);
		}
	}

	/**
	 * 回滚事务
	 * 
	 * @throws DBTransException
	 */
	public void rollback() throws DBTransException {
		try {
			if (conn != null) {
				conn.rollback();
			}
			status = Status.STATUS_ROLLEDBACK;
		} catch (SQLException e) {
			throw new DBTransException(e);
		}
	}

	/**
	 * 开始一个事务
	 * 
	 * @throws DBTransException
	 */
	public void begin() throws DBTransException {
		status = Status.STATUS_ACTIVE;
		try {
			this.conn.setAutoCommit(false);
		} catch (SQLException se) {
			se.printStackTrace();
		}
	}

	/**
	 * 返回当前事务的状态
	 * 
	 * @throws DBTransException
	 * @return int
	 */
	public int getStatus() throws DBTransException {
		return status;
	}

	/**
	 * 启动数据库连接自动提交事务功能
	 */
	public void enableAutoCommit() throws DBTransException {
		try {
			if (conn != null) {
				conn.setAutoCommit(true);
			}
		} catch (SQLException e) {
			throw new DBTransException(e);
		}
	}

	/**
	 * 是否支持事务
	 * 
	 * @return boolean
	 */
	public boolean isSupportTransaction() {
		return this.isTranFlag;
	}

	private boolean getSupport() {
		try {
			int i = conn.getTransactionIsolation();
			if (i == Connection.TRANSACTION_NONE) {
				return false;
			} else {
				return true;
			}
		} catch (SQLException e) {
			throw new RuntimeException("getTransactionIsolation err", e);
		}
	}
}

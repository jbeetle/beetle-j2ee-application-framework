/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.pagination;

/**
 * <p>Title: Beetle Persistence Framework</p>
 *
 * <p>Description: </p>
 *
 * <p>Copyright: Copyright (c) 2005</p>
 *
 * <p>Company: BeetleSoft</p>
 *
 * @author HenryYu (yuhaodong@gmail.com)
 * @version 1.0
 */
import com.beetle.framework.AppProperties;
import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.persistence.access.DBConfig;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;

/*
 * <!--
 * 1-oracle;2-sqlserver;3-mysql;4-sybase;5-db2;6-PostgreSql;7-InterBase(Firebird)
 * -->
 */

public class PaginationFactory {
	private static ICache cache = new StrongCache();

	private static final String defaultid = "pagination_defaultId";

	// private static String url =
	// "com.beetle.framework.persistence.pagination.Pagination";

	private static final String[] dbids = { "pagination_oracle",
			"pagination_sqlserver", "pagination_mysql", "pagination_sybase",
			"pagination_db2", "pagination_postgresql", "pagination_firebird" };

	public final static String ORACLE_ID = dbids[0];

	public final static String SQLSERVER_ID = dbids[1];

	public final static String MYSQL_ID = dbids[2];

	public final static String SYBASE_ID = dbids[3];

	public final static String DB2_ID = dbids[4];

	public final static String POSTGRESQL_ID = dbids[5];

	public final static String FIREBIRD_ID = dbids[6];

	/**
	 * 返回框架默认分页实现【在DBConfig.xml文件“PAGINATION_DBMS_FLAG”属性设置】
	 * 
	 * @return
	 */
	public static IPagination getPaginationInstance() {
		IPagination ip = (IPagination) cache.get(defaultid);
		if (ip == null) {
			String dbtype = DBConfig.getAtWorkValue("PAGINATION_DBMS_FLAG");
			if (dbtype == null) {
				String classname = AppProperties
						.get(defaultid,
								"com.beetle.framework.persistence.pagination.imp.OraclePaginationImp");
				ip = loadInstance(classname);
			} else {
				int t = Integer.parseInt(dbtype);
				for (int i = 0; i < dbids.length; i++) {
					if (i == (t - 1)) {
						String classname = AppProperties.get(dbids[i]);
						ip = loadInstance(classname);
						break;
					}
				}
			}
		}
		return ip;
	}

	private static IPagination loadInstance(String classname)
			throws AppRuntimeException {
		IPagination ip = null;
		try {
			Object obj = Class.forName(classname).newInstance();
			cache.put(defaultid, (IPagination) obj);
			ip = (IPagination) obj;
		} catch (Exception ex) {
			throw new AppRuntimeException(ex);
		}
		return ip;
	}

	/**
	 * 根据输入数据库标识，返回其对应数据库分页实现
	 * 
	 * @param dbid
	 * @return
	 */
	public static IPagination getPaginationInstance(String dbid) {
		IPagination ip = (IPagination) cache.get(dbid);
		if (ip == null) {
			String classname = AppProperties.get(dbid);
			try {
				Object obj = Class.forName(classname).newInstance();
				cache.put(dbid, obj);
				ip = (IPagination) obj;
			} catch (Exception ex) {
				throw new AppRuntimeException(ex);
			}
		}
		return ip;
	}

}

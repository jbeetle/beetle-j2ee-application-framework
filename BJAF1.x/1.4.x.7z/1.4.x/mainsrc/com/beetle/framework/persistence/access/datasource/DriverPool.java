/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.transaction.TransactionManager;

import com.beetle.framework.appsrv.AppRunnable;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.access.IConnPool;
import com.beetle.framework.util.cache.ConcurrentCache;
import com.beetle.framework.util.cache.ICache;

public class DriverPool implements IConnPool {
	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public void setConURL(String conURL) {
		this.conURL = conURL;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setMin(int min) {
		this.min = min;
	}

	public void setMax(int max) {
		this.max = max;
	}

	private static long _id = 0l;

	private static class PooledConnection {
		private Connection con;
		private boolean available;
		private Long id;

		PooledConnection(Connection con, boolean available) {
			this.con = con;
			this.available = available;
		}

		public Long getId() {
			id = new Long(_id++);
			return id;
		}

		Connection getConnection() {
			return con;
		}

		boolean isAvailable() {
			return available;
		}

		void setAvailable(boolean available) {
			this.available = available;
		}
	}

	private String driverName;
	private String conURL;
	private String username;
	private String password;
	private int min, max;
	private ICache conPool;
	private Driver drv;
	private SysLogger logger;
	private PoolMonitor monitor;

	/**
	 * @param max
	 * @param min
	 * @param driverName
	 * @param conURL
	 * @param username
	 * @param password
	 */
	public DriverPool(int max, int min, String driverName, String conURL,
			String username, String password) {
		this.logger = SysLogger.getInstance(this.getClass());
		this.driverName = driverName;
		this.conURL = conURL;
		this.username = username;
		this.password = password;
		this.max = max;
		this.min = min;
		conPool = new ConcurrentCache(this.max);
		addConnectionsToPool(this.min);
		monitor = new PoolMonitor();
		monitor.startAsDaemon();
	}

	/**
	 * Creates database connection(s) and adds them to the pool.
	 * 
	 * @param numPooledCon
	 * @param driverName
	 * @param conURL
	 * @param username
	 * @param password
	 */
	private synchronized void addConnectionsToPool(int numPooledCon) {
		try {
			if (drv == null) {
				drv = (Driver) Class.forName(driverName).newInstance();
				DriverManager.registerDriver(drv);
			}
			for (int i = 0; i < numPooledCon; i++) {
				Connection con = DriverManager.getConnection(conURL, username,
						password);
				PooledConnection pc = new PooledConnection(con, true);
				conPool.put(pc.getId(), pc);
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}

	private int getAvailableSize() {
		int i = 0;
		Set s = conPool.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			PooledConnection pc = (PooledConnection) kv.getValue();
			if (pc.isAvailable()) {
				i = i + 1;
			}
		}
		return i;
	}

	// synchronized
	private void moniPool() {
		try {
			removeAnyClosedConnections();
			int size = getAvailableSize();
			if (size < this.min) {
				int x = (this.max - this.min) / 2;
				int j = this.min - size;
				if (x > 0) {
					if (x + j > this.max) {
						this.addConnectionsToPool(x);
					} else {
						this.addConnectionsToPool(x + j);
					}
				} else {
					this.addConnectionsToPool(j);
				}
			}
			if (logger.isDebugEnabled()) {
				logger.debug("moniPool...cursize:" + size);
			}
		} catch (Throwable e) {
			logger.error("moniPool", e);
		}
	}

	private synchronized void removeAnyClosedConnections() {
		Set s = conPool.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			PooledConnection pc = (PooledConnection) kv.getValue();
			Connection con = pc.getConnection();
			if (con == null) {
				if (logger.isDebugEnabled()) {
					logger.debug("con is null ,remove pc key=" + kv.getKey());
				}
				conPool.remove(kv.getKey());
				pc = null;
			} else {
				try {
					if (pc.getConnection().isClosed()) {
						if (logger.isDebugEnabled()) {
							logger.debug("con is closed ,remove pc key="
									+ kv.getKey());
						}
						conPool.remove(kv.getKey());
						pc = null;
					}
				} catch (SQLException e) {
					logger.error(e);
				}
			}
		}
	}

	/**
	 * Gets available connection from the pool
	 * 
	 * @return Connection
	 */
	public Connection getConnection() {
		Connection conn = getfrompool();
		if (conn == null) {
			addConnectionsToPool(1);
			conn = getfrompool();
		}
		return conn;
	}

	private synchronized Connection getfrompool() {
		Connection conn = null;
		Set s = conPool.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			PooledConnection pc = (PooledConnection) kv.getValue();
			if (pc.isAvailable()) {
				pc.setAvailable(false); // 标注此连接已经被使用
				conn = pc.getConnection();
				try {
					if (conn.isClosed()) {
						continue;
					} else {
						conn.getMetaData();
						break;
					}
				} catch (Exception e) {
					conn = null;
					logger.error(e);
					continue;
				}
			}
		}
		return conn;
	}

	/**
	 * Closes all connections in the connection pool.
	 */
	public void closeAllConnections() {
		Set s = conPool.entrySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			Map.Entry kv = (Map.Entry) it.next();
			PooledConnection pc = (PooledConnection) kv.getValue();
			closeConnection(pc.getConnection());
		}
		conPool.clear(); // remove all PooledConnections from list
	}

	/**
	 * method closes the given connection
	 * 
	 * @param con
	 *            connection to close
	 * @param dbType
	 *            type of database (used to throw appropriate exception)
	 */
	private void closeConnection(Connection con) {
		try {
			if (con != null) {
				if (!con.isClosed()) {
					con.close();
				}
				con = null;
			}
		} catch (SQLException e) {
			logger.error(e);
		}
	}

	public int getPoolType() {
		return IConnPool.POOL_TYPE_DRIVER; // driver type
	}

	public void setTransactionManager(TransactionManager tm) {
		throw new com.beetle.framework.AppRuntimeException("do not support yet");
	}

	private class PoolMonitor extends AppRunnable {
		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;
		private int time;

		public PoolMonitor() {
			super();
			time = 250;
		}

		protected void stopEvent() {
			closeAllConnections();
		}

		public void run() {
			while (!this.isStoped()) {
				moniPool();
				sleep(time);
				this.resetIdleTime();
			}
		}

	}

	public void shutdown() {
		this.closeAllConnections();
		this.monitor.stopNow();
	}

	public void start() {

	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access.datasource;

import java.sql.Connection;
import java.sql.SQLException;

import javax.transaction.TransactionManager;

import org.enhydra.jdbc.pool.StandardPoolDataSource;
import org.enhydra.jdbc.standard.StandardConnectionPoolDataSource;

import com.beetle.framework.persistence.access.ConnectionException;
import com.beetle.framework.persistence.access.IConnPool;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: J2EEϵͳ�������
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: �׿ǳ����
 * </p>
 * 
 * @author ��ƶ�
 * @version 1.0
 */
public class GenePool implements IConnPool {
	private StandardConnectionPoolDataSource pool;
	private StandardPoolDataSource poolDs;

	public GenePool(int max, int min, String driverName, String conURL,
			String username, String password) {
		pool = new StandardConnectionPoolDataSource();
		try {
			pool.setDriverName(driverName);
			pool.setPassword(password);
			pool.setUser(username);
			pool.setUrl(conURL);
			poolDs = new StandardPoolDataSource(pool);
			poolDs.setMaxSize(max);
			poolDs.setMinSize(min);
			poolDs.setUser(username);
			poolDs.setPassword(password);
		} catch (Exception sqe) {
			throw new com.beetle.framework.AppRuntimeException(
					"create pool err!", sqe);
		}
	}

	/**
	 * closeAllConnections
	 * 
	 * @todo Implement this com.beetle.framework.persistence.db.IConnPool method
	 */
	public void closeAllConnections() {
		if (poolDs != null) {
			poolDs.stopPool();
			poolDs.shutdown(true);
		}
		if (pool != null) {
			pool.shutdown(true);
		}
	}

	/**
	 * getConnection
	 * 
	 * @return Connection
	 * @todo Implement this com.beetle.framework.persistence.db.IConnPool method
	 */
	public Connection getConnection() throws ConnectionException {
		try {
			return poolDs.getConnection();
		} catch (SQLException sqe) {
			throw new ConnectionException("get connection err!", sqe);
		}
	}

	/**
	 * finalize
	 * 
	 * @throws Throwable
	 * @todo Implement this java.lang.Object method
	 */
	protected void finalize() throws Throwable {
		this.closeAllConnections();
		super.finalize();
	}

	public int getPoolType() {
		return IConnPool.POOL_TYPE_GENE; // genepool type
	}

	public void setTransactionManager(TransactionManager tm) {
		throw new UnsupportedOperationException();
	}

	public void setConURL(String conURL) {

	}

	public void setDriverName(String driverName) {

	}

	public void setMax(int max) {

	}

	public void setMin(int min) {

	}

	public void setPassword(String password) {

	}

	public void setUsername(String username) {

	}

	public void shutdown() {
		this.closeAllConnections();
	}

	public void start() {

	}
}

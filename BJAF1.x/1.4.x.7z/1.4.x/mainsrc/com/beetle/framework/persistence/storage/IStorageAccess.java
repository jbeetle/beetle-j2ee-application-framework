/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.storage;

import java.util.List;

/**
 * 存储器操作接口
 * 
 * 
 * @author YUHAODONG yuhaodong@gmail.com
 * 
 */

public interface IStorageAccess {
	/**
	 * 打开存储器
	 * 
	 * @return 0--成功，-1失败
	 */
	int open() throws StorageAccessException;

	/**
	 * 关闭存储器
	 * 
	 * @return 0--成功，-1失败
	 */
	int close() throws StorageAccessException;

	/**
	 * 把一个storageobj对象存储在文件中
	 * 
	 * @param storageObj
	 * @return 1为成功
	 */
	int create(StorageObj storageObj) throws StorageAccessException;

	/**
	 * 批量建立
	 * 
	 * @param storageObjList
	 *            存储对象列表,执行完毕后此列表不会清空
	 * @return
	 */
	int[] createBatch(List storageObjList) throws StorageAccessException;

	/**
	 * 从文件中，根据id把storage对象删除
	 * 
	 * @param id
	 * @return 1为成功；0为不存在此对象
	 */
	int delete(String id) throws StorageAccessException;

	/**
	 * 批量删除
	 * 
	 * @param idList
	 *            id列表
	 * @return
	 */
	int[] deleteBatch(List idList) throws StorageAccessException;

	/**
	 * 根据删除表达式删除文件系统数据
	 * 
	 * 
	 * @param deleteExpression
	 * @param values
	 * @return 成功删除的记录数
	 */
	int delete(String deleteExpression, Object values[])
			throws StorageAccessException;

	/**
	 * 根据id，从文件中找回此对象
	 * 
	 * @param id
	 * @return
	 */
	StorageObj retrieve(String id) throws StorageAccessException;

	/**
	 * 从文件中更新此对象
	 * 
	 * 
	 * @param storageObj
	 * @return 1为成功，0为不存在此对象
	 */
	int update(StorageObj storageObj) throws StorageAccessException;

	/**
	 * 返回当前文件中多少个对象
	 * 
	 * @return
	 */
	int size() throws StorageAccessException;

	/**
	 * 弱更新，只根系StorageObj对象中除了obj属性的属性
	 * 
	 * 
	 * @param storageObj
	 * @return
	 */
	int weakUpdate(StorageObj storageObj) throws StorageAccessException;

	/**
	 * 批量 弱更新，只根系StorageObj对象中除了obj属性的属性
	 * 
	 * 
	 * @param storageObjList
	 * @return
	 */
	int[] weakUpdateBatch(List storageObjList) throws StorageAccessException;

	/**
	 * 根据id，找出此对象，但不包括obj属性数据
	 * 
	 * 
	 * @param id
	 * @return
	 */
	StorageObj peek(String id) throws StorageAccessException;

	/**
	 * 根据表达式，过滤文件中的对象记录集
	 * 
	 * 
	 * @param filterExpression
	 *            --表达式与参见的SQL条件语言语法相一致 [WHERE
	 *            expression[id,createtime,lasttime,status]] [ORDER BY order
	 *            [,...]] [LIMIT expression [OFFSET expression] [SAMPLE_SIZE
	 *            rowCountInt]]
	 * @param values
	 * @return 返回StorageObj对象列表
	 */
	List filter(String filterExpression, Object values[])
			throws StorageAccessException;

	/**
	 * 分页过滤(obj属性不会返回)
	 * 
	 * @param filterExpression
	 * @param values
	 * @param pageNum
	 *            --页号
	 * @param pageSize
	 *            --页大小
	 * 
	 * @return
	 */
	List weakFilterByPage(String filterExpression, Object values[],
			int pageNum, int pageSize) throws StorageAccessException;

	List weakFilterByPage(String filterExpression, Object values[])
			throws StorageAccessException;

	/**
	 * 清空存储文件内容
	 */
	void empty() throws StorageAccessException;

	/**
	 * 根据表达式，过滤文件中的对象记录集的大小
	 * 
	 * @param filterExpression
	 *            --表达式与参见的SQL条件语言语法相一致 [WHERE
	 *            expression[id,createtime,lasttime,status]] [ORDER BY order
	 *            [,...]] [LIMIT expression [OFFSET expression] [SAMPLE_SIZE
	 *            rowCountInt]]
	 * @param values
	 * @return 对象记录集的大小
	 */
	int filterSize(String filterExpression, Object values[])
			throws StorageAccessException;

	/**
	 * 分页过滤
	 * 
	 * @param filterExpression
	 * @param values
	 * @param pageNum
	 *            --页号
	 * @param pageSize
	 *            --页大小
	 * 
	 * @return
	 */
	List filterByPage(String filterExpression, Object values[], int pageNum,
			int pageSize) throws StorageAccessException;

	/**
	 * 删除索引
	 * 
	 * @param fieldName
	 *            -[createtime,lasttime,status,objtype]
	 */
	void dropIndex(String fieldName) throws StorageAccessException;

	/**
	 * 建议索引，优化查询
	 * 
	 * 
	 * @param fieldName
	 *            -[createtime,lasttime,status,objtype]
	 */
	void createIndex(String fieldName) throws StorageAccessException;

	/**
	 * 重建索引
	 * 
	 * @param filedName
	 *            -[createtime,lasttime,status,objtype]
	 */
	void rebuildIndex(String filedName) throws StorageAccessException;
}

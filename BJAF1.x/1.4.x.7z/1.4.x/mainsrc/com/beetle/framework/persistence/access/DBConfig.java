/*
 * BJAF - Beetle J2EE Application Framework
 * �׿ǳ�J2EE��ҵӦ�ÿ������
 * ��Ȩ����2003-2009 ��ƶ� (www.beetlesoft.net)
 * 
 * ����һ����ѿ�Դ�������������ڡ��׿ǳ�J2EEӦ�ÿ�������ȨЭ�顷
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   ��GNU Lesser General Public License v3.0��
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>�ºϷ�ʹ�á��޸Ļ����·�����
 *
 * ��л��ʹ�á��ƹ㱾��ܣ����н�������⣬��ӭ�������ϵ��
 * �ʼ��� <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.persistence.access;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.resource.FrameworkContext;
import com.beetle.framework.resource.ResourceReader;
import com.beetle.framework.resource.define.CfgFileInfo;
import com.beetle.framework.util.AesEncrypt;
import com.beetle.framework.util.OtherUtil;
import com.beetle.framework.util.ResourceLoader;
import com.beetle.framework.util.XMLProperties;

public class DBConfig {
	private static Map debugDBTable = new HashMap();

	private static Map dbPool = new HashMap();

	private static Map atworkTable = new HashMap();

	public static void resetDBConfig() {
		atworkTable.clear();
		dbPool.clear();
		loadAtWorkTable();
	}

	private static void markCfgInfo(File f, String filename) {
		String smfn = OtherUtil.removePath(filename);
		FrameworkContext ctx = FrameworkContext.getInstance();
		try {
			if (ctx.lookup(smfn) == null) {
				CfgFileInfo cfi = new CfgFileInfo();
				cfi.setFilename(smfn);
				cfi.setLastFileModifiedTime(f.lastModified());
				cfi.setLastReadTime(System.currentTimeMillis());
				cfi.setModifyCount(0);
				cfi.setPath(filename);
				ctx.bind(smfn, cfi);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getFrameworkDS(String dsName, String keyName) {
		if (!dbPool.containsKey(dsName)) {
			Map m = readeConfig("Config.DataSources." + dsName.trim(), "name",
					"value");
			dbPool.put(dsName, m);
			// m.clear();
		}
		Map m = (Map) dbPool.get(dsName);
		return (String) m.get(keyName);
	}

	public final static String getDatasourcePassword(String dataSourceName) {
		int mask = ResourceReader.getSYSCONFIG_MASK();
		if (mask == 1) {
			String pwd = DBConfig.getFrameworkDS(dataSourceName, "password");
			pwd = AesEncrypt.decrypt(pwd);
			return pwd;
		} else {
			return DBConfig.getFrameworkDS(dataSourceName, "password");
		}
	}

	private final static Map readeConfig(String v1, String v2, String v3) {
		Map m = null;
		File f = null;
		try {
			String filename = ResourceReader.getAPP_HOME()
					+ "config/DBConfig.xml";
			f = new File(filename);
			if (f.exists()) {
				//
				markCfgInfo(f, filename);
				//
				m = XMLProperties.getProperties(filename, v1, v2, v3);
				SysLogger.getInstance(DBConfig.class).info(
						"from file:[" + f.getPath() + "]");
			} else {
				m = XMLProperties.getProperties(
						ResourceLoader.getResAsStream(filename), v1, v2, v3);
				SysLogger.getInstance(DBConfig.class).info(
						"from jar:["
								+ ResourceLoader.getClassLoader().toString()
								+ "]");
			}
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (f != null) {
				f = null;
			}
		}
		return m;
	}

	public static String getDebugDBValue(String keyName) {
		if (debugDBTable.isEmpty()) {
			loadDebugDBTable();
		}
		return (String) debugDBTable.get(keyName);
	}

	private static synchronized void loadDebugDBTable() {
		if (debugDBTable.isEmpty()) {
			// Map m = XMLProperties.getProperties(sysconfigFileName,
			// "Config.DataSources.DebugDB",
			// "name",
			// "value");
			Map m = readeConfig("Config.DataSources.DebugDB", "name", "value");
			debugDBTable.putAll(m);
			m.clear();
		}
	}

	public static boolean isOnlyDatasourceUsed() {
		if (atworkTable.isEmpty()) {
			loadAtWorkTable();
		}
		int i = 0;
		Set s = atworkTable.keySet();
		Iterator it = s.iterator();
		while (it.hasNext()) {
			String a = (String) it.next();
			if (a.startsWith("SYSDATASOURCE_")) {
				i++;
			}
		}
		if (i > 1) {
			return false;
		} else {
			return true;
		}
	}

	public static int getFrameworkDBType(String datasourcename) {
		int pool_type = 1;
		String imp = DBConfig.getFrameworkDS(datasourcename, DBConfig.pool_imp);
		if (imp == null || imp.equals(DBConfig.emptyStr)) {
			pool_type = Integer.parseInt(DBConfig.getFrameworkDS(
					datasourcename, DBConfig.pool_type));
		} else {
			if (imp.equals(DBConfig.pool_driver)) {
				pool_type = 1;
			} else if (imp.equals(DBConfig.pool_general)) {
				pool_type = 2;
			} else if (imp.equals(DBConfig.pool_xa)) {
				pool_type = 3;
			} else if (imp.equals(DBConfig.pool_proxool)) {
				pool_type = 4;
			} else {
				pool_type = 100;
			}
		}
		return pool_type;
		// String t = getFrameworkDS(SYSDATASOURCE_DEFAULT, pool_type);
		// return Integer.parseInt(t.trim());
	}

	public static String getAtWorkValue(String name) {
		if (atworkTable.isEmpty()) {
			loadAtWorkTable();
		}
		return (String) atworkTable.get(name);
	}

	private static synchronized void loadAtWorkTable() {
		if (atworkTable.isEmpty()) {
			// Map m = XMLProperties.getProperties(sysconfigFileName,
			// "Config.AtWork", "name",
			// "value");
			Map m = readeConfig("Config.AtWork", "name", "value");
			atworkTable.putAll(m);
			m.clear();
		}
	}

	public static final String SYSDATASOURCE_DEFAULT = "SYSDATASOURCE_DEFAULT";
	static final String DATASOURCE_USE_FLAG = "DATASOURCE_USE_FLAG";
	static final String pool_type = "pool-type";
	static final String pool_imp = "pool-imp";
	static final String pool_driver = "com.beetle.framework.persistence.access.datasource.DriverPool";
	static final String pool_general = "com.beetle.framework.persistence.access.datasource.GenePool";
	static final String pool_xa = "com.beetle.framework.persistence.access.datasource.XaPool";
	static final String pool_proxool = "com.beetle.framework.persistence.access.datasource.ProxoolPool";
	static final String emptyStr = "";

	// to test
	public static void main(String arg[]) {
		System.out.println(DBConfig
				.getAtWorkValue(DBConfig.DATASOURCE_USE_FLAG));
	}
}

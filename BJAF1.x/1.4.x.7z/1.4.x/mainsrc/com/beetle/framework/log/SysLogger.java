/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.log;

import java.io.File;
import java.net.URL;
import java.util.Properties;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

/**
 * <p>
 * Title:
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: 甲壳虫科技
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0 使用:static SysLoger logger =
 *          SysLoger.getSysLogerInstance(类名.class)
 */

public final class SysLogger {
	private Logger logger;
	private static SysLogger sl = null;
	private static SysLogger root = null;

	private SysLogger(Class logClass) {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init();
		}
		logger = Logger.getLogger(logClass);
	}

	private SysLogger() {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init();
		}
		logger = Logger.getRootLogger();
	}

	private SysLogger(String className) {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init();
		}
		logger = Logger.getLogger(className);
	}

	/*
	 * static { if (!LogConfigReader.isInited()) { LogConfigReader.init(); } }
	 */
	public static SysLogger getRootInstance() {
		if (root == null) {
			root = new SysLogger();
		}
		return root;
	}

	/**
	 * 在运行时修改了配置文件，可以通过此方法重载配置，以便修改见效
	 */
	public synchronized static void reloadLogConfig() {
		SysLogger log = getRootInstance();
		LogConfigReader.reload();
		log.info("reloadLogConfig ok");
	}

	public synchronized static void reloadLogConfig(Properties pro) {
		SysLogger log = getRootInstance();
		LogConfigReader.reload(pro);
		log.info("reloadLogConfig ok");
	}

	/**
	 * 获取系统默认的logger，打印信息由此系统logger输出。 使用此方法获取logger可在系统共享一个实例，节约内存
	 * 
	 * @return SysLogger
	 */
	public static SysLogger getInstance() {
		if (sl == null) {
			sl = new SysLogger(SysLogger.class);
		}
		return sl;
	}

	/**
	 * 获取系统日志记录实例
	 * 
	 * @param logClassName
	 *            需要注册一个日志的类
	 * 
	 * @return 系统日志实例
	 */
	public static SysLogger getInstance(Class logClass) {
		return new SysLogger(logClass);
	}

	/**
	 * 获取系统日志记录实例
	 * 
	 * @param className
	 *            需要注册一个日志名称
	 * 
	 * @return 系统日志实例
	 */
	public static SysLogger getInstance(String Name) {
		return new SysLogger(Name);
	}

	private SysLogger(File configFile, String name) {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init(configFile);
		}
		logger = Logger.getLogger(name);
	}

	/**
	 * 指定配置文件创建一个logger,注意：在一个instance中只有一个syslogger，如果配置不同，调用此方法加载多次，
	 * 则只有首次加载的配置有效。
	 * 
	 * @param configFile
	 * @param name
	 * @return
	 */
	public static SysLogger getInstance(File configFile, String name) {
		return new SysLogger(configFile, name);
	}

	private SysLogger(URL url, String name) {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init(url);
		}
		logger = Logger.getLogger(name);
	}

	private SysLogger(Properties pro, String name) {
		if (!LogConfigReader.isInited()) {
			LogConfigReader.init(pro);
		}
		logger = Logger.getLogger(name);
	}

	public static SysLogger getInstance(URL url, String name) {
		return new SysLogger(url, name);
	}

	public static SysLogger getInstance(Properties pro, String name) {
		return new SysLogger(pro, name);
	}

	/**
	 * isDebugEnabled
	 * 
	 * @return boolean
	 */
	public boolean isDebugEnabled() {
		return logger.isDebugEnabled();
	}

	/**
	 * 设置当前日志的输入级别
	 * 
	 * @param level
	 *            1--debug; 2--info; 3--warn; 4--error; 5--fatal
	 */
	public void setLevel(int level) {
		if (level == 1) {
			logger.setLevel(Level.DEBUG);
		} else if (level == 2) {
			logger.setLevel(Level.INFO);
		} else if (level == 3) {
			logger.setLevel(Level.WARN);
		} else if (level == 4) {
			logger.setLevel(Level.ERROR);
		} else if (level == 5) {
			logger.setLevel(Level.FATAL);
		}
	}

	/**
	 * isInfoEnabled
	 * 
	 * @return boolean
	 */
	public boolean isInfoEnabled() {
		return logger.isInfoEnabled();
	}

	/**
	 * error
	 * 
	 * @param parm1
	 *            Object
	 * @param parm2
	 *            Throwable
	 */
	public void error(Object parm1, Throwable parm2) {
		logger.error(parm1, parm2);
	}

	public void error(Class markClass, String message) {
		logger.error("[" + markClass.getName() + "]" + message);
	}

	public void error(Class markClass, String message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.error("[" + markClass.getName() + "]" + message, t);
	}

	/**
	 * fatal
	 * 
	 * @param message
	 *            Object
	 */
	public void fatal(Object message) {
		logger.fatal(message);
	}

	public void fatal(Class markClass, String message) {
		logger.fatal("[" + markClass.getName() + "]" + message);
	}

	public void fatal(Class markClass, String message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.fatal("[" + markClass.getName() + "]" + message, t);
	}

	/**
	 * info
	 * 
	 * @param message
	 *            Object
	 */
	public void info(Object message) {
		logger.info(message);
	}

	public void info(Class markClass, String message) {
		logger.info("[" + markClass.getName() + "]" + message);
	}

	public void info(Class markClass, String message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.info("[" + markClass.getName() + "]" + message, t);
	}

	/**
	 * info
	 * 
	 * @param message
	 *            Object
	 * @param t
	 *            Throwable
	 */
	public void info(Object message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.info(message, t);
	}

	/**
	 * warn
	 * 
	 * @param message
	 *            Object
	 */
	public void warn(Object message) {
		logger.warn(message);
	}

	public void warn(Class markClass, String message) {
		logger.warn("[" + markClass.getName() + "]" + message);
	}

	public void warn(Class markClass, String message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.warn("[" + markClass.getName() + "]" + message, t);
	}

	/**
	 * warn
	 * 
	 * @param message
	 *            Object
	 * @param t
	 *            Throwable
	 */
	public void warn(Object message, Throwable t) {
		logger.warn(message, t);
	}

	/**
	 * fatal
	 * 
	 * @param parm1
	 *            Object
	 * @param parm2
	 *            Throwable
	 */
	public void fatal(Object parm1, Throwable parm2) {
		logger.fatal(parm1, parm2);
	}

	/**
	 * debug
	 * 
	 * @param message
	 *            Object
	 */
	public void debug(Object message) {
		logger.debug(message);
	}

	public void debug(Class markClass, String message) {
		logger.debug("[" + markClass.getName() + "]" + message);
	}

	public void debug(Class markClass, String message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.debug("[" + markClass.getName() + "]" + message, t);
	}

	/**
	 * debug
	 * 
	 * @param message
	 *            Object
	 * @param t
	 *            Throwable
	 */
	public void debug(Object message, Throwable t) {
		if (t != null) {
			t.printStackTrace();
		}
		logger.debug(message, t);
	}

	/**
	 * error
	 * 
	 * @param message
	 *            Object
	 * @todo Implement this org.apache.log4j.Category method
	 */
	public void error(Object message) {
		if (message == null) {
			return;
		}
		if (message instanceof Throwable) {
			Throwable t = (Throwable) message;
			error(t.getMessage(), t);
		} else {
			logger.error(message);
		}
	}

	public String getStackTraceInfo(Throwable t) {
		return getErrStackTraceInfo(t);
	}

	/**
	 * 把错误堆栈信息封装成字符串
	 * 
	 * 
	 * @param t
	 * @return
	 */
	public static String getErrStackTraceInfo(Throwable t) {
		java.io.CharArrayWriter cw = new java.io.CharArrayWriter();
		java.io.PrintWriter pw = new java.io.PrintWriter(cw, true);
		t.printStackTrace(pw);
		String info = cw.toString();
		cw.close();
		cw = null;
		pw.close();
		pw = null;
		return info;
	}
}

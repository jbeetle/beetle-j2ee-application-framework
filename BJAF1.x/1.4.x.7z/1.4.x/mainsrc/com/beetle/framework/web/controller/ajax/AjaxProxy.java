/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller.ajax;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.tools.CommonUtil;

public class AjaxProxy implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private transient HttpServletRequest request;

	private transient HttpServletResponse response;

	public AjaxProxy() {

	}

	private static ICache actionCache = new StrongCache();

	public static Map strToMap(String requestParameter)
			throws NoSuchElementException, ParseException {
		Map params = new HashMap();
		JSONObject o = new JSONObject(requestParameter);
		Object m = o.get("map");
		JSONObject o2 = new JSONObject(m.toString());
		Iterator it = o2.keys();
		while (it.hasNext()) {
			Object obj = it.next();
			params.put(obj, o2.get(obj.toString()));
		}
		o = null;
		o2 = null;
		return params;
	}

	private static final String AJAX_REQUEST_NAME = "AJAX_REQUEST_NAME";
	private static final String GLOBAL_FRONTCALL_FLAG = "GLOBAL_FRONTCALL_FLAG";
	private static final String GLOBAL_BACKCALL_FLAG = "GLOBAL_BACKCALL_FLAG";

	/*
	 * requestParameter example format: "{'javaClass': 'java.util.Hashtable',
	 * 'map': {'AJAX_REQUEST_NAME':'xxx.ajax','name': 'Henry', 'email':
	 * 'henryyu@163.com', '1': {'foo': 'foo 1', 'javaClass': 'Example.Wiggle',
	 * 'bar': 1}}}";
	 */
	public Map execute(String requestParameter) throws Exception {
		Map rM = new Hashtable();
		Map params = strToMap(requestParameter); // ת���ɲ���Map
		Map config = AjaxConfig.getAjaxConfig(null);
		String key = params.get(AJAX_REQUEST_NAME).toString();
		String actionClassName = (String) config.get(key);
		Object actionObj = null;
		if (actionClassName == null) {// 在配置文件中找不到，按0配置方式找
			actionClassName = (String) this.request
					.getAttribute(CommonUtil.controllerimpclassname);
			actionClassName = actionClassName.replaceFirst(
					AjaxConfig.AJAX_FRAMEWORK_NAME, CommonUtil.formatPath(key));
			config.put(key, actionClassName);
		}
		if (actionClassName != null) {
			actionObj = actionCache.get(key);
			if (actionObj == null) {
				try {
					actionObj = Class.forName(actionClassName).newInstance();
					if (ReflectUtil.isThreadSafe(actionObj.getClass())) {
						actionCache.put(key, actionObj);
					}
				} catch (Exception ex) {
					ex.printStackTrace();
					params.clear();
					throw ex;
				}
			}
			AjaxResponse aresponse;
			AjaxRequest arequest = new AjaxRequest(params, this.request,
					this.response);
			if (arequest.getParameterAsBoolean(GLOBAL_FRONTCALL_FLAG)
					.booleanValue()) {
				ICommonAjax precall = AjaxConfig.getPreCall();
				if (precall != null) {
					aresponse = precall.perform(arequest);
					if (aresponse.isBreakFlag()) {
						setMap(rM, aresponse);
						params.clear();
						aresponse.clear();
						return rM; // ֱ�ӷ���
					} else {
						rM.putAll(aresponse);
						aresponse.clear();
					}
				}
			}
			ICommonAjax comAjax = (ICommonAjax) actionObj;
			aresponse = comAjax.perform(arequest);
			setMap(rM, aresponse);
			if (arequest.getParameterAsBoolean(GLOBAL_BACKCALL_FLAG)
					.booleanValue()) {
				ICommonAjax backCall = AjaxConfig.getBackCall();
				if (backCall != null) {
					aresponse = backCall.perform(arequest);
					if (aresponse.isBreakFlag()) {
						setMap(rM, aresponse);
						params.clear();
						aresponse.clear();
						return rM; // ֱ�ӷ���
					} else {
						rM.putAll(aresponse);
					}
				}
			}
			params.clear();
			aresponse.clear();
		} else {
			params.clear();
			throw new Exception(
					"can't find controller class,check your config please!");
		}
		return rM;
	}

	private void setMap(Map rM, AjaxResponse aresponse) {
		rM.put("ReturnMsg", aresponse.getReturnMsg());
		rM.put("ReturnFlag", new Integer(aresponse.getReturnFlag()));
		rM.putAll(aresponse);
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}
	/*
	 * public static void main(String arg[]) throws ParseException { String a =
	 * "{'javaClass': 'java.util.Hashtable', 'map': {'name': 'Henry', 'email':
	 * 'henryyu@163.com', 'myObj': {'foo': 'foo 1', 'javaClass':
	 * 'Example.Wiggle', 'bar': 1}}}"; Map m = strToMap(a); AjaxRequest ax = new
	 * AjaxRequest(m); System.out.println(ax.getParameter("name"));
	 * Example.Wiggle w = (Example.Wiggle) ax.getParameterAsObject("myObj");
	 * System.out.println(w.getBar()); System.out.println(w.getFoo()); }
	 */
}

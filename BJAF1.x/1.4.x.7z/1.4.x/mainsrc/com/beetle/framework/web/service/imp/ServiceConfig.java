/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.service.imp;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletContext;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

public class ServiceConfig {

	private static Map url_serivicAttr = new HashMap();

	private static boolean read_flag = false;

	private static ServiceConfig instance = new ServiceConfig();

	private ServiceConfig() {
	}

	private static String convertPath(String aStr) {
		return "//".concat(aStr.replace('.', '/'));
	}

	public synchronized void readServices(InputStream xmlIs) {
		url_serivicAttr.clear();
		if (xmlIs == null) {
			return;
		}
		SAXReader reader = new SAXReader();
		try {
			Document doc = reader.read(xmlIs);
			Node node = doc.selectSingleNode(convertPath("mappings.service"));
			if (node != null) {
				Iterator it = node.selectNodes("srvItem").iterator();
				while (it.hasNext()) {
					ServiceAttr attr = new ServiceAttr();
					Element e = (Element) it.next();
					attr.setName(e.valueOf("@name"));
					String face = e.valueOf("@interface");
					if (face == null || face.equals("")) {
						face = "com.beetle.framework.web.service.ICommonService";
					}
					attr.setInterFace(face);
					attr.setImpClass(e.valueOf("@class"));
					url_serivicAttr.put(attr.getName(), attr);
				}
			}
		} catch (Exception de) {
			de.printStackTrace();
		}
	}

	public static Map getServices(ServletContext app) {
		if (!read_flag) {
			instance.readServices(app
					.getResourceAsStream("/config/WebController.xml"));
			// ���ҵ���3��rpc������
			fillDefineSrv(
					"com.beetle.framework.business.common.rpcserver.ServiceCmdImp",
					"COMMAND.service",
					"com.beetle.framework.business.common.rpcserver.IRpcService");
			fillDefineSrv(
					"com.beetle.framework.business.common.rpcserver.ServiceDelegateImp",
					"DELEGATE.service",
					"com.beetle.framework.business.common.rpcserver.IRpcService");
			fillDefineSrv(
					"com.beetle.framework.business.common.rpcserver.ServiceMsgImp",
					"MESSAGE.service",
					"com.beetle.framework.business.common.rpcserver.IRpcService");
			fillDefineSrv(
					"com.beetle.framework.business.msgfacade.receive.ReceiveOtcService",
					"PUSHER.service",
					"com.beetle.framework.business.common.rpcserver.IRpcService");
			fillDefineSrv("com.paic.amesb.facade.receive.ReceiveOtcService",
					"PUSHERX.service",
					"com.beetle.framework.business.common.rpcserver.IRpcService");
			read_flag = true;
		}
		return url_serivicAttr;
	}

	private static void fillDefineSrv(String impclass, String name, String face) {
		ServiceAttr attr = new ServiceAttr();
		attr.setImpClass(impclass);
		attr.setInterFace(face);
		attr.setName(name);
		url_serivicAttr.put(attr.getName(), attr);
	}

	public static Map getServices(InputStream xmlIs) {
		if (!read_flag) {
			instance.readServices(xmlIs);
			read_flag = true;
		}
		return url_serivicAttr;
	}
}

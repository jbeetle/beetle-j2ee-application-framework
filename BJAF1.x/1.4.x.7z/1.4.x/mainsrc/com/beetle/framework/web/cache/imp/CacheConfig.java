/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.cache.imp;

/**
 * @author Henry Yu 2005-9-27
 *
 */
import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;
import org.dom4j.io.SAXReader;

public class CacheConfig {

	private final static Map url_cacheAttr = new HashMap();
	private static boolean read_flag = false;
	private static CacheConfig instance = new CacheConfig();

	private CacheConfig() {
	}

	private static String convertPath(String aStr) {
		return "//".concat(aStr.replace('.', '/'));
	}

	public synchronized void readCacheURLs(InputStream xmlIs) {
		url_cacheAttr.clear();
		if (xmlIs == null) {
			return;
		}
		SAXReader reader = new SAXReader();
		Document doc = null;
		try {
			doc = reader.read(xmlIs);
			Node node = doc.selectSingleNode(convertPath("mappings.caches"));
			if (node != null) {
				Iterator it = node.selectNodes("cItem").iterator();
				while (it.hasNext()) {
					CacheAttr attr = new CacheAttr();
					Element e = (Element) it.next();
					attr.setUrl(e.valueOf("@name"));
					attr.setScope(e.valueOf("@scope"));
					attr.setTime(toInt(e.valueOf("@time")));
					url_cacheAttr.put(attr.getUrl(), attr);
				}
			}
		} catch (Exception de) {
			de.printStackTrace();
		} finally {
			if (doc != null) {
				doc.clearContent();
			}
			reader = null;
		}
	}

	private int toInt(String a) {
		return Integer.parseInt(a);
	}

	public static Map getCacheURLs(InputStream xmlIs) {
		if (!read_flag) {
			instance.readCacheURLs(xmlIs);
			read_flag = true;
		}
		return url_cacheAttr;
	}
}
/*
 * public static Map getCacheURLs() { if (!read_flag) { File f = new File(
 * ResourceReader.getAPP_HOME() + "config/WebController.xml"); if (f.exists()) {
 * CacheConfig.getInstance().readCacheURLs(f); } read_flag = true; } return
 * url_cacheAttr; }
 */

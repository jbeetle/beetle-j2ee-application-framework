/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.cache;

import java.io.IOException;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.jsp.PageContext;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.web.cache.imp.CacheAttr;
import com.beetle.framework.web.cache.imp.CacheConfig;
import com.beetle.framework.web.cache.imp.CacheHttpServletResponseWrapper;
import com.beetle.framework.web.cache.imp.ResponseContent;
import com.opensymphony.oscache.base.Cache;
import com.opensymphony.oscache.base.NeedsRefreshException;
import com.opensymphony.oscache.web.ServletCacheAdministrator;

/**
 * <p>
 * Title: BeetleWeb
 * </p>
 * 
 * <p>
 * Description: ҳ�涯̬�����������Ҫ��web.xml����
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: �׿ǳ����
 * </p>
 * 
 * @author ��ƶ�(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class ControllerCacheFilter extends HttpServlet implements Filter {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// Header
	public static final String HEADER_LAST_MODIFIED = "Last-Modified";

	public static final String HEADER_CONTENT_TYPE = "Content-Type";

	public static final String HEADER_CONTENT_ENCODING = "Content-Encoding";

	public static final String HEADER_EXPIRES = "Expires";

	public static final String HEADER_IF_MODIFIED_SINCE = "If-Modified-Since";

	public static final String HEADER_CACHE_CONTROL = "Cache-control";

	public static final String HEADER_ACCEPT_ENCODING = "Accept-Encoding";

	private static boolean initedFlag = false;

	private static transient SysLogger log = SysLogger.getInstance();

	private ServletCacheAdministrator admin = null;

	private String characterEncoding = "GBK";

	private Map cacheUrls = null;

	private final static String analysePath(String path) {
		int i = path.lastIndexOf('/');
		if (i == -1) {
			return path;
		} else {
			return path.substring(i + 1);
		}
	}

	// Process the request/response pair
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain filterChain) throws ServletException, IOException {
		if (this.cacheUrls.isEmpty()) {
			filterChain.doFilter(request, response);
			return;
		}
		request.setCharacterEncoding(this.characterEncoding);
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String path = analysePath(httpRequest.getServletPath().trim()); // only
																		// name
		if (this.cacheUrls.containsKey(path)) {
			docache(request, response, filterChain, path);
		} else {
			filterChain.doFilter(request, response);
		}
	}

	private int toScope(String scopeString) {
		int cacheScope = PageContext.APPLICATION_SCOPE;
		if (scopeString.equals("session")) {
			cacheScope = PageContext.SESSION_SCOPE;
		} else if (scopeString.equals("application")) {
			cacheScope = PageContext.APPLICATION_SCOPE;
		} else if (scopeString.equals("request")) {
			cacheScope = PageContext.REQUEST_SCOPE;
		} else if (scopeString.equals("page")) {
			cacheScope = PageContext.PAGE_SCOPE;
		}
		return cacheScope;
	}

	private void docache(ServletRequest request, ServletResponse response,
			FilterChain filterChain, String urlpath) throws ServletException,
			IOException {
		if (log.isDebugEnabled()) {
			log.debug("cache url:" + urlpath);
			log.debug(response.getCharacterEncoding());
		}
		CacheAttr attr = (CacheAttr) cacheUrls.get(urlpath);
		int cacheScope = toScope(attr.getScope());
		int time = attr.getTime(); // in sec
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		String key = admin.generateEntryKey(null, httpRequest, cacheScope);
		Cache cache = admin.getCache(httpRequest, cacheScope);
		try {
			ResponseContent respContent = (ResponseContent) cache.getFromCache(
					key, time);
			if (log.isDebugEnabled()) {
				log.debug("<cache>: Using cached entry for " + key);
				log.debug(response.getCharacterEncoding());
			}
			long clientLastModified = httpRequest
					.getDateHeader("If-Modified-Since"); // will return -1 if no
															// header...
			if ((clientLastModified != -1)
					&& (clientLastModified >= respContent.getLastModified())) {
				((HttpServletResponse) response)
						.setStatus(HttpServletResponse.SC_NOT_MODIFIED);
				return;
			}
			respContent.writeTo(response);
		} catch (NeedsRefreshException nre) {
			boolean updateSucceeded = false;
			try {
				if (log.isDebugEnabled()) {
					log
							.debug("<cache>: New cache entry, cache stale or cache scope flushed for "
									+ key);
				}
				CacheHttpServletResponseWrapper cacheResponse = new CacheHttpServletResponseWrapper(
						(HttpServletResponse) response);
				filterChain.doFilter(request, cacheResponse);
				cacheResponse.flushBuffer();
				// Only cache if the response was 200
				if (cacheResponse.getStatus() == HttpServletResponse.SC_OK) {
					// Store as the cache content the result of the response
					cache.putInCache(key, cacheResponse.getContent());
					updateSucceeded = true;
				}
			} finally {
				if (!updateSucceeded) {
					cache.cancelUpdate(key);
				}
			}
		}
	}

	public void init(FilterConfig filterConfig) throws ServletException {
		if (!initedFlag) {
			initedFlag = true;
			this.characterEncoding = System.getProperty("file.encoding");
			admin = ServletCacheAdministrator.getInstance(filterConfig
					.getServletContext());
			cacheUrls = CacheConfig.getCacheURLs(filterConfig
					.getServletContext().getResourceAsStream(
							"/config/WebController.xml"));
		}
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.web.tools.CommonUtil;
import com.beetle.framework.web.tools.WebUtil;
import com.beetle.framework.web.view.View;
import com.beetle.framework.web.view.ViewFactory;

/**
 * <p>
 * Title: FrameWork
 * </p>
 * <p>
 * Description: MVC框架的主控制器，在需要web.xml文件中配置
 * 
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */

final public class MainControllerServlet extends HttpServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private transient ServletContext context = null;

	private static SysLogger logger = SysLogger
			.getInstance(MainControllerServlet.class);

	public ServletContext getServletContext() {
		if (context == null) {
			return super.getServletContext();
		}
		return context;
	}

	public void setContext(ServletContext context) {
		this.context = context;
	}

	private void doService(HttpServletRequest request,
			HttpServletResponse response)
			throws javax.servlet.ServletException, java.io.IOException {
		if (logger.isDebugEnabled()) {
			logger.debug("-------->MainController Execute Report<--------");
			logger.debug("-->servletPath:" + request.getServletPath());
		}
		request.setAttribute(CommonUtil.app_Context, this.getServletContext());
		View view = null;
		try {
			ControllerImp imp = ControllerFactory.findController(this
					.getServletContext(), request);
			view = imp.dealRequest(request, response);
			if (view != null) {
				if (view.getViewname().equals(
						AbnormalViewControlerImp.abnormalViewName)) { // 流视图					OutputStream out = response.getOutputStream();
					out.flush();
					out.close();
					view.clear();
				} else { // 正常视图
					dealModelAndForward(view, request, response, this
							.getServletContext());
				}
			} else {
				throw new ServletException(
						"errCode[-1003]:View can not be null [please make sure your controller class,the 'View perform(WebInput webInput)' method can't  raise the return null View Object case !]");
			}
		} catch (Exception se) {
			WebUtil.ExceptionInfo ei = WebUtil.analyseException(se);
			request.setAttribute(CommonUtil.WEB_EXCEPTION_INFO, ei);
			if (ViewFactory.isDefinedErrView()) {// 存在错误视图，交给错误视图处理				if (view != null) {
					view.clear();
				}
				String url = ViewFactory.getViewUrlByName(this
						.getServletContext(), "Beetle_ErrorView_19760224");
				RequestDispatcher rd = request.getRequestDispatcher(url);
				rd.forward(request, response);
			} else {// 没有定义错误视图的话，交给容器处理
				if (se instanceof ServletException) {
					throw (ServletException) se;
				} else {
					throw new ServletException(se);
				}
			}
		}
		if (logger.isDebugEnabled()) {
			logger.debug("-------->End<----------");
		}
	}

	private final static String const_ftl = "ftl";

	private void dealModelAndForward(View view, HttpServletRequest request,
			HttpServletResponse response, ServletContext app)
			throws IOException, ServletException {
		String viewName = view.getViewname();
		String url = ViewFactory.getViewUrlByName(this.getServletContext(),
				viewName);
		if (logger.isDebugEnabled()) {
			logger.debug("-->controllerName:"
					+ request.getAttribute(CommonUtil.controllname));
			logger.debug("-->viewName:" + viewName);
			logger.debug("-->viewURL:" + url);
		}
		// 建立控制器与视图的映射关系		ControllerFactory.mapCtrlView(request, viewName);
		//
		String ext = CommonUtil.getExt(url);
		if (ext.equalsIgnoreCase(const_ftl)) { // freeMarker
			ViewFactory.dealWithFreeMarkerFtl(app, request, response, url,
					viewName, view.getData());
		} else { // html/jsp
			ViewFactory.transferDataForView(view.getData(), request);
			RequestDispatcher rd = request.getRequestDispatcher(url);
			if (rd == null) {
				throw new ServletException("errCode[-1004]can't senddirect:"
						+ url);
			}
			view.clear();
			view = null;
			rd.forward(request, response);
		}
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doService(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}
}

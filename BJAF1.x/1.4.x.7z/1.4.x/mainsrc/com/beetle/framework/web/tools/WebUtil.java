/*
 * BJAF - Beetle J2EE Application Framework
 * �׿ǳ�J2EE��ҵӦ�ÿ������
 * ��Ȩ����2003-2009 ��ƶ� (www.beetlesoft.net)
 * 
 * ����һ����ѿ�Դ�������������ڡ��׿ǳ�J2EEӦ�ÿ�������ȨЭ�顷
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   ��GNU Lesser General Public License v3.0��
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>�ºϷ�ʹ�á��޸Ļ����·�����
 *
 * ��л��ʹ�á��ƹ㱾��ܣ����н�������⣬��ӭ�����jϵ��
 * �ʼ��� <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.tools;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.beetle.framework.web.controller.ControllerException;

/**
 * <p>
 * Title: BeetleWeb
 * </p>
 * 
 * <p>
 * Description: Web������
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: �׿ǳ����
 * </p>
 * 
 * @author ��ƶ�(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class WebUtil {
	public static String getDecodeValueByKeyName(HttpServletRequest request,
			String keyName) {
		String qs = decodeURL(request.getQueryString(), (String) request
				.getAttribute("WEB_ENCODE_CHARSET"));
		StringTokenizer st = new StringTokenizer(qs, "&");
		HashMap m = new HashMap();
		while (st.hasMoreTokens()) {
			String b = st.nextToken();
			int i = b.indexOf("=");
			String key = b.substring(0, i);
			String value = b.substring(i + 1);
			m.put(key, value);
		}
		String v = (String) m.get(keyName);
		m.clear();
		return v;
	}

	/**
	 * ����html�淶������url
	 * 
	 * @param url
	 *            url
	 * @param charset
	 *            ���������õ��ַ����
	 * @return String
	 */
	public static String decodeURL(String url, String charset) {
		try {
			return URLDecoder.decode(url, charset);
		} catch (UnsupportedEncodingException u) {
			u.printStackTrace();
			return url;
		}
	}

	/**
	 * ����html�淶������url
	 * 
	 * @param url
	 *            url
	 * @param charset
	 *            �����ַ����
	 * @return String
	 */
	public static String encodeURL(String url, String charset) {
		try {
			return URLEncoder.encode(url, charset);
		} catch (UnsupportedEncodingException u) {
			u.printStackTrace();
			return url;
		}
	}

	/**
	 * ��ȡҳ���������Զ����ȴ�request��Attribute����ȡ��û�д�ҳ��������
	 * 
	 * @param paramterName
	 *            String
	 * @param request
	 *            HttpServletRequest
	 * @return Object
	 */
	public static Object getParameter(String paramterName,
			HttpServletRequest request) {
		Object o = request.getAttribute(paramterName);
		if (o == null) {
			o = request.getParameter(paramterName);
		}
		return o;
	}

	/**
	 * ��session��ȡ��Ӧ��ֵ
	 * 
	 * @param sessionName
	 *            String
	 * @param request
	 *            HttpServletRequest
	 * @return Object
	 */
	public static Object getValueFromSession(String sessionName,
			HttpServletRequest request) {
		HttpSession session = request.getSession(false);
		if (session != null) {
			return session.getAttribute(sessionName);
		} else {
			return null;
		}
	}

	private static String ReplaceChar(String aSour, char aFind, String aRep) {
		int aLength = aSour.length();
		if (aLength == 0) {
			return aSour;
		}
		StringBuffer aStrBuf = new StringBuffer();
		for (int i = 0; i < aLength; i++) {
			char aChar = aSour.charAt(i);
			if (aChar == aFind) {
				aStrBuf.append(aRep);
			} else {
				aStrBuf.append(aChar);
			}
		}
		return aStrBuf.toString();
	}

	/**
	 * �����ַ������еı�ǩ'<';'>'��ţ�ת����html��Ӧ�ı�ǩ
	 * 
	 * @param pStr
	 *            String
	 * @return String
	 */
	public static String dealTags(String pStr) {
		String aStr = ReplaceChar(pStr, '<', "&lt;");
		aStr = ReplaceChar(aStr, '>', "&gt;");
		return aStr;
	}

	/**
	 * �����ַ������еĻس���ת����html��Ӧ��<br>
	 * 
	 * @param pStr
	 *            String
	 * @return String
	 */
	public static String returnToBR(String pStr) {
		String aStr = ReplaceChar(pStr, '\n', "<br>");
		return aStr;
	}

	/**
	 * �����ַ������еĿո�ת����html��Ӧ�Ŀո�
	 * 
	 * @param pStr
	 *            String
	 * @return String
	 */
	public static String dealSpace(String pStr) {
		String aStr = ReplaceChar(pStr, ' ', "&nbsp;");
		return aStr;
	}

	/**
	 * �����ַ������е�html���淶���ַ�ת���ɷ��html��ʾ�ĸ�ʽ
	 * 
	 * @param pStr
	 *            String
	 * @return String
	 */
	public static String doPre(String pStr) {
		String aStr = returnToBR(dealSpace(dealTags(pStr)));
		return aStr;
	}

	public static String decodeURL(String string) {
		return decodeURL(string, System.getProperty("file.encoding"));
		// return URLDecoder.decode(string);
	}

	public static String encodeURL(String string) {
		// return encodeUrl(string, "ISO-8859-1");
		// return URLEncoder.encode(string);
		return encodeURL(string, System.getProperty("file.encoding"));
	}

	public static class ExceptionInfo {
		public int errCode;

		public String errMessage;

		public String stackTraceInfo;
	}

	public static ExceptionInfo analyseException(Exception e) {
		ExceptionInfo ei = new ExceptionInfo();
		ei.errCode = 0;
		if (e instanceof ControllerException) {
			ei.errCode = ((ControllerException) e).getErrCode();
			ei.errMessage = e.getMessage();
		}
		if (ei.errCode == 0) {
			// errCode[-1001]:Don't submit the same request repeating��
			String str = e.getMessage();
			ei.errMessage = str;
			if (str != null) {
				if (str.startsWith("errCode[")) {
					int i = str.indexOf("[");
					int j = str.indexOf("]");
					ei.errCode = Integer.parseInt(str.substring(i + 1, j));
					int k = str.indexOf(":");
					ei.errMessage = str.substring(k + 1);
				}
			}
		}
		java.io.CharArrayWriter cw = new java.io.CharArrayWriter();
		java.io.PrintWriter pw = new java.io.PrintWriter(cw, true);
		e.printStackTrace(pw);
		ei.stackTraceInfo = cw.toString();
		cw.close();
		pw.close();
		cw = null;
		pw = null;
		return ei;
	}

}

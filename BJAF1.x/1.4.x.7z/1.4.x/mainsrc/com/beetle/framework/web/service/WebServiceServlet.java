/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.lang.reflect.Constructor;
import java.util.Map;

import javax.servlet.GenericServlet;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.service.imp.ServiceAttr;
import com.beetle.framework.web.service.imp.ServiceConfig;
import com.caucho.hessian.io.HessianInput;
import com.caucho.hessian.io.HessianOutput;
import com.caucho.hessian.server.HessianSkeleton;
import com.caucho.services.server.GenericService;
import com.caucho.services.server.Service;
import com.caucho.services.server.ServiceContext;

/**
 * <p>
 * Title: BeetleWeb
 * </p>
 * 
 * <p>
 * Description: 支持Web Service的控制器，需要在web.xml配置
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2005
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东(hdyu@beetlesoft.net)
 * @version 1.0
 */
public class WebServiceServlet extends GenericServlet {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private transient ServletContext context = null;

	private static transient  SysLogger logger = SysLogger.getInstance();

	private Map servicesMap = null;

	private static ICache homeImpObjCache = new StrongCache();

	private static final String analysePath(String path) {
		int i = path.lastIndexOf('/');
		if (i == -1) {
			return path;
		} else {
			return path.substring(i + 1);
		}
	}

	/**
	 * Initialize the service, including the service object.
	 */
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		servicesMap = ServiceConfig.getServices(config.getServletContext()
				.getResourceAsStream("/config/WebController.xml"));
	}

	private Class findRemoteAPI(Class implClass) {
		if (implClass == null || implClass.equals(GenericService.class)) {
			return null;
		}

		Class[] interfaces = implClass.getInterfaces();

		if (interfaces.length == 1) {
			return interfaces[0];
		}

		return findRemoteAPI(implClass.getSuperclass());
	}

	private Class loadClass(String className) throws ClassNotFoundException {
		ClassLoader loader = Thread.currentThread().getContextClassLoader();

		if (loader != null) {
			return Class.forName(className, false, loader);
		} else {
			return Class.forName(className);
		}
	}

	private void init(Object service) throws ServletException {
		if (service instanceof Service) {
			((Service) service).init(getServletConfig());
		} else if (service instanceof Servlet) {
			((Servlet) service).init(getServletConfig());
		}
	}

	/**
	 * Execute a request. The path-info of the request selects the bean. Once
	 * the bean's selected, it will be applied.
	 */
	public void service(ServletRequest request, ServletResponse response)
			throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		if (!req.getMethod().equalsIgnoreCase("POST")) {
			// res.setStatus(500, "Requires POST");
			PrintWriter out = res.getWriter();
			res.setContentType("text/html");
			out.println("<h1>WebService Requires POST</h1>");
			return;
		}
		String path = analysePath(req.getServletPath().trim()); // only name
		if (!this.servicesMap.containsKey(path)) {
			logger.error("can't find service:" + path);
			return;
		}
		ServiceAttr attr = (ServiceAttr) this.servicesMap.get(path);
		if (logger.isDebugEnabled()) {
			logger.debug("getServletPath:" + req.getServletPath());
			logger.debug("path:" + path);
			logger.debug(attr.getInterFace());
			logger.debug(attr.getImpClass());
		}
		Object _homeImpl = gen_homeImpl(attr);
		Class _homeAPI = gen_homeAPI(attr, _homeImpl);
		HessianSkeleton _homeSkeleton = null;
		try {
			_homeSkeleton = gen_HessianSkeleton(_homeImpl, _homeAPI);
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error(ex);
			throw new ServletException(ex);
		}
		String serviceId = req.getPathInfo();
		if (logger.isDebugEnabled()) {
			logger.debug("--->");
			logger.debug(_homeImpl);
			logger.debug(_homeAPI);
			logger.debug(serviceId);
		}
		ServiceContext.begin(req, serviceId, null);
		try {
			InputStream is = request.getInputStream();
			OutputStream os = response.getOutputStream();
			HessianInput in = new HessianInput(is);
			HessianOutput out = new HessianOutput(os);
			_homeSkeleton.invoke(in, out);
			if (logger.isDebugEnabled()) {
				logger.debug("rpc invoke ok!");
			}
		} catch (RuntimeException e) {
			throw e;
		} catch (ServletException e) {
			throw e;
		} catch (Throwable e) {
			throw new ServletException(e);
		} finally {
			ServiceContext.end();
		}
	}

	private Class gen_homeAPI(ServiceAttr attr, Object _homeImpl)
			throws ServletException {
		Class _homeAPI;
		try {
			_homeAPI = loadClass(attr.getInterFace());
			if (_homeAPI == null) {
				_homeAPI = findRemoteAPI(_homeImpl.getClass());
			}
			return _homeAPI;
		} catch (ClassNotFoundException ex) {
			throw new ServletException(ex);
		}
	}

	private HessianSkeleton gen_HessianSkeleton(Object service, Class apiClass)
			throws Exception {
		HessianSkeleton hs = null;
		try {
			// Try Hessian 3.x (with service interface argument).
			Constructor ctor = HessianSkeleton.class
					.getConstructor(new Class[] { Object.class, Class.class });
			hs = (HessianSkeleton) ctor.newInstance(new Object[] { service,
					apiClass });
		} catch (NoSuchMethodException ex) {
			// Fall back to Hessian 2.x (without service interface argument).
			Constructor ctor = HessianSkeleton.class
					.getConstructor(new Class[] { Object.class });
			hs = (HessianSkeleton) ctor.newInstance(new Object[] { service });
		}
		return hs;
	}

	private Object gen_homeImpl(ServiceAttr attr) throws ServletException {
		Object _homeImpl;
		try {
			Class homeClass = loadClass(attr.getImpClass());
			try {
				_homeImpl = homeImpObjCache.get(attr.getName());
				if (_homeImpl == null) {
					_homeImpl = homeClass.newInstance();
					if (ReflectUtil.isThreadSafe(_homeImpl.getClass())) {
						homeImpObjCache.put(attr.getName(), _homeImpl);
					}
				}
				init(_homeImpl);
				return _homeImpl;
			} catch (IllegalAccessException ex1) {
				throw new ServletException(ex1);
			} catch (InstantiationException ex1) {
				throw new ServletException(ex1);
			}
		} catch (ClassNotFoundException ex) {
			throw new ServletException(ex);
		}
	}

	/**
	 * getServletContext
	 * 
	 * @return ServletContext
	 * @todo Implement this javax.servlet.ServletConfig method
	 */
	public ServletContext getServletContext() {
		if (context == null) {
			return super.getServletContext();
		}
		return context;
	}

	public void setContext(ServletContext context) {
		this.context = context;
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller.ajax;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.util.XMLProperties;
import com.beetle.framework.web.controller.ControllerFactory;
import com.beetle.framework.web.tools.CommonUtil;

public class AjaxConfig {
	private static Map ajaxTable = new HashMap();

	private static boolean initFlag = false;

	private static String GlobalBackCallClassName = null;

	private static String GlobalPreCallClassName = null;

	private static ICommonAjax preCall = null;

	private static ICommonAjax backCall = null;

	static final String AJAX_FRAMEWORK_NAME = "BEETLE_AJAX_FRAMEWORK";

	private static synchronized void loadTable(ServletContext app) {
		initFlag = true;
		//
		CommonUtil.fill_DataMap(app, "/config/WebController.xml",
				"mappings.controllers.ajax", "aItem", "name", "class",
				ajaxTable);
		Map mItem = ControllerFactory.getModuleItem(app);
		// 加载其它文件的数据		if (!mItem.isEmpty()) {
			Set s = mItem.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
				Map.Entry e = (Map.Entry) it.next();
				String fn = (String) e.getKey();
				String active = (String) e.getValue();
				if (active.equalsIgnoreCase("true")) {
					CommonUtil.fill_DataMap(app, fn,
							"mappings.controllers.ajax", "aItem", "name",
							"class", ajaxTable);
				}
			}
		}
	}

	public final static boolean isAjaxController(String url) {
		return url.startsWith(AJAX_FRAMEWORK_NAME);
	}

	public static Map getAjaxConfig(ServletContext app) {
		if (!initFlag) {
			loadTable(app);
			GlobalBackCallClassName = getGlobalBackCallStr(app);
			GlobalPreCallClassName = getGlobalPreCallStr(app);
		}
		return ajaxTable;
	}

	private static String getGlobalBackCallStr(ServletContext application) {
		InputStream in2 = null;
		in2 = application.getResourceAsStream("/config/WebController.xml");
		String a = XMLProperties.getTagContent(in2,
				"mappings.controllers.cutting.ajaxBackAction");
		return a;
	}

	private static String getGlobalPreCallStr(ServletContext application) {
		InputStream in2 = null;
		in2 = application.getResourceAsStream("/config/WebController.xml");
		String precallName = XMLProperties.getTagContent(in2,
				"mappings.controllers.cutting.ajaxFrontAction");
		return precallName;
	}

	public static ICommonAjax getPreCall() {
		if (preCall == null) {
			if (GlobalPreCallClassName == null
					|| GlobalPreCallClassName.equals("")) {
				return null;
			}
			try {
				preCall = (ICommonAjax) Class.forName(GlobalPreCallClassName)
						.newInstance();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new AppRuntimeException(ex.getMessage());
			}
		}
		return preCall;
	}

	public static ICommonAjax getBackCall() {
		if (backCall == null) {
			if (GlobalBackCallClassName == null
					|| GlobalBackCallClassName.equals("")) {
				return null;
			}
			try {
				backCall = (ICommonAjax) Class.forName(GlobalBackCallClassName)
						.newInstance();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new AppRuntimeException(ex.getMessage());
			}
		}
		return backCall;
	}

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller;

import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.XMLProperties;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.controller.ajax.AjaxConfig;
import com.beetle.framework.web.controller.ajax.ICommonAjax;
import com.beetle.framework.web.controller.document.DocFactory;
import com.beetle.framework.web.controller.document.IDocument;
import com.beetle.framework.web.controller.draw.DrawFactory;
import com.beetle.framework.web.controller.draw.IDraw;
import com.beetle.framework.web.controller.upload.IUpload;
import com.beetle.framework.web.controller.upload.UploadFactory;
import com.beetle.framework.web.tools.CommonUtil;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description:
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */
public class ControllerFactory {
	private static ICache cacheCtrl = new StrongCache(134);
	private static Map zeroConfig = new HashMap();
	private static ICutFrontAction preCall = null;

	private static ICutBackAction backCall = null;

	private static String globalPreCallStr = null;

	private static String globalBackCallStr = null;

	private static SysLogger logger = SysLogger
			.getInstance(ControllerFactory.class);

	/**
	 * 返回系统所有控制（包括标准、虚拟、ajax等） 每次都是动态生产一个map
	 * 
	 * @return
	 */
	public static Map getAllControllers() {
		Map m = new HashMap();
		m.putAll(standardTable);
		m.putAll(virtualTable);
		m.putAll(AjaxConfig.getAjaxConfig(null));
		m.putAll(UploadFactory.getUploadConfig(null));
		m.putAll(DrawFactory.getDrawConfig(null));
		m.putAll(DocFactory.getDocConfig(null));
		m.putAll(zeroConfig);
		return m;
	}

	static ICutBackAction getControllerGlobalBackCall() throws ServletException {
		if (backCall == null) {
			if (globalBackCallStr == null || globalBackCallStr.equals("")) {
				return null;
			}
			try {
				backCall = (ICutBackAction) Class.forName(globalBackCallStr)
						.newInstance();
			} catch (Exception ex) {
				ex.printStackTrace();
				throw new ServletException(ex.getMessage());
			}
		}
		return backCall;
	}

	static ICutFrontAction getControllerGlobalPreCall() throws ServletException {
		if (preCall == null) {
			if (globalPreCallStr == null || globalPreCallStr.equals("")) {
				return null;
			}
			try {
				preCall = (ICutFrontAction) Class.forName(globalPreCallStr)
						.newInstance();
			} catch (Exception ex) {
				logger.error(ex);
				throw new ServletException(ex.getMessage());
			}
		}
		return preCall;
	}

	private static String getGlobalBackCallStr(ServletContext application) {
		InputStream in2 = null;
		in2 = application.getResourceAsStream("/config/WebController.xml");
		String a = XMLProperties.getTagContent(in2,
				"mappings.controllers.cutting.ctrlBackAction");
		return a;
	}

	private static String getGlobalPreCallStr(ServletContext application) {
		InputStream in2 = null;
		in2 = application.getResourceAsStream("/config/WebController.xml");
		String precallName = XMLProperties.getTagContent(in2,
				"mappings.controllers.cutting.ctrlFrontAction");
		return precallName;
	}

	/**
	 * 根据request的servletpath获取其对应的实现类的实例
	 * 
	 * @param application
	 * @param request
	 * @return
	 * @throws ServletException
	 */
	static ControllerImp findController(ServletContext application,
			HttpServletRequest request) throws ServletException {
		// only name
		String path = CommonUtil.analysePath(request.getServletPath());
		request.setAttribute(CommonUtil.controllname, path); // 保存已分析的控制器名称
		String key = CommonUtil.formatPath(request.getServletPath());// 零配置路径
		// 配置和零配置混合
		String prefix = (String) request
				.getAttribute(CommonUtil.WEB_CTRL_PREFIX);
		if (prefix == null) {
			prefix = "";
		}
		String javaPath = (prefix + key).replace(CommonUtil.RIGHT_SLASHDOT,
				CommonUtil.DOT);
		request.setAttribute(CommonUtil.controllerimpclassname, javaPath);
		if (logger.isDebugEnabled()) {
			logger.debug("controllname:" + path);
			logger.debug("controllerimpclassname:" + javaPath);
		}
		if (cacheCtrl.containsKey(path)) {// 配置型控制			Object handler = cacheCtrl.get(path);
			return (ControllerImp) handler;
		} else {
			if (cacheCtrl.containsKey(key)) {// 零配置				// request.setAttribute(CommonUtil.controllname, key);
				return (ControllerImp) cacheCtrl.get(key);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("loading new Controller class....");
			}
			try {
				Class ct = Class.forName(javaPath);
				try {
					ControllerImp ctrlImp = null;
					Object ctrlObj = ct.newInstance();
					if (ctrlObj instanceof IUpload) {
						ctrlImp = new UploadController();
					} else if (ctrlObj instanceof IDraw) {
						ctrlImp = new DrawController();
					} else if (ctrlObj instanceof IDocument) {
						ctrlImp = new DocumentController();
					} else if (ctrlObj instanceof ICommonAjax) {
						ctrlImp = new AjaxController();
					} else {
						ctrlImp = (ControllerImp) ctrlObj;
					}
					if (ctrlImp.isInstanceCacheFlag()) {
						cacheCtrl.put(key, ctrlImp);
						zeroConfig.put(key, javaPath);// 记录相关零配置控制器
						if (logger.isDebugEnabled()) {
							logger.debug("cache controller:" + key);
						}
					}
					// request.setAttribute(CommonUtil.controllname, key);
					return ctrlImp;
				} catch (Exception e) {
					logger.error("实例化" + javaPath + "失败", e);
					throw new ServletException(e);
				}
			} catch (ClassNotFoundException nofe) {// 从配置文件中寻找并新建				// request.setAttribute(CommonUtil.controllname, path);
				if (logger.isDebugEnabled()) {
					logger.debug(javaPath + ",not found!");
				}
				// virtual
				if (isVirtualController(application, path)) {
					return new VirtualController(getVirtualView(path), request);
				}
				// ajax
				if (AjaxConfig.isAjaxController(path)) {
					AjaxController ajaxController = new AjaxController();
					cacheCtrl.put(path, ajaxController);
					return ajaxController;
				}
				// upload case,check if upload controller
				if (UploadFactory.isUploadController(path, application)) {
					ControllerImp upc = new UploadController();
					cacheCtrl.put(path, upc);
					return upc;
				}
				// draw
				if (DrawFactory.isDrawController(path, application)) {
					ControllerImp drawcontroller = new DrawController();
					cacheCtrl.put(path, drawcontroller);
					return drawcontroller;
				}
				// document
				if (DocFactory.isDocController(path, application)) {
					ControllerImp cdc = new DocumentController();
					cacheCtrl.put(path, cdc);
					return cdc;
				}
				//
				String className = getControllerClassByUrlPath(application,
						path);
				if (className == null) {
					throw new ServletException(
							"errCode[-1002]:controller not found!["
									+ path
									+ "]please check your controller config file");
				}
				try {
					Object handler = Class.forName(className.trim())
							.newInstance();
					ControllerImp imp = (ControllerImp) handler;
					if (imp.isInstanceCacheFlag()) { // 判别此控制器对象是否需要缓存						cacheCtrl.put(path, handler);
						if (logger.isDebugEnabled()) {
							logger.debug("cache controller:" + path);
						}
					}
					return imp;
				} catch (Exception ex) {
					logger.error(ex);
					throw new ServletException(ex);
				}
			}
		}
	}

	/**
	 * 获取标准控制器的配置数据
	 * 
	 * @param app
	 *            ServletContext
	 * @return Map
	 */
	public static Map getStandartControllerConfigs(ServletContext app) {
		if (!initFlag) {
			loadConfigInfo(app);
			initFlag = true;
		}
		return standardTable;
	}

	/**
	 * 获取模块项目
	 * 
	 * @param app
	 *            ServletContext
	 * @return Map
	 */
	public static Map getModuleItem(ServletContext app) {
		if (!initFlag) {
			loadConfigInfo(app);
			initFlag = true;
		}
		return moduleItemMap;
	}

	private static Map moduleItemMap = new HashMap(); // 存储模块项
	private static Map standardTable = new HashMap();

	private static Map virtualTable = new HashMap();

	private static boolean initFlag = false;

	private static synchronized void loadConfigInfo(ServletContext app) {
		if (logger.isDebugEnabled()) {
			logger.debug("loading WebController.xml datas into cache...");
		}
		String filename = "/config/WebController.xml";
		// virtual
		CommonUtil.fill_DataMap(app, filename, "mappings.controllers.virtual",
				"vItem", "name", "view", virtualTable);
		// standard
		CommonUtil.fill_DataMap(app, filename, "mappings.controllers.standard",
				"sItem", "name", "class", standardTable);
		// ...获取全局回叫实现类
		globalPreCallStr = getGlobalPreCallStr(app);
		globalBackCallStr = getGlobalBackCallStr(app);
		// 获取module数据..
		CommonUtil.fill_DataMap(app, filename, "mappings.module", "mItem",
				"filename", "active", moduleItemMap);
		// 加载其它文件的数据
		if (!moduleItemMap.isEmpty()) {
			Set s = moduleItemMap.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
				Map.Entry e = (Map.Entry) it.next();
				String fn = (String) e.getKey();
				String active = (String) e.getValue();
				if (active.equalsIgnoreCase("true")) {
					// virtual
					CommonUtil.fill_DataMap(app, fn,
							"mappings.controllers.virtual", "vItem", "name",
							"view", virtualTable);
					// standard
					CommonUtil.fill_DataMap(app, fn,
							"mappings.controllers.standard", "sItem", "name",
							"class", standardTable);
				}
			}
		}
		initDefaultCtrl();
		initFlag = true;
	}

	/**
	 * 初始化默认管理的控制器
	 */
	private static void initDefaultCtrl() {
		zeroConfig.put("framework.web.manage.ManageController",
				"com.beetle.framework.web.manage.ManageController");// 注册管理控制器
		try {
			cacheCtrl.put("framework.web.manage.ManageController",
					Class.forName(
							"com.beetle.framework.web.manage.ManageController")
							.newInstance());
		} catch (Exception e) {
			logger.error(e);
		}
	}

	static boolean isVirtualController(ServletContext app, String urlPath) {
		if (!initFlag) {
			loadConfigInfo(app);
			initFlag = true;
		}
		// return virtualTable.containsKey(urlPath);
		boolean f = virtualTable.containsKey(urlPath);
		if (!f) {// 检查看是否为零配置虚拟写法eg:$|xpath|ypath|zcontroller.ctrl
			if (urlPath.indexOf('|') >= 0) {// 合法为零配置url
				virtualTable.put(urlPath, urlPath);
				f = true;
			}
		}
		return f;
	}

	static String getVirtualView(String urlPath) {
		return virtualTable.get(urlPath).toString();
	}

	private static String getControllerClassByUrlPath(ServletContext app,
			String url) {
		if (!initFlag) {
			loadConfigInfo(app);
			initFlag = true;
		}
		String r = (String) standardTable.get(url);
		return r;
	}

	private static Map controllerViewConfig = new HashMap();// 控制器与视图关系映射

	/**
	 * 记录控制器与视图的使用关系
	 * 
	 * 
	 * @param request
	 * @param viewName
	 */
	static void mapCtrlView(HttpServletRequest request, String viewName) {
		String flag = (String) request
				.getAttribute(CommonUtil.CTRL_VIEW_MAP_ENABLED);
		if (flag != null && flag.equalsIgnoreCase(CommonUtil.TRUE_STR)) {
			String ctrlname = (String) request
					.getAttribute(CommonUtil.controllname);
			if (!controllerViewConfig.containsKey(ctrlname)) {
				createTipSet(ctrlname);
			}
			HashSet hs = (HashSet) controllerViewConfig.get(ctrlname);
			if (viewName != null) {
				hs.add(viewName);
			}
		}
	}

	public static Map getCtrlViewMap() {
		return controllerViewConfig;
	}

	private synchronized static void createTipSet(String ctrlname) {
		if (!controllerViewConfig.containsKey(ctrlname)) {
			controllerViewConfig.put(ctrlname, new HashSet());
		}
	}
}

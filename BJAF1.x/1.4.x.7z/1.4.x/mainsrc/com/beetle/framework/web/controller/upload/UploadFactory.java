/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller.upload;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import com.beetle.framework.util.ReflectUtil;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.StrongCache;
import com.beetle.framework.web.controller.ControllerFactory;
import com.beetle.framework.web.tools.CommonUtil;

public class UploadFactory {
	private static Map uploadTable = new HashMap();
	private static ICache cacheUpload = new StrongCache();
	private static boolean initFlag = false;

	public static Map getUploadConfig(ServletContext app) {
		if (!initFlag) {
			loadUploadTable(app);
			initFlag = true;
		}
		return uploadTable;
	}

	private static synchronized void loadUploadTable(ServletContext app) {
		initFlag = true;
		//
		CommonUtil.fill_DataMap(app, "/config/WebController.xml",
				"mappings.controllers.upload", "uItem", "name", "class",
				uploadTable);
		Map mItem = ControllerFactory.getModuleItem(app);
		// 加载其它文件的数据
		if (!mItem.isEmpty()) {
			Set s = mItem.entrySet();
			Iterator it = s.iterator();
			while (it.hasNext()) {
				Map.Entry e = (Map.Entry) it.next();
				String fn = (String) e.getKey();
				String active = (String) e.getValue();
				if (active.equalsIgnoreCase("true")) {
					CommonUtil.fill_DataMap(app, fn,
							"mappings.controllers.upload", "uItem", "name",
							"class", uploadTable);
				}
			}
		}
	}

	public static boolean isUploadController(String url, ServletContext app) {
		if (!initFlag) {
			loadUploadTable(app);
			initFlag = true;
		}
		return uploadTable.containsKey(url);
	}

	public static IUpload getUploadInstance(String url, String zoreImpClass)
			throws ServletException {
		Object upload = cacheUpload.get(url);
		if (upload == null) {
			String className = (String) uploadTable.get(url);
			if (className == null) {
				className = zoreImpClass;
				uploadTable.put(url, className);
			}
			try {
				upload = Class.forName(className.trim()).newInstance();
				IUpload imp = (IUpload) upload;
				if (ReflectUtil.isThreadSafe(imp.getClass())) { // 判别此控制器对象是否需要缓存					cacheUpload.put(url, upload);
				}
				/*
				 * if (imp.cacheFlag) { cacheUpload.put(url, upload); }
				 */
			} catch (Exception e) {
				upload = null;
				throw new ServletException(e);
			}
		}
		return (IUpload) upload;
	}
}

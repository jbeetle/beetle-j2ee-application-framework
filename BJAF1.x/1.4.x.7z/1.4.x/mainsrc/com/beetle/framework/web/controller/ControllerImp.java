/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.web.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.beetle.framework.web.tools.CommonUtil;
import com.beetle.framework.web.view.View;

/**
 * <p>
 * Title: Beetle J2EE Application FrameWork
 * </p>
 * <p>
 * Description: 子控制器抽象类，每个控制器必须继承这个抽象类，同时需要在WebController.xml文件中注册(零配置除外)
 * 
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东
 * 
 * @version 1.0
 */

public abstract class ControllerImp {
	public ControllerImp() {
	}

	private boolean globalBackCallFlag = true;

	private boolean globalFrontCallFlag = true; // 默认处理PreCall提前回调

	private boolean requireSession = false; // 默认不需要做session检查

	private boolean disableGetMethodFlag = false;// 禁止get方法请求，默认允许

	private int cacheSeconds = -1;

	private boolean instanceCacheFlag = true; // 默认都需要缓存

	private int avoidSubmitSeconds = 0; // 避免控制器多次提交

	private String className = null;

	private final static Map cache = new HashMap();

	public void setAvoidSubmitSeconds(int seconds) {
		this.avoidSubmitSeconds = seconds;
	}

	View dealRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		WebInput webInput = null;
		if (this.disableGetMethodFlag) {
			if (request.getMethod().equalsIgnoreCase("get")) {
				throw new ServletException(
						"errCode[-1013]:the get method for this request had been forbided! ");
			}
		}
		// 设置是否通过header缓存
		if (this.cacheSeconds <= 0) {
			noCache(response);
		} else if (this.cacheSeconds > 0) {
			cacheForSeconds(response, this.cacheSeconds);
		}
		// 防止控制器多次提交
		if (avoidSubmitSeconds > 0) {
			avoidSubmit(request, response);
		}
		// ////////////////==设置front回调==//////////////////
		if (this.globalFrontCallFlag) {
			ICutFrontAction preCall = ControllerFactory
					.getControllerGlobalPreCall();
			if (preCall != null) {
				webInput = new WebInput(request, response);
				View ve = preCall.act(webInput);
				if (ve != null) {
					return ve;
				}
			}
		}
		// 检查session
		if (this.requireSession) {
			HttpSession session = request.getSession(false);
			if (session == null) {
				noCache(response);
				if (webInput.getRequest().getAttribute(
						CommonUtil.CANCEL_SESSION_CHECK_FLAG) == null) {
					return new View(CommonUtil.DISABLED_SESSION_VIEW);
				}
			}
		}
		// 最大并发数检查
		if (cache.containsKey(this.className)) {
			ParallelValue pv = (ParallelValue) cache.get(this.className);
			int max = pv.getMax();
			int cur = pv.getCur();
			if (cur > max) {
				throw new ServletException(
						"errCode[-1009]:exceeding this controller's request parallel amount limit,do it later,please!");
			} else {
				cur = cur + 1;
				pv.setCur(cur);
			}
		}
		// ///////////////////==执行正常控制代码==//////////////////////////////
		if (webInput == null) {
			webInput = new WebInput(request, response);
		}
		View view;
		try {
			view = perform(webInput);
		} catch (ControllerException e) {
			// throw new ServletException("errCode[-1010]:" + e.getMessage(),
			// e);
			throw new ServletException(e);
		} finally {
			// 更新计数器
			if (cache.containsKey(this.className)) {
				ParallelValue pv = (ParallelValue) cache.get(this.className);
				int cur = pv.getCur();
				cur = cur - 1;
				pv.setCur(cur);
			}
		}
		// ////////////////////////==设置back回调==//////////////////////////
		if (this.globalBackCallFlag) {
			ICutBackAction backCall = ControllerFactory
					.getControllerGlobalBackCall();
			if (backCall != null) {
				View ve = backCall.act(webInput);
				if (ve != null) {
					if (view != null) {
						view.clear();
					}
					return ve;
				}
			}
		}
		return view;
	}

	private void avoidSubmit(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			NumberFormatException {
		String ckname = CommonUtil.analysePath(request.getServletPath().trim());
		if (ckname.indexOf('$') == 0) {
			ckname = ckname.substring(1);
		}
		Cookie cookie = CommonUtil.getCookie(ckname, request);
		if (cookie != null) {
			long old = Long.parseLong(cookie.getValue());
			long now = System.currentTimeMillis();
			long cmp = this.avoidSubmitSeconds * 1000;
			if (now - old <= cmp) { // 如果是在设置的时间内提交请求的话，则直接中断请求
				throw new ServletException(
						"errCode[-1001]:Don't submit the same request repeating！");
			} else {
				cookie.setMaxAge(-1); // 删除请求
				cookie = null;
			}
		} else {
			cookie = new Cookie(ckname, String.valueOf(System
					.currentTimeMillis()));
			cookie.setMaxAge(this.avoidSubmitSeconds);
			response.addCookie(cookie);
		}
	}

	final void cacheForSeconds(HttpServletResponse response, int seconds) {
		String hval = "max-age=" + seconds;
		response.setHeader("Cache-Control", hval);
	}

	private void noCache(HttpServletResponse response) {
		response.setHeader("Pragma", "No-cache");
		response.setHeader("Cache-Control", "no-cache");
		response.setDateHeader("Expires", 1L);
	}

	/**
	 * 控制逻辑执行方法，系统框架主控制器（MainControllerServlet）会根据请求的url来找到此控制类， 并执行此方法完成任务
	 * 
	 * @param webInput
	 *            Web页面输入参数对象，对request对象封装，基本上保留request的方法，屏蔽到一些不利于开发的方法
	 * @return 视图对象（视图的名称[WebView.xml]，以及相关的数据）
	 * 
	 * @throws ServletException
	 */
	public abstract View perform(WebInput webInput) throws ControllerException;

	/**
	 * 启动此控制器在执行逻辑之前进行Session检查，框架默认不做检查 (注:必须在构造函数内调用才有效)
	 * 如果session不存在，则主控制器会不不处理此控制器，直接挑转到NoSessionView视图
	 */
	public void enableSessionCheck() {
		this.requireSession = true;
	}

	private static class ParallelValue {
		int max;

		int cur;

		public ParallelValue(int max, int cur) {
			this.max = max;
			this.cur = cur;
		}

		public int getMax() {
			return this.max;
		}

		public int getCur() {
			return this.cur;
		}

		public void setCur(int cur) {
			this.cur = cur;
		}
	}

	/**
	 * 设置此控制器最大支持并发请求数，默认为负数，即无限制。 此方法在对此控制器做并发控制时候，才需要设置，其它情况，框架不会
	 * 
	 * 对控制器进行任何并发数量限制。(注:必须在构造函数内调用才有效)
	 * 
	 * @param amount
	 */
	public void setMaxParallelAmount(int amount) {
		if (amount > 0) {// 只作一次初始化设置
			if (this.className == null) {
				this.className = this.getClass().getName();
			}
			if (!cache.containsKey(className)) {
				cache.put(className, new ParallelValue(amount, 0));
			}
		}
	}

	/**
	 * 利用http协议的header缓存生产的view (注:必须在构造函数内调用才有效)
	 * 
	 * @param cacheSeconds
	 *            单位为秒
	 */
	public void setCacheSeconds(int cacheSeconds) {
		this.cacheSeconds = cacheSeconds;
	}

	boolean isInstanceCacheFlag() {
		return instanceCacheFlag;
	}

	/**
	 * 设置此控制器是否需要缓存在内容中，默认，所有的控制器都被缓存 (注:必须在构造函数内调用才有效)
	 * 
	 * @param instanceCacheFlag
	 *            如果为true表示需要缓存，为false，此控制器实例不被缓存，默认为true，如果你的控制器为线程不安全的，
	 *            则设置为false
	 */
	public void setInstanceCacheFlag(boolean instanceCacheFlag) {
		this.instanceCacheFlag = instanceCacheFlag;
	}

	/**
	 * 禁止此控制器参与全局“前置”回调。 前置回调－－是指在系统执行此控制器之前会先执行此回调。 (注:必须在构造函数内调用才有效)
	 */
	public void disableFrontAction() {
		this.globalFrontCallFlag = false;
	}

	/**
	 * 禁止此控制器参与全局“后置”回调，后置回调－－是指在系统执行此控制器Perform后会执行此回调。 (注:必须在构造函数内调用才有效)
	 */
	public void disableBackAction() {
		this.globalBackCallFlag = false;
	}

	/**
	 * 禁止此控制器处理http协议的get请求(注:必须在构造函数内调用才有效)
	 */
	public void disableGetMethod() {
		this.disableGetMethodFlag = true;
	}
}

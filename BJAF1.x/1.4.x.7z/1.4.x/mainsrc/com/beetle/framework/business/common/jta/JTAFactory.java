/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.common.jta;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.transaction.UserTransaction;

import com.beetle.framework.log.SysLogger;
import com.beetle.framework.persistence.access.ConnectionFactory;
import com.beetle.framework.persistence.access.DBConfig;
import com.beetle.framework.resource.AppContext;
import com.beetle.framework.resource.JTAService;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: JTA工厂
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东
 * @version 1.0
 */
public class JTAFactory {
	private static SysLogger logger = SysLogger.getInstance();

	private static boolean f = true;

	/**
	 * 返回一个系统事务
	 * 
	 * @throws JTAException
	 * @return ITransaction
	 */
	public static ITransaction getTransactionFromContainer()
			throws JTAException {
		UserTransaction ut = null;
		try {
			if (f) {
				ut = (UserTransaction) AppContext.getLocalEJBContainerContext()
						.lookup("java:comp/UserTransaction");
				if (logger.isDebugEnabled()) {
					logger
							.debug("get 'UserTransaction' by jndi[java:comp/UserTransaction]");
				}
			} else {
				ut = (UserTransaction) AppContext.getLocalEJBContainerContext()
						.lookup("javax.transaction.UserTransaction");
				if (logger.isDebugEnabled()) {
					logger
							.debug("get 'UserTransaction' by jndi[javax.transaction.UserTransaction]");
				}
			}
		} catch (NamingException e) {
			if (ut == null) {
				try {
					ut = (UserTransaction) AppContext
							.getLocalEJBContainerContext().lookup(
									"javax.transaction.UserTransaction"); // for
					// weblogic
					if (logger.isDebugEnabled()) {
						logger
								.debug("get 'UserTransaction' by jndi[javax.transaction.UserTransaction]");
					}
					f = false;
				} catch (NamingException ex) {
					logger.error(ex);
					throw new JTAException("获取系统JTA失败", ex);
				}
			}
		}
		JTATransaction jta = new JTATransaction(ut);
		return jta;
	}

	/**
	 * 返回一个系统事务
	 * 
	 * @param context
	 *            Context
	 * @throws JTAException
	 * @return ITransaction
	 */
	public static ITransaction getTransaction(Context context)
			throws JTAException {
		UserTransaction ut;
		try {
			ut = (UserTransaction) context.lookup("java:comp/UserTransaction");
			JTATransaction jta = new JTATransaction(ut);
			return jta;
		} catch (NamingException e) {
			throw new JTAException("获取系统JTA失败", e);
		}
	}

	/**
	 * 返回框架事务对象 如果框架默认数据源的类型为非xa的话，采取jdbc事务，而且此事务的作用范围只在默认数据源本身；
	 * 如果是xa数据源则采取，jotm事务。
	 * 
	 * @return
	 */
	public static ITransaction getTransactionFromFramework() {
		ITransaction it = null;
		int type = DBConfig.getFrameworkDBType(DBConfig.SYSDATASOURCE_DEFAULT);
		if (type != 3) {// 非XA数据源，而且只有一个数据源的时候采取jdbc事务
			it = new JDBCTransaction(ConnectionFactory
					.getConncetion(DBConfig.SYSDATASOURCE_DEFAULT));
			if (logger.isDebugEnabled()) {
				logger.debug("get 'ITransaction' by JDBCTransaction");
			}
		} else {
			UserTransaction ut = JTAService.getInstance().getUserTransaction();
			it = new JTATransaction(ut);
			if (logger.isDebugEnabled()) {
				logger.debug("get 'ITransaction' by JTATransaction");
			}
		}
		return it;
	}

}

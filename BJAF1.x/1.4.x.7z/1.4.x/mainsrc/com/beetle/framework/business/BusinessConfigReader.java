/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.resource.FrameworkContext;
import com.beetle.framework.resource.ResourceReader;
import com.beetle.framework.resource.define.CfgFileInfo;
import com.beetle.framework.util.OtherUtil;
import com.beetle.framework.util.ResourceLoader;
import com.beetle.framework.util.XMLProperties;

/**
 * <p>
 * Title: Beetle业务逻辑框架
 * </p>
 * 
 * <p>
 * Description:配置属性读取类
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2006
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * 
 * </p>
 * 
 * @author 余浩东（yuhaodong@gmail.com）
 * 
 * @version 1.0
 */
public class BusinessConfigReader {
	/**
	 * 根据属性id返回属性值
	 * 
	 * 
	 * @param 属性id
	 * @return 属性值
	 */
	private static Map commandLogicTable = new HashMap();

	private static Map delegateLogicTable = new HashMap();

	private static Map queueLogicTable = new HashMap();

	private static Map jmsDealerTable = new HashMap();// MsgHandler.xml

	// private static String sysconfigFileName = ResourceReader.getAPP_HOME() +
	// "config/Business.xml";

	private final static Map readeConfig(String cffile, String v1, String v2,
			String v3) {
		Map m = null;
		File f = null;
		File f2 = null;
		String filename = ResourceReader.getAPP_HOME() + cffile;
		f = new File(filename);
		if (f.exists()) {
			// 记录文件信息以便日后监控
			markCfgInfo(f, filename);
			//
			m = XMLProperties.getProperties(filename, v1, v2, v3);
			SysLogger.getInstance(BusinessConfigReader.class).info(
					"from file:[" + f.getPath() + "]");
		} else {
			String fn2 = cffile.substring(cffile.indexOf('/') + 1);
			f2 = new File(fn2);
			if (f2.exists()) {// 支持没有config的相对路径
				markCfgInfo(f2, fn2);
				m = XMLProperties.getProperties(fn2, v1, v2, v3);
				SysLogger.getInstance(BusinessConfigReader.class).info(
						"from file:[" + f2.getPath() + "]");
			} else {
				try {
					m = XMLProperties.getProperties(ResourceLoader
							.getResAsStream(filename), v1, v2, v3);
					SysLogger.getInstance(BusinessConfigReader.class).info(
							"from resourceloader:["
									+ ResourceLoader.getClassLoader()
											.toString() + "]");
				} catch (IOException e) {
					try {
						m = XMLProperties.getProperties(ResourceLoader
								.getResAsStream(fn2), v1, v2, v3);
						SysLogger.getInstance(BusinessConfigReader.class).info(
								"from resourceloader:["
										+ ResourceLoader.getClassLoader()
												.toString() + "]");
					} catch (IOException e1) {
						throw new AppRuntimeException(e1);
						// e1.printStackTrace();
						// SysLogger.getInstance(BusinessConfigReader.class).warn(
						// e1.getMessage());
						// m = new HashMap();
					}
				}
			}
		}
		f = null;
		f2 = null;
		return m;
	}

	public static void markCfgInfo(File f, String filename) {
		String smfn = OtherUtil.removePath(filename);
		FrameworkContext ctx = FrameworkContext.getInstance();
		try {
			if (ctx.lookup(smfn) == null) {
				CfgFileInfo cfi = new CfgFileInfo();
				cfi.setFilename(smfn);
				cfi.setLastFileModifiedTime(f.lastModified());
				cfi.setLastReadTime(System.currentTimeMillis());
				cfi.setModifyCount(0);
				cfi.setPath(filename);
				ctx.bind(smfn, cfi);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String getCommandLogicValue(String keyName) {
		if (commandLogicTable.isEmpty()) {
			synchronized (commandLogicTable) {
				// Map m = XMLProperties.getProperties(sysconfigFileName,
				// "Config.BusinessLogic.command",
				// "name", "value");
				Map m = readeConfig("config/ExeMode.xml", "Mode.Command",
						"name", "value");
				commandLogicTable.putAll(m);
				m.clear();
			}
		}
		return (String) commandLogicTable.get(keyName);
	}

	public static String getDelegateLogicValue(String keyName) {
		if (delegateLogicTable.isEmpty()) {
			synchronized (delegateLogicTable) {
				/*
				 * Map m = XMLProperties.getProperties(sysconfigFileName,
				 * "Config.BusinessLogic.delegate", "name", "value");
				 */
				Map m = readeConfig("config/ExeMode.xml", "Mode.Delegate",
						"name", "value");
				delegateLogicTable.putAll(m);
				m.clear();
			}
		}
		return (String) delegateLogicTable.get(keyName);
	}

	/**
	 * 根据标签和Key获取配置ExeMode文件的只
	 * 
	 * @param tagName
	 * @param keyName
	 * @return
	 */
	public static String getExeModeValue(String tagName, String keyName) {
		Map tagMap = (Map) exemodeMap.get(tagName);
		if (tagMap == null) {
			tagMap = initTagMap(tagName);
		}
		if (tagMap.isEmpty()) {
			synchronized (tagMap) {
				Map m = readeConfig("config/ExeMode.xml", "Mode." + tagName,
						"name", "value");
				tagMap.putAll(m);
				m.clear();
			}
		}
		return (String) tagMap.get(keyName);
	}

	private synchronized static Map initTagMap(String tagName) {
		if (!exemodeMap.containsKey(tagName)) {
			exemodeMap.put(tagName, new HashMap());
		}
		return (Map) exemodeMap.get(tagName);
	}

	private static Map exemodeMap = new HashMap();

	public static String getQueueLogicValue(String keyName) {
		if (queueLogicTable.isEmpty()) {
			synchronized (queueLogicTable) {
				/*
				 * Map m = XMLProperties.getProperties(sysconfigFileName,
				 * "Config.BusinessLogic.queue", "name", "value");
				 */
				Map m = readeConfig("config/ExeMode.xml", "Mode.Message",
						"name", "value");
				queueLogicTable.putAll(m);
				m.clear();
			}
		}
		return (String) queueLogicTable.get(keyName);
	}

	public static synchronized void resetMessageConfig() {
		Map m = readeConfig("config/MsgHandler.xml", "Handler", "id",
				"impClass");
		jmsDealerTable.putAll(m);
		m.clear();
	}

	public static String getMessageDealer(String keyName) {
		if (jmsDealerTable.isEmpty()) {
			synchronized (jmsDealerTable) {
				Map m = readeConfig("config/MsgHandler.xml", "Handler", "id",
						"impClass");
				jmsDealerTable.putAll(m);
				// 固有插件注册[统一有配置文件定义]

				jmsDealerTable
						.put("AmesbManageAdapter",
								"com.beetle.framework.business.msgfacade.plugin.mgr.AmesbManageAdapter");
				/*
				 * jmsDealerTable .put("AutoEjbProxyAdapter",
				 * "com.beetle.framework.business.msgfacade.plugin.AutoEjbProxyAdapter"
				 * ); jmsDealerTable .put("AutoEjbSynchroAdapter",
				 * "com.beetle.framework.business.msgfacade.plugin.AutoEjbSynchroAdapter"
				 * ); jmsDealerTable .put("AutoEjbSynchroProxyAdapter",
				 * "com.beetle.framework.business.msgfacade.plugin.AutoEjbSynchroProxyAdapter"
				 * ); jmsDealerTable .put("AutoJdbcSimpleAdapter",
				 * "com.beetle.framework.business.msgfacade.plugin.jdbc.AutoJdbcSimpleAdapter"
				 * );
				 */
				m.clear();
			}
		}
		return (String) jmsDealerTable.get(keyName);
	}

	// to test
	public static void main(String arg[]) {
		System.out.println(getExeModeValue("Message", "JMS_CONN_FACTORY"));
	}
}

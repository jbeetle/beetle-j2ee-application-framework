/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp.proxy;

import java.util.Map;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.appsrv.Locker;
import com.beetle.framework.appsrv.RoutinesPool;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.BsResponse;
import com.beetle.framework.business.delegate.BusinessException;
import com.beetle.framework.business.delegate.DelegateExecuteException;
import com.beetle.framework.business.delegate.DelegateExecutor;
import com.beetle.framework.business.delegate.IBusiness;
import com.beetle.framework.business.service.Input;
import com.beetle.framework.business.service.Output;
import com.beetle.framework.business.service.ServiceAtt;
import com.beetle.framework.business.service.ServiceFactory;
import com.beetle.framework.util.cache.ICache;
import com.beetle.framework.util.cache.WeakCache;

public class RemoteInvokeProxy implements IBusiness {
	private final static String MID = "REQUEST_MSG_MID";

	private final static String EXEFLAG = "REQUEST_EXE_FLAG";// ibusiness事务执行标记;1-非事务；2-事务

	private final static String SERVICEURL = "SERVICE_URL";// 此类服务地址

	private final static String TIMEOUT = "REQUEST_TIME_OUT";// 超时定义，毫秒ms

	private final static String INVOKETYPE = "INVOKE_TYPE";// 100-ibusiness;200-iservice

	private final static String IMPCLASS = "IMP_CLASS";
	private final static String TRANSATTRIBUTE = "TRANS_ATTRIBUTE";
	private final static String EJBTYPE = "EJB_TYPE";
	private final static String ROLLBACK = "ROLL_BACK";
	private static ICache tmpCache = new WeakCache();

	public BsResponse execute(BsRequest rq) throws BusinessException {
		String mid = rq.getParameterAsString(MID);
		BsResponse rs = null;
		int timeout = 0;
		String tot = rq.getParameterAsString(TIMEOUT);
		if (tot == null) {
			timeout = 30000;
		} else {
			timeout = Integer.parseInt(tot);
		}
		String url = rq.getParameterAsString(SERVICEURL);
		rq.registerBusinessURL(url);
		tmpCache.put(mid, rs);
		int ivktype = rq.getParameterAsInteger(INVOKETYPE).intValue();
		Locker locker = null;
		if (ivktype == 100) {
			locker = new Locker();
			RoutinesPool.runRoutineInCommonPool(new EJBInvokeRoutine(rq, mid,
					locker));
		} else if (ivktype == 200) {
			locker = new Locker();
			RoutinesPool.runRoutineInCommonPool(new ServiceInvokeRoutine(rq,
					mid, locker));
		} else {
			// throw new BusinessException("调用失败，[" + ivktype + "]没有此类型调用");
			rs = new BsResponse();
			rs.setReturnFlag(-2000);
			rs.setReturnMsg("调用失败，[" + ivktype + "]没有此类型调用");
			return rs;
		}
		try {
			locker.lockForTime(timeout);
			rs = (BsResponse) tmpCache.get(mid);
		} catch (InterruptedException e) {
			// throw new BusinessException(e);
			if (rs == null) {
				rs = new BsResponse();
				rs.setReturnFlag(-2001);
				rs.setReturnMsg("等待异常" + e.getMessage());
			}
		} finally {
			tmpCache.remove(mid);
			if (rq != null) {
				rq.clear();
				rq = null;
			}
		}
		if (rs == null) {
			// throw new BusinessException("调用失败，返回为空，可能因超时[" + (timeout / 100)
			// + "秒]无返回");
			rs = new BsResponse();
			rs.setReturnFlag(-2002);
			rs.setReturnMsg("服务调用返回为空，可能服务本身没有返回，可能因超时[" + (timeout)
					+ "ms]终止无返回");
		}
		return rs;
	}

	// IService接口服务调用
	private static class ServiceInvokeRoutine extends SubRoutine {
		private BsRequest rq;
		private Locker lock;
		private String mid;

		public ServiceInvokeRoutine(BsRequest rq, String mid, Locker lock) {
			super();// 不需要后台线程监控

			this.rq = rq;
			this.mid = mid;
			this.lock = lock;
		}

		protected void routine() throws InterruptedException {
			String srvId = rq.getBusinessURL();
			Input ip = new Input();
			ip.setServiceId(srvId);
			Map m = ip.peek();
			m.putAll(rq.peek());
			ServiceAtt sa = new ServiceAtt();
			sa.setImpClass(rq.getParameterAsString(IMPCLASS));
			sa.setId(srvId);
			sa.setTransAttribute(rq.getParameterAsString(TRANSATTRIBUTE));
			sa.setType(rq.getParameterAsString(EJBTYPE));
			// sa.setType(ServiceAtt.type_Local);// 代理为本地服务调用

			// sa.setTransAttribute(ServiceAtt.transAttribute_NotSupported);
			ServiceAtt rbAttr = (ServiceAtt) rq.getParameter(ROLLBACK);
			try {
				Output op = ServiceFactory.doService(ip, sa);
				if (op != null) {
					BsResponse rs = (BsResponse) op;
					tmpCache.put(mid, rs);
				}
			} catch (Throwable e) {
				if (rbAttr == null) {
					BsResponse rs = new BsResponse();
					rs.setReturnFlag(-2006);
					rs.setReturnMsg(e.getMessage());
					tmpCache.put(mid, rs);
					throw new InterruptedException(e.getMessage());
				} else {// 存在回滚服务设置，执行它
					if (e instanceof AppRuntimeException) {
						try {
							Output rbop = ServiceFactory.doService(ip, rbAttr);
							if (rbop != null) {
								BsResponse rs = (BsResponse) rbop;
								tmpCache.put(mid, rs);
							}
						} catch (AppRuntimeException e2) {
							BsResponse rs = new BsResponse();
							rs.setReturnFlag(-2007);
							rs.setReturnMsg(e2.getMessage());
							tmpCache.put(mid, rs);
							throw new InterruptedException(e2.getMessage());
						}
					}
				}
			} finally {
				lock.unlock();
				sa = null;
				rbAttr = null;
				if (rq != null) {
					rq.clear();
					rq = null;
				}
				if (ip != null) {
					ip.clear();
					ip = null;
				}
			}
		}

	}

	// IBusiness接口服务调用
	private static class EJBInvokeRoutine extends SubRoutine {
		private BsRequest rq;

		private String mid;
		private Locker lock;

		public EJBInvokeRoutine(BsRequest rq, String mid, Locker lock) {
			// super(20);// 20秒

			super();// 不需要后台线程监控

			this.rq = rq;
			this.mid = mid;
			this.lock = lock;
		}

		protected void routine() throws InterruptedException {
			BsResponse rs = null;
			int exeflag = rq.getParameterAsInteger(EXEFLAG).intValue();
			if (exeflag == 1) {// 非事务执行

				try {
					rs = DelegateExecutor.executeBusiness(rq,
							DelegateExecutor.EJB_LOCAL_EXECUTE);
				} catch (DelegateExecuteException e) {
					throw new InterruptedException(e.getMessage());
				} finally {
					lock.unlock();
				}
			} else if (exeflag == 2) {// 事务执行
				try {
					rs = DelegateExecutor.executeBusinessWithTransaction(rq,
							DelegateExecutor.EJB_LOCAL_EXECUTE);
				} catch (DelegateExecuteException e) {
					throw new InterruptedException(e.getMessage());
				} finally {
					lock.unlock();
				}
			}
			if (rs != null) {
				tmpCache.put(mid, rs);
			}
		}

	}
}

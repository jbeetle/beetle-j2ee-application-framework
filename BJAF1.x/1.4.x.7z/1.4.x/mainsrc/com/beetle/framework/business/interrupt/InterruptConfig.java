/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.interrupt;

/**
 * @author Henry Yu 2005-4-11
 *
 */
import java.io.*;
import java.util.*;
import com.beetle.framework.log.*;
import org.dom4j.*;
import org.dom4j.io.*;
import com.beetle.framework.resource.*;
import com.beetle.framework.util.*;

public class InterruptConfig {

	private static Map COMMAND_ACTION = new HashMap();
	private static boolean com_read_flag = false;
	private static boolean dele_read_flag = false;
	private static Map DELEDATE_ACTION = new HashMap();
	private static InterruptConfig instance = new InterruptConfig();

	private InterruptConfig() {

	}

	public static InterruptConfig getInstance() {
		return instance;
	}

	public void readCommandActions(File xmlfile, InputStream xmlFileInputStream) {
		COMMAND_ACTION.clear();
		SAXReader reader = new SAXReader();
		try {
			Document doc = null;
			if (xmlfile != null && xmlFileInputStream == null) {
				doc = reader.read(xmlfile);
			} else if (xmlfile == null && xmlFileInputStream != null) {
				doc = reader.read(xmlFileInputStream);
			} else {
				return;
			}
			List list = doc.selectNodes("//Interrupt/Command/@ClassName");
			Iterator it = list.iterator();
			while (it.hasNext()) {
				Node node = (Node) it.next();
				String commandKey = node.getText();
				List actions = new LinkedList();
				Element element = node.getParent();
				Iterator iterator = element.elementIterator("Action");
				while (iterator.hasNext()) {
					ActionAttr attr = new ActionAttr();
					Element e = (Element) iterator.next();
					attr.setClassName(e.valueOf("@ClassName"));
					attr.setPointCut(e.valueOf("@PointCut"));
					// attr.setThreadSafe(toBool(e.valueOf("@ThreadSafe")));
					attr.setThreadSafe(checkClassIsThreadSafe(attr
							.getClassName()));
					actions.add(attr);
				}
				COMMAND_ACTION.put(commandKey, actions);
			}
		} catch (Exception de) {
			de.printStackTrace();
		}
	}

	private boolean checkClassIsThreadSafe(String classname) {
		boolean abl = false;
		try {
			abl = ReflectUtil.isThreadSafe(Class.forName(classname));
		} catch (ClassNotFoundException ex) {
			throw new com.beetle.framework.AppRuntimeException(
					"ClassNotFoundException:[" + classname + "]not found!", ex);
		}
		return abl;
	}

	/*
	 * private boolean toBool(String a) { boolean abl = false; if
	 * (a.toLowerCase().equals("true")) { abl = true; } return abl; }
	 */
	public void readDelegateActions(File xmlfile, InputStream xmlFileInputStream) {
		DELEDATE_ACTION.clear();
		SAXReader reader = new SAXReader();
		try {
			Document doc = null;
			if (xmlfile != null && xmlFileInputStream == null) {
				doc = reader.read(xmlfile);
			} else if (xmlfile == null && xmlFileInputStream != null) {
				doc = reader.read(xmlFileInputStream);
			} else {
				return;
			}
			List list = doc.selectNodes("//Interrupt/Delegate/@ClassName");
			Iterator it = list.iterator();
			// System.out.println(list.size());
			while (it.hasNext()) {
				Node node = (Node) it.next();
				String commandKey = node.getText();
				List actions = new LinkedList();
				Element element = node.getParent();
				Iterator iterator = element.elementIterator("Action");
				while (iterator.hasNext()) {
					ActionAttr attr = new ActionAttr();
					Element e = (Element) iterator.next();
					attr.setClassName(e.valueOf("@ClassName"));
					attr.setPointCut(e.valueOf("@PointCut"));
					// attr.setThreadSafe(toBool(e.valueOf("@ThreadSafe")));
					attr.setThreadSafe(checkClassIsThreadSafe(attr
							.getClassName()));
					actions.add(attr);
				}
				DELEDATE_ACTION.put(commandKey, actions);
			}
		} catch (Exception de) {
			de.printStackTrace();
		}
	}

	public static Map getCommandActions() {
		if (!com_read_flag) {
			File f = new File(ResourceReader.getAPP_HOME()
					+ "config/Interrupt.xml");
			if (f.exists()) {
				InterruptConfig.getInstance().readCommandActions(f, null);
				SysLogger.getInstance(InterruptConfig.class).info(
						"from file:[" + f.getPath() + "]");
			} else {
				try {
					InterruptConfig.getInstance().readCommandActions(
							null,
							ResourceLoader
									.getResAsStream("config/Interrupt.xml"));
					SysLogger.getInstance(InterruptConfig.class).info(
							"from jar:["
									+ ResourceLoader.getClassLoader()
											.toString() + "]");
				} catch (IOException ex) {
					SysLogger.getInstance(InterruptConfig.class).warn(
							"no Interrupt.xml found!");
				}
			}
			com_read_flag = true;
		}
		return COMMAND_ACTION;
	}

	public static Map getDelegateActions() {
		if (!dele_read_flag) {
			File f = new File(ResourceReader.getAPP_HOME()
					+ "config/Interrupt.xml");
			if (f.exists()) {
				InterruptConfig.getInstance().readDelegateActions(f, null);
				SysLogger.getInstance(InterruptConfig.class).info(
						"from file:[" + f.getPath() + "]");
			} else {
				try {
					InterruptConfig.getInstance().readDelegateActions(
							null,
							ResourceLoader
									.getResAsStream("config/Interrupt.xml"));
					SysLogger.getInstance(InterruptConfig.class).info(
							"from jar:["
									+ ResourceLoader.getClassLoader()
											.toString() + "]");
				} catch (IOException ex) {
					SysLogger.getInstance(InterruptConfig.class).warn(
							"no Interrupt.xml found!");
				}
			}
			dele_read_flag = true;
		}
		return DELEDATE_ACTION;
	}

}

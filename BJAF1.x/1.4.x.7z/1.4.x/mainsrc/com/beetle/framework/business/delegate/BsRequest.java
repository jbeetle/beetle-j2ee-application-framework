/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.beetle.framework.util.ObjectUtil;

public class BsRequest implements java.io.Serializable {
	private static final long serialVersionUID = -19760224l;

	private Map params;
	private String businessClassURL;

	public BsRequest() {
		params = new HashMap();
	}

	/**
	 * 设置参数
	 * 
	 * @param parameterName
	 *            参数名称
	 * @param parameterValue
	 *            参数值
	 */
	public void setParameter(String parameterName, Object parameterValue) {
		params.put(parameterName, parameterValue);
	}

	public Object getParameter(String parameterName) {
		Object o = params.get(parameterName);
		if (o == null) {
			return null;
		}
		if (o instanceof Map) {
			Map map = (Map) o;
			String cn = (String) map.get(parameterName);
			if (cn == null) {
				return o;
			}
			Object obj = null;
			try {
				obj = Class.forName(cn).newInstance();
				map.remove(parameterName);
				ObjectUtil.populate(obj, map);
			} catch (Exception e) {
				throw new com.beetle.framework.AppRuntimeException(
						"对此对象解析出现问题，不支持", e);
			}
			return obj;
		} else {
			return o;
		}
	}

	public String getParameterAsString(String parameterName) {
		return (String) getParameter(parameterName);
	}

	public Integer getParameterAsInteger(String parameterName) {
		return (Integer) getParameter(parameterName);
	}

	public Long getParameterAsLong(String parameterName) {
		return (Long) getParameter(parameterName);
	}

	public List getParameterAsList(String parameterName) {
		Object o = getParameter(parameterName);
		if (o == null) {
			return null;
		}
		List tl = (List) o;
		if (tl.isEmpty()) {
			return tl;
		}
		Object to = tl.get(0);
		if (to instanceof Map) {
			Map map = (Map) to;
			if (!map.containsKey(parameterName)) {
				return tl;
			} else {
				List ol = new ArrayList();
				for (int i = 0; i < tl.size(); i++) {
					Map m = (Map) tl.get(i);
					String cn = (String) m.get(parameterName);
					Object obj = null;
					try {
						obj = Class.forName(cn).newInstance();
						map.remove(parameterName);
						ObjectUtil.populate(obj, map);
					} catch (Exception e) {
						tl.clear();
						ol.clear();
						throw new com.beetle.framework.AppRuntimeException(
								"对此对象解析出现问题，不支持", e);
					}
					ol.add(obj);
				}
				tl.clear();
				return ol;
			}
		} else {
			return tl;
		}
	}

	public Map getParameterAsMap(String parameterName) {
		return (Map) getParameter(parameterName);
	}

	public Time getParameterAsTime(String parameterName) {
		return (Time) getParameter(parameterName);
	}

	public java.util.Date getParameterAsDate(String parameterName) {
		return (java.util.Date) getParameter(parameterName);
	}

	public Timestamp getParameterAsTimestamp(String parameterName) {
		return (Timestamp) getParameter(parameterName);
	}

	public void clear() {
		params.clear();
	}

	/**
	 * finalize
	 * 
	 * @throws Throwable
	 * @todo Implement this java.lang.Object method
	 */
	protected void finalize() throws Throwable {
		//businessClassURL = null;
		if (!params.isEmpty()) {
			params.clear();
			//params = null;
		}
		super.finalize();
	}

	public Map peek() {
		return params;
	}

	public String getBusinessURL() {
		return businessClassURL;
	}

	/**
	 * 注册业务类的URL url--一般就是此业务类的包路径+名称
	 * 
	 * @param businessURL
	 *            String
	 */
	public void registerBusinessURL(String businessURL) {
		this.businessClassURL = businessURL;
	}

}

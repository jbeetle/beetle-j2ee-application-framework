/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate.imp;

import com.beetle.framework.business.common.jta.*;
import com.beetle.framework.business.delegate.*;
import com.beetle.framework.business.interrupt.*;
import com.beetle.framework.util.*;
import com.beetle.framework.util.cache.*;

/**
 * <p>Title: BeetleSoft Framework</p>
 *
 * <p>Description: J2EE系统开发框架</p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东
 * @version 1.0
 */
public class PojoTarget
    implements IDelegateTarget {
  private static PojoTarget instance = new PojoTarget();
  private static ICache cacheSafeObj = new StrongCache(512);

  private PojoTarget() {

  }

  /*
    private void checkUrl2(String businessURL) {
      if (businessURL == null) {
        throw new com.beetle.framework.AppRuntimeException(
            "the businessURL can not be null!");
      }
      try {
        Class c = Class.forName(businessURL);
        if (!ReflectUtil.isContainMethod(c, "execute")) {
          throw new com.beetle.framework.AppRuntimeException(
              "the class has not a execute method, is unlawful");
        }
      }
      catch (ClassNotFoundException ex) {
   throw new com.beetle.framework.AppRuntimeException("the url is unlawful",
            ex);
      }
    }
   */
  private Object getFromNative(String logicClass) {
    //checkUrl(logicClass);
    Object localObject = null;
    try {
      //Class[] constrParamTypes = new Class[] {};
      //Object[] constrParamValues = new Object[] {};
      localObject = ReflectUtil.newInstance(logicClass, null,
                                            null);
      return localObject;
    }
    catch (Exception t) {
      throw new com.beetle.framework.AppRuntimeException(
          "create service obj err!");
    }
  }

  private BsResponse getErrResultObj(String errMsg) {
    BsResponse ro = new BsResponse();
    ro.setReturnFlag(BsResponse.FATAL_ERR_FLAG);
    ro.setReturnMsg(errMsg);
    return ro;
  }

  public BsResponse executeBusinessWithTransaction(BsRequest bsReq) throws
      DelegateExecuteException {
    //begin point cut
    int procSignal = ActionExecutor.beginPointCutExecute(bsReq, null);
    if (procSignal == ActionSignal.PROCESS_BREAK) {
      return new BsResponse();
    }
    //
    ITransaction trans = null;
    BsResponse rd = null;
    try {
      trans = JTAFactory.getTransactionFromFramework();
      IBusiness serviceObject = callServiceObj(bsReq);
      trans.begin();
      rd = serviceObject.execute(bsReq);
      trans.commit();
      //end point cut
      ActionExecutor.endPointCutExecute(bsReq, rd);
      return rd;
    }
    catch (JTAException jta) {
      throw new DelegateExecuteException(jta);
    }
    catch (BusinessException t) {
      trans.rollback();
      if (t instanceof BusinessRollbackException) {
        System.out.println("rollback by hand!");
        BusinessRollbackException t2 = (BusinessRollbackException) t;
        return t2.getBs();
      }
      else {
        return getErrResultObj(t.getMessage());
      }

    }
    catch (Exception e) {
      trans.rollback();
      e.printStackTrace();
      return getErrResultObj(e.getMessage());
    }
    finally {
      if (bsReq != null) {
        bsReq.clear();
      }
      trans = null;
    }
  }

  public static PojoTarget getInstance() {
    return instance;
  }

  public BsResponse executeBusiness(BsRequest bsReq) throws
      DelegateExecuteException {
    //begin point cut
    int procSignal = ActionExecutor.beginPointCutExecute(bsReq, null);
    if (procSignal == ActionSignal.PROCESS_BREAK) {
      return new BsResponse();
    }
    try {
      IBusiness serviceObject = callServiceObj(bsReq);
      BsResponse rd = serviceObject.execute(bsReq);
      //end point cut
      ActionExecutor.endPointCutExecute(bsReq, rd);
      return rd;
    }
    catch (BusinessException t) {
      return getErrResultObj(t.getMessage());
    }
    finally {
      if (bsReq != null) {
        bsReq.clear();
      }
    }
  }

  private IBusiness callServiceObj(BsRequest params) {
    IBusiness serviceObject = (IBusiness) cacheSafeObj.get(
        params.getBusinessURL());
    if (serviceObject == null) {
      serviceObject = (IBusiness) getFromNative(params.getBusinessURL());
      if (ReflectUtil.isThreadSafe(serviceObject.getClass())) {
        cacheSafeObj.put(params.getBusinessURL(), serviceObject);
      }
    }
    return serviceObject;
  }

}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate;

/**
 * <p>Title: BeetleSoft Framework</p>
 *
 * <p>Description: J2EE系统开发框架</p>
 *
 * <p>Copyright: Copyright (c) 2003</p>
 *
 * <p>Company: 甲壳虫软件</p>
 *
 * @author 余浩东
 * @version 1.0
 */

import com.beetle.framework.business.BusinessConfigReader;
import com.beetle.framework.business.delegate.imp.AsynchroCallImp;
import com.beetle.framework.business.delegate.imp.AsynchroCallImp.AsynTask;
import com.beetle.framework.business.delegate.imp.EjbLocalTarget;
import com.beetle.framework.business.delegate.imp.EjbRemoteTarget;
import com.beetle.framework.business.delegate.imp.PojoTarget;
import com.beetle.framework.business.delegate.imp.RPCTarget;

public final class DelegateExecutor {
	public final static int EJB_LOCAL_EXECUTE = 1;
	public final static int EJB_REMOTEL_EXECUTE = 2;
	public final static int COMMON_EXECUTE = 3;
	public final static int RPC_EXECUTE = 4;
	private static int exe_flag = -1;
	static {
		// exe_flag =
		// Integer.parseInt(BusinessConfigReader.getDelegateLogicValue(
		// "DELEGATE_EXECUTE_FLAG"));
	}

	public static BsResponse executeBusinessWithTransaction(BsRequest params)
			throws DelegateExecuteException {
		if (exe_flag == -1) {
			exe_flag = Integer.parseInt(BusinessConfigReader
					.getDelegateLogicValue("DELEGATE_EXECUTE_FLAG"));
		}
		return executeBusinessWithTransaction(params, exe_flag);
	}

	public static BsResponse executeBusinessWithTransaction(BsRequest params,
			int delegateExecuteFlag) throws DelegateExecuteException {
		IDelegateTarget target = getTarget(delegateExecuteFlag);
		return target.executeBusinessWithTransaction(params);
	}

	private static IDelegateTarget getTarget(int delegateExecuteFlag) {
		IDelegateTarget target = null;
		switch (delegateExecuteFlag) {
		case EJB_LOCAL_EXECUTE:
			target = EjbLocalTarget.getInstance();
			break;
		case EJB_REMOTEL_EXECUTE:
			target = EjbRemoteTarget.getInstance();
			break;
		case COMMON_EXECUTE:
			target = PojoTarget.getInstance();
			break;
		case RPC_EXECUTE:
			target = RPCTarget.getInstance();
			break;
		default:
			target = EjbLocalTarget.getInstance();
		}
		return target;
	}

	public static void asynchroExecuteBusiness(BsRequest params,
			IBusinessCallBack callback) throws DelegateExecuteException {
		try {
			AsynTask at = new AsynTask();
			at.setBack(callback);
			at.setReq(params);
			at.setDealFlag(10);
			AsynchroCallImp.getInstance().addTask(at);
		} catch (Exception e) {
			throw new DelegateExecuteException(e);
		}
	}

	public static void asynchroExecuteBusiness(BsRequest params,
			int delegateExecuteFlag, IBusinessCallBack callback)
			throws DelegateExecuteException {
		try {
			AsynTask at = new AsynTask();
			at.setBack(callback);
			at.setReq(params);
			at.setDealFlag(11);
			at.setDelegateExecuteFlag(delegateExecuteFlag);
			AsynchroCallImp.getInstance().addTask(at);
		} catch (Exception e) {
			throw new DelegateExecuteException(e);
		}
	}

	public static void asynchroExecuteBusinessWithTransaction(BsRequest params,
			IBusinessCallBack callback) throws DelegateExecuteException {
		try {
			AsynTask at = new AsynTask();
			at.setBack(callback);
			at.setReq(params);
			at.setDealFlag(20);
			AsynchroCallImp.getInstance().addTask(at);
		} catch (Exception e) {
			throw new DelegateExecuteException(e);
		}
	}

	public static void asynchroExecuteBusinessWithTransaction(BsRequest params,
			int delegateExecuteFlag, IBusinessCallBack callback)
			throws DelegateExecuteException {
		try {
			AsynTask at = new AsynTask();
			at.setBack(callback);
			at.setReq(params);
			at.setDealFlag(21);
			at.setDelegateExecuteFlag(delegateExecuteFlag);
			AsynchroCallImp.getInstance().addTask(at);
		} catch (Exception e) {
			throw new DelegateExecuteException(e);
		}
	}

	public static BsResponse executeBusiness(BsRequest params)
			throws DelegateExecuteException {
		if (exe_flag == -1) {
			exe_flag = Integer.parseInt(BusinessConfigReader
					.getDelegateLogicValue("DELEGATE_EXECUTE_FLAG"));
		}
		return executeBusiness(params, exe_flag);
	}

	public static BsResponse executeBusiness(BsRequest params,
			int delegateExecuteFlag) throws DelegateExecuteException {
		IDelegateTarget target = getTarget(delegateExecuteFlag);
		return target.executeBusiness(params);
	}

}

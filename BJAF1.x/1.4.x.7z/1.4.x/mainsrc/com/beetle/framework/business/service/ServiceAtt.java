/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.service;

import java.io.Serializable;

public class ServiceAtt implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String id;
	private String impClass;
	private String location;// 有多个的情况xxx#mmm
	private String transAttribute;
	private String type;
	private String enabled;
	private String timeout;
	private String currentLocation;// 当前使用使用的location位置，此属性由运行时动态指定
	public static final String type_Local = "Local";
	public static final String type_Remote = "Remote";
	public static final String type_Web = "Web";
	public static final String transAttribute_Supports = "Supports";
	public static final String transAttribute_NotSupported = "NotSupported";
	public static final String transAttribute_Required = "Required";
	private static final String tipflag = "#";

	public String getId() {
		return id;
	}

	public String[] getLocations() {
		return location.split(tipflag);
	}

	public String getTransAttribute() {
		return transAttribute;
	}

	public void setTransAttribute(String transAttribute) {
		this.transAttribute = transAttribute;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getImpClass() {
		return impClass;
	}

	public void setImpClass(String impClass) {
		this.impClass = impClass;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEnabled() {
		return enabled;
	}

	public void setEnabled(String enabled) {
		this.enabled = enabled;
	}

	public String getTimeout() {
		return timeout;
	}

	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}

	public String getCurrentLocation() {
		return currentLocation;
	}

	public void setCurrentLocation(String currentLocation) {
		this.currentLocation = currentLocation;
	}
}

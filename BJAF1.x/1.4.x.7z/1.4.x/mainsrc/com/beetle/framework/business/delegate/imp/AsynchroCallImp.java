package com.beetle.framework.business.delegate.imp;

import com.beetle.framework.appsrv.AppThreadImp;
import com.beetle.framework.appsrv.RoutineExecutor;
import com.beetle.framework.appsrv.RoutinesPool.WorkThreadPool;
import com.beetle.framework.appsrv.SubRoutine;
import com.beetle.framework.business.BusinessConfigReader;
import com.beetle.framework.business.delegate.BsRequest;
import com.beetle.framework.business.delegate.DelegateExecutor;
import com.beetle.framework.business.delegate.IBusinessCallBack;
import com.beetle.framework.log.SysLogger;
import com.beetle.framework.util.queue.BlockQueue;
import com.beetle.framework.util.queue.IQueue;

public class AsynchroCallImp {
	private static AsynchroCallImp instance = new AsynchroCallImp();
	private WorkThreadPool wtp;
	private IQueue cmdQueue;
	private Consumer consumer;

	public static AsynchroCallImp getInstance() {
		return instance;
	}

	private class Consumer extends AppThreadImp {

		public Consumer(String threadName) {
			super(threadName);
		}

		protected void workProc() {
			AsynTask task = (AsynTask) cmdQueue.pop();
			execute(task);
		}

	}

	public static class AsynTask {

		public BsRequest getReq() {
			return req;
		}

		public void setReq(BsRequest req) {
			this.req = req;
		}

		public IBusinessCallBack getBack() {
			return back;
		}

		public void setBack(IBusinessCallBack back) {
			this.back = back;
		}

		public int getDelegateExecuteFlag() {
			return delegateExecuteFlag;
		}

		public void setDelegateExecuteFlag(int delegateExecuteFlag) {
			this.delegateExecuteFlag = delegateExecuteFlag;
		}

		private BsRequest req;
		private IBusinessCallBack back;
		private int dealFlag;
		private int delegateExecuteFlag;

		public int getDealFlag() {
			return dealFlag;
		}

		public void setDealFlag(int dealFlag) {
			this.dealFlag = dealFlag;
		}

	}

	private static class Worker extends SubRoutine {
		private AsynTask task;

		public Worker(AsynTask task) {
			super();
			this.task = task;
		}

		protected void routine() throws InterruptedException {
			try {
				if (task.getDealFlag() == 10) {
					task.getBack().handle(
							DelegateExecutor.executeBusiness(task.getReq()));
				} else if (task.getDealFlag() == 11) {
					task.getBack().handle(
							DelegateExecutor.executeBusiness(task.getReq(),
									task.getDelegateExecuteFlag()));
				} else if (task.getDealFlag() == 20) {
					task.getBack().handle(
							DelegateExecutor
									.executeBusinessWithTransaction(task
											.getReq()));
				} else if (task.getDealFlag() == 21) {
					task.getBack().handle(
							DelegateExecutor.executeBusinessWithTransaction(
									task.getReq(),
									task.getDelegateExecuteFlag()));
				} else {
					throw new InterruptedException(
							"can't foun this case,please check delegate!");
				}
			} catch (Exception e) {
				e.printStackTrace();
				throw new InterruptedException(
						SysLogger.getErrStackTraceInfo(e));
			}
		}
	}

	private AsynchroCallImp() {
		String size = BusinessConfigReader
				.getDelegateLogicValue("ASYNCHRO_CALL_QUEUE_SIZE");
		if (size == null || size.length() == 0) {
			size = "10";
		}
		int size2 = Integer.parseInt(size.trim());
		wtp = new WorkThreadPool(size2, size2, 5 * 1000 * 60, 2);
		cmdQueue = new BlockQueue();
		consumer = new Consumer("AsynchroCallConsumer");
		consumer.startNow();
	}

	public void clear() {
		if (wtp != null) {
			wtp.shutdown();
			wtp = null;
		}
		if (consumer != null) {
			consumer.stopNow();
		}
	}

	public void addTask(AsynTask task) {
		cmdQueue.push(task);
	}

	private void execute(AsynTask task) {
		try {
			RoutineExecutor re = new RoutineExecutor(this.wtp);
			re.addSubRoutine(new Worker(task));
			re.runRoutine();
			re = null;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

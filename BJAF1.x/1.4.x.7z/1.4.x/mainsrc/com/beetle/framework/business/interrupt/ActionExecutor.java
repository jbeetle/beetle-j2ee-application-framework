/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.interrupt;

import java.util.*;

import com.beetle.framework.business.command.*;
import com.beetle.framework.business.delegate.*;
import com.beetle.framework.business.interrupt.cmd.*;
import com.beetle.framework.business.interrupt.delegate.*;
import com.beetle.framework.log.*;
import com.beetle.framework.util.cache.*;

/**
 * @author Henry Yu 2005-4-11
 *
 */


public class ActionExecutor {
  private final static String begin = "begin";
  private final static String end = "end";
  private static ICache cache = new StrongCache();
  private static SysLogger logger = SysLogger.getInstance();
  public static void endPointCutExecute(BsRequest bsReq, BsResponse bsRes) {
    Map map = InterruptConfig.getDelegateActions();
    if (!map.isEmpty()) {
      List actions = new ArrayList();
      loadDlgActions(bsReq, map, actions);
      if (actions.isEmpty()) {
        return;
      }
      Iterator it = actions.iterator();
      while (it.hasNext()) {
        ActionAttr attr = (ActionAttr) it.next();
        if (attr.getPointCut().equals(end)) {
          try {
            Object obj = null;
            if (attr.isThreadSafe()) {
              obj = cache.get(attr.getClassName());
              if (obj == null) {
                obj = Class.forName(attr.getClassName())
                    .newInstance();
                cache.put(attr.getClassName(), obj);
              }
            }
            else {
              obj = Class.forName(attr.getClassName())
                  .newInstance();
            }
            IDelegateAction action = (IDelegateAction) obj;
            action.execute(bsReq, bsRes);
            if (logger.isDebugEnabled()) {
              logger.debug("executed[" + action.getClass().getName() +
                           "]action at [" + bsReq.getBusinessURL() +
                           "] end pointcut");
            }
          }
          catch (Exception e) {
            logger.error(e);
          }
        }
      }
      actions.clear();
    }
  }

  public static void endPointCutExecute(CommandImp cmd) {
    Map map = InterruptConfig.getCommandActions();
    if (!map.isEmpty()) {
      List actions = new ArrayList();
      loadCmdActions(cmd, map, actions);
      if (actions.isEmpty()) {
        return;
      }
      Iterator it = actions.iterator();
      while (it.hasNext()) {
        ActionAttr attr = (ActionAttr) it.next();
        if (attr.getPointCut().equals(end)) {
          try {
            Object obj = null;
            if (attr.isThreadSafe()) {
              obj = cache.get(attr.getClassName());
              if (obj == null) {
                obj = Class.forName(attr.getClassName())
                    .newInstance();
                cache.put(attr.getClassName(), obj);
                if (logger.isDebugEnabled()) {
                  logger.debug("get action by new operate");
                }
              }
              else {
                if (logger.isDebugEnabled()) {
                  logger.debug("get action from cache");
                }
              }
            }
            else {
              obj = Class.forName(attr.getClassName())
                  .newInstance();
              if (logger.isDebugEnabled()) {
                logger.debug("get action by new operate");
              }
            }
            ICmdAction action = (ICmdAction) obj;
            action.execute(cmd);
            if (logger.isDebugEnabled()) {
              logger.debug("executed[" + action.getClass().getName() +
                           "]action at [" + cmd.getClass().getName() +
                           "] end pointcut");
            }
          }
          catch (Exception e) {
            logger.error(e);
          }
        }
      }
      actions.clear();
    }
  }

  /**
   * beginPointCutExecute
   *
   * @param cmd CommandImp
   * @return int
   */
  private static final String ALL_COMMAND = "ALL_COMMAND";
  public static int beginPointCutExecute(CommandImp cmd) {
    Map map = InterruptConfig.getCommandActions();
    if (!map.isEmpty()) {
      List actions = new ArrayList();
      loadCmdActions(cmd, map, actions);
      if (actions.isEmpty()) {
        return ActionSignal.PROCESS_CONTINUE;
      }
      Iterator it = actions.iterator();
      while (it.hasNext()) {
        ActionAttr attr = (ActionAttr) it.next();
        if (attr.getPointCut().equals(begin)) {
          try {
            Object obj = null;
            if (attr.isThreadSafe()) {
              obj = cache.get(attr.getClassName());
              if (obj == null) {
                obj = Class.forName(attr.getClassName())
                    .newInstance();
                if (logger.isDebugEnabled()) {
                  logger.debug("get action by new operate");
                }
                cache.put(attr.getClassName(), obj);
              }
              else {
                if (logger.isDebugEnabled()) {
                  logger.debug("get action from cache");
                }
              }
            }
            else {
              obj = Class.forName(attr.getClassName())
                  .newInstance();
              if (logger.isDebugEnabled()) {
                logger.debug("get action by new operate");
              }
            }
            ICmdAction action = (ICmdAction) obj;
            ActionSignal signal = action.execute(cmd);
            if (logger.isDebugEnabled()) {
              logger.debug("executed[" + action.getClass().getName() +
                           "]action at [" + cmd.getClass().getName() +
                           "] begen pointcut");
            }
            if (signal.getProcessFlag() == ActionSignal.PROCESS_BREAK) {
              actions.clear();
              return ActionSignal.PROCESS_BREAK;
            }
          }
          catch (Exception e) {
            logger.error(e);
          }
        }
      }
      actions.clear();
    }
    return ActionSignal.PROCESS_CONTINUE;
  }

  private static final String ALL_DELEGATE = "ALL_DELEGATE";

  private static void loadDlgActions(BsRequest bsReq, Map map,
                                     List actions) {
    List all_list = (List) map.get(ALL_DELEGATE);
    if (all_list != null && !all_list.isEmpty()) {
      actions.addAll(all_list);
      //all_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [ALL_DELEGATE] actions");
      }
    }
    String key = bsReq.getBusinessURL();
    int pos = key.indexOf('.');
    String path = key.substring(0, pos + 1);
    List path_list = (List) map.get(path);
    if (path_list != null && !path_list.isEmpty()) {
      actions.addAll(path_list);
      //path_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [package path] actions");
      }
    }
    List class_list = (List) map.get(key);
    if (class_list != null && !class_list.isEmpty()) {
      actions.addAll(class_list);
      //class_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [class] actions");
      }
    }
  }

  private static void loadCmdActions(CommandImp cmd, Map map, List actions) {
    List all_list = (List) map.get(ALL_COMMAND);
    if (all_list != null && !all_list.isEmpty()) {
      actions.addAll(all_list);
      //all_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [ALL_COMMAND] actions");
      }
    }
    String key = cmd.getClass().getName();
    int pos = key.indexOf('.');
    String path = key.substring(0, pos + 1);
    List path_list = (List) map.get(path);
    if (path_list != null && !path_list.isEmpty()) {
      actions.addAll(path_list);
      //path_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [package path] actions");
      }
    }
    List class_list = (List) map.get(key);
    if (class_list != null && !class_list.isEmpty()) {
      actions.addAll(class_list);
      //class_list.clear();
      if (logger.isDebugEnabled()) {
        logger.debug("load [class] actions");
      }
    }
  }

  public static int beginPointCutExecute(BsRequest bsReq, BsResponse bsRes) {
    Map map = InterruptConfig.getDelegateActions();
    if (!map.isEmpty()) {
      List actions = new ArrayList();
      loadDlgActions(bsReq, map, actions);
      if (actions.isEmpty()) {
        return ActionSignal.PROCESS_CONTINUE;
      }
      Iterator it = actions.iterator();
      while (it.hasNext()) {
        ActionAttr attr = (ActionAttr) it.next();
        if (attr.getPointCut().equals(begin)) {
          try {
            Object obj = null;
            if (attr.isThreadSafe()) {
              obj = cache.get(attr.getClassName());
              if (obj == null) {
                obj = Class.forName(attr.getClassName())
                    .newInstance();
                cache.put(attr.getClassName(), obj);
              }
            }
            else {
              obj = Class.forName(attr.getClassName())
                  .newInstance();
            }
            IDelegateAction action = (IDelegateAction) obj;
            ActionSignal signal = action.execute(bsReq, bsRes);
            if (logger.isDebugEnabled()) {
              logger.debug("executed[" + action.getClass().getName() +
                           "]action at [" + bsReq.getBusinessURL() +
                           "] begen pointcut");
            }
            if (signal.getProcessFlag() == ActionSignal.PROCESS_BREAK) {
              actions.clear();
              return ActionSignal.PROCESS_BREAK;
            }
          }
          catch (Exception e) {
            logger.error(e);
          }
        }
      }
      actions.clear();
    }
    return ActionSignal.PROCESS_CONTINUE;
  }
}

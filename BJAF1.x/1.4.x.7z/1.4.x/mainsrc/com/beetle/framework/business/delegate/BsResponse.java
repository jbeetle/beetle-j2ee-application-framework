/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.delegate;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 * Title: BeetleSoft Framework
 * </p>
 * 
 * <p>
 * Description: J2EE系统开发框架
 * </p>
 * 
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * 
 * <p>
 * Company: 甲壳虫软件
 * </p>
 * 
 * @author 余浩东
 * @version 1.0
 */

public class BsResponse implements java.io.Serializable {
	private static final long serialVersionUID = -19760224l;

	public static final int FATAL_ERR_FLAG = -1000;

	public static final int SUCCEED_FLAG = 0;

	public static final String SUCCEED_MSG = "ok";

	private int returnFlag = SUCCEED_FLAG;

	private String returnMsg = SUCCEED_MSG;

	private Map BsResponse;

	public BsResponse() {
		BsResponse = new HashMap();
	}

	public Map peek() {
		return BsResponse;
	}

	public void clear() {
		BsResponse.clear();
	}

	/**
	 * 以【key-value】设置返回值
	 * 
	 * @param valueName--唯一名称
	 * @param data--具体数据对象
	 */
	public void setValue(String valueName, Object data) {
		BsResponse.put(valueName, data);
		/*
		Class c = data.getClass();
		String tip = c.getName();
		if (tip.startsWith("java.")) {
			if (data instanceof List) {
				List l = (List) data;
				if (l.isEmpty()) {
					return;
				} else {
					Object o0 = l.get(0);
					if (o0.getClass().getName().startsWith("java.")) {
						BsResponse.put(valueName, data);
					} else {
						BsResponse.put(valueName + "_self_object_list", data);
					}
				}
			} else {
				BsResponse.put(valueName, data);
			}
		} else {
			BsResponse.put(valueName + "_self_object", data);
		}
		*/
	}

	/**
	 * 获取执行结果返回值
	 * 
	 * @param valueName
	 *            String
	 * @return Object
	 */
	public Object getValue(String valueName) {
		Object o = BsResponse.get(valueName);
		if (o == null) {
			o = BsResponse.get(valueName + "_self_object");
			if (o == null) {
				o = BsResponse.get(valueName + "_self_object_list");
			}
		}
		return o;
	}

	public String getValueAsString(String valueName) {
		return (String) getValue(valueName);
	}

	public Integer getValueAsInteger(String valueName) {
		return (Integer) getValue(valueName);
	}

	public Long getValueAsLong(String valueName) {
		return (Long) getValue(valueName);
	}

	public List getValueAsList(String valueName) {
		return (List) getValue(valueName);
	}

	public Map getValueAsMap(String valueName) {
		return (Map) getValue(valueName);
	}

	public Time getValueAsTime(String valueName) {
		return (Time) getValue(valueName);
	}

	public java.util.Date getValueAsDate(String valueName) {
		return (java.util.Date) getValue(valueName);
	}

	public Timestamp getValueAsTimestamp(String valueName) {
		return (Timestamp) getValue(valueName);
	}

	/**
	 * finalize
	 * 
	 * @throws Throwable
	 * @todo Implement this java.lang.Object method
	 */
	protected void finalize() throws Throwable {
		if (!BsResponse.isEmpty()) {
			BsResponse.clear();
			//BsResponse = null;
		}
		super.finalize();
	}

	/**
	 * 获取执行结果标记
	 * 
	 * @return int
	 */
	public int getReturnFlag() {
		return returnFlag;
	}

	/**
	 * 获取执行结果情况说明
	 * 
	 * @return String
	 */
	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnFlag(int returnFlag) {
		this.returnFlag = returnFlag;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.business.common.jms.queue;

import javax.jms.*;
import javax.naming.*;

import com.beetle.framework.business.*;
import com.beetle.framework.resource.*;

/**
 * <p>
 * Title: ������
 * </p>
 * <p>
 * Description: JMSQueue��Ϣͬ��������
 * </p>
 * <p>
 * Copyright: Copyright (c) 2003
 * </p>
 * <p>
 * Company: �׿ǳ�Ƽ�
 * </p>
 * 
 * @author ��ƶ�
 * @version 1.0
 */

abstract public class JMSQueueReader extends Thread {
	private QueueConnection queueConnection = null;

	private QueueSession queueSession = null;

	protected QueueReceiver queueReceiver = null;

	private String factoryName = null;

	public String getFactoryName() {
		return factoryName;
	}

	public String getQueueName() {
		return queueName;
	}

	private String queueName = "";

	public JMSQueueReader() {
		this.queueName = BusinessConfigReader.getQueueLogicValue("MTMSGQUEUE"); // ΪĬ��
		this.factoryName = BusinessConfigReader
				.getQueueLogicValue("JMSCONNFACTORY");
		this.init(null);
	}

	/**
	 * @param ejbContainerTagName
	 *            --������ǩ��ƣ���SysConfig.xml������
	 * @param queueName
	 *            --�������
	 * @param factoryName
	 *            --���й������
	 */
	public JMSQueueReader(String ejbContainerTagName, String queueName,
			String factoryName) {
		this.queueName = queueName;
		this.factoryName = factoryName;
		this.init(ejbContainerTagName);
	}

	abstract public void dealObjMsg() throws JMSQueueException;

	public ObjectMessage receiveObjMsg() throws JMSQueueException {
		ObjectMessage om = null;
		try {
			om = (ObjectMessage) queueReceiver.receive();
		} catch (JMSException jms) {
			throw new JMSQueueException("������Ϣ����", jms);
		}
		return om;
	}

	protected void init(String ejbContainerTagName) {
		try {
			Context ctx = null;
			if (ejbContainerTagName == null) {
				ctx = AppContext.getRemoteEJBContainerContext();
			} else {
				ctx = AppContext
						.getRemoteEJBContainerContext(ejbContainerTagName);
			}
			QueueConnectionFactory conFactory = (QueueConnectionFactory) ctx
					.lookup(this.factoryName);
			queueConnection = conFactory.createQueueConnection();
			queueSession = queueConnection.createQueueSession(false,
					Session.AUTO_ACKNOWLEDGE);
			Queue queue = (Queue) ctx.lookup(queueName);
			queueReceiver = queueSession.createReceiver(queue);
			queueConnection.start(); //
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (JMSException je) {
			je.printStackTrace();
		}
	}

	public void close() throws JMSQueueException {
		try {
			queueReceiver.close();
			queueSession.close();
			queueConnection.close();
		} catch (JMSException e) {
			throw new JMSQueueException(e);
		}
	}

	public void run() {
		try {
			while (true) {
				dealObjMsg();
				sleep(50);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void destroy() {
		try {
			close();
		} catch (Exception e) {
		}
		//super.destroy();
	}
}

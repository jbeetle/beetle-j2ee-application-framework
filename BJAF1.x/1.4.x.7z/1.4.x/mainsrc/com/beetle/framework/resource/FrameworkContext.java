/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.resource;

import java.util.Enumeration;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.Name;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;

public class FrameworkContext implements Context {
	private static Hashtable table = new Hashtable();
	private static FrameworkContext instance = new FrameworkContext();

	public Enumeration getContextKeys() {
		return table.keys();
	}

	private FrameworkContext() {
		// table = new Hashtable();
	}

	/**
	 * Adds a new environment property to the environment of this context.
	 * 
	 * @param propName
	 *            the name of the environment property to add; may not be null
	 * @param propVal
	 *            the value of the property to add; may not be null
	 * @return the previous value of the property, or null if the property was
	 *         not in the environment before
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object addToEnvironment(String propName, Object propVal)
			throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Binds a name to an object.
	 * 
	 * @param name
	 *            the name to bind; may not be empty
	 * @param obj
	 *            the object to bind; possibly null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void bind(String name, Object obj) throws NamingException {
		table.put(name, obj);
	}

	/**
	 * Binds a name to an object.
	 * 
	 * @param name
	 *            the name to bind; may not be empty
	 * @param obj
	 *            the object to bind; possibly null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void bind(Name name, Object obj) throws NamingException {
		table.put(name, obj);
	}

	/**
	 * Closes this context.
	 * 
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void close() throws NamingException {
		if (!table.isEmpty()) {
			table.clear();
		}
	}

	/**
	 * Composes the name of this context with a name relative to this context.
	 * 
	 * @param name
	 *            a name relative to this context
	 * @param prefix
	 *            the name of this context relative to one of its ancestors
	 * @return the composition of <code>prefix</code> and <code>name</code>
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Name composeName(Name name, Name prefix) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Composes the name of this context with a name relative to this context.
	 * 
	 * @param name
	 *            a name relative to this context
	 * @param prefix
	 *            the name of this context relative to one of its ancestors
	 * @return the composition of <code>prefix</code> and <code>name</code>
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public String composeName(String name, String prefix)
			throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Creates and binds a new context.
	 * 
	 * @param name
	 *            the name of the context to create; may not be empty
	 * @return the newly created context
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Context createSubcontext(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Creates and binds a new context.
	 * 
	 * @param name
	 *            the name of the context to create; may not be empty
	 * @return the newly created context
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Context createSubcontext(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Destroys the named context and removes it from the namespace.
	 * 
	 * @param name
	 *            the name of the context to be destroyed; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void destroySubcontext(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Destroys the named context and removes it from the namespace.
	 * 
	 * @param name
	 *            the name of the context to be destroyed; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void destroySubcontext(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Retrieves the environment in effect for this context.
	 * 
	 * @return the environment of this context; never null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Hashtable getEnvironment() throws NamingException {
		return table;
	}

	/**
	 * Retrieves the full name of this context within its own namespace.
	 * 
	 * @return this context's name in its own namespace; never null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public String getNameInNamespace() throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Retrieves the parser associated with the named context.
	 * 
	 * @param name
	 *            the name of the context from which to get the parser
	 * @return a name parser that can parse compound names into their atomic
	 *         components
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NameParser getNameParser(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Retrieves the parser associated with the named context.
	 * 
	 * @param name
	 *            the name of the context from which to get the parser
	 * @return a name parser that can parse compound names into their atomic
	 *         components
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NameParser getNameParser(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Enumerates the names bound in the named context, along with the class
	 * names of objects bound to them.
	 * 
	 * @param name
	 *            the name of the context to list
	 * @return an enumeration of the names and class names of the bindings in
	 *         this context. Each element of the enumeration is of type
	 *         <tt>NameClassPair</tt>.
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NamingEnumeration list(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Enumerates the names bound in the named context, along with the class
	 * names of objects bound to them.
	 * 
	 * @param name
	 *            the name of the context to list
	 * @return an enumeration of the names and class names of the bindings in
	 *         this context. Each element of the enumeration is of type
	 *         <tt>NameClassPair</tt>.
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NamingEnumeration list(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Enumerates the names bound in the named context, along with the objects
	 * bound to them.
	 * 
	 * @param name
	 *            the name of the context to list
	 * @return an enumeration of the bindings in this context. Each element of
	 *         the enumeration is of type <tt>Binding</tt>.
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NamingEnumeration listBindings(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Enumerates the names bound in the named context, along with the objects
	 * bound to them.
	 * 
	 * @param name
	 *            the name of the context to list
	 * @return an enumeration of the bindings in this context. Each element of
	 *         the enumeration is of type <tt>Binding</tt>.
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public NamingEnumeration listBindings(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Retrieves the named object.
	 * 
	 * @param name
	 *            the name of the object to look up
	 * @return the object bound to <tt>name</tt>
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object lookup(String name) throws NamingException {
		return table.get(name);
	}

	/**
	 * Retrieves the named object.
	 * 
	 * @param name
	 *            the name of the object to look up
	 * @return the object bound to <tt>name</tt>
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object lookup(Name name) throws NamingException {
		return table.get(name);
	}

	/**
	 * Retrieves the named object, following links except for the terminal
	 * atomic component of the name.
	 * 
	 * @param name
	 *            the name of the object to look up
	 * @return the object bound to <tt>name</tt>, not following the terminal
	 *         link (if any).
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object lookupLink(Name name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Retrieves the named object, following links except for the terminal
	 * atomic component of the name.
	 * 
	 * @param name
	 *            the name of the object to look up
	 * @return the object bound to <tt>name</tt>, not following the terminal
	 *         link (if any)
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object lookupLink(String name) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Binds a name to an object, overwriting any existing binding.
	 * 
	 * @param name
	 *            the name to bind; may not be empty
	 * @param obj
	 *            the object to bind; possibly null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void rebind(Name name, Object obj) throws NamingException {
		if (table.containsKey(name)) {
			table.remove(name);
		}
		table.put(name, obj);
	}

	/**
	 * Binds a name to an object, overwriting any existing binding.
	 * 
	 * @param name
	 *            the name to bind; may not be empty
	 * @param obj
	 *            the object to bind; possibly null
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void rebind(String name, Object obj) throws NamingException {
		if (table.containsKey(name)) {
			table.remove(name);
		}
		table.put(name, obj);
	}

	/**
	 * Removes an environment property from the environment of this context.
	 * 
	 * @param propName
	 *            the name of the environment property to remove; may not be
	 *            null
	 * @return the previous value of the property, or null if the property was
	 *         not in the environment
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public Object removeFromEnvironment(String propName) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Binds a new name to the object bound to an old name, and unbinds the old
	 * name.
	 * 
	 * @param oldName
	 *            the name of the existing binding; may not be empty
	 * @param newName
	 *            the name of the new binding; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void rename(Name oldName, Name newName) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Binds a new name to the object bound to an old name, and unbinds the old
	 * name.
	 * 
	 * @param oldName
	 *            the name of the existing binding; may not be empty
	 * @param newName
	 *            the name of the new binding; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void rename(String oldName, String newName) throws NamingException {
		throw new com.beetle.framework.AppRuntimeException(
				"the method not implement!");
	}

	/**
	 * Unbinds the named object.
	 * 
	 * @param name
	 *            the name to unbind; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void unbind(String name) throws NamingException {
		if (table.containsKey(name)) {
			table.remove(name);
		}
	}

	/**
	 * Unbinds the named object.
	 * 
	 * @param name
	 *            the name to unbind; may not be empty
	 * @throws NamingException
	 *             if a naming exception is encountered
	 * @todo Implement this javax.naming.Context method
	 */
	public void unbind(Name name) throws NamingException {
		if (table.containsKey(name)) {
			table.remove(name);
		}
	}

	public static FrameworkContext getInstance() {
		return instance;
	}
}

/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.resource.define;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.util.ObjectUtil;
import com.beetle.framework.util.OtherUtil;

public class BaseDTO extends HashMap {
	/**
	 *
	 */
	private static final long serialVersionUID = 1L;

	public BaseDTO() {
	}

	/**
	 * 获取简单对象列表
	 *
	 * @deprecated
	 * @param key
	 * @return List
	 */
	public List getValueAsSimpleObjectList(String key) {
		List l = this.getValueAsList(key);
		if (l == null) {
			return null;
		}
		if (l.isEmpty()) {
			return l;
		}
		Object tip = l.get(0);
		if (tip instanceof Map) {
			List l2 = new ArrayList(l.size());
			Iterator it = l.iterator();
			while (it.hasNext()) {
				Map map = (Map) it.next();
				try {
					String cn = (String) map.get(key);
					if (cn == null) {
						throw new AppRuntimeException("非标准Map-Object映射数据，不支持"
								+ map.toString() + "]");
					}
					Object obj = Class.forName(cn).newInstance();
					map.remove(key);
					ObjectUtil.populate(obj, map);
					l2.add(obj);
				} catch (Exception ex) {
					l.clear();
					l2.clear();
					throw new AppRuntimeException("对此对象解析出现问题，不支持", ex);
				}
			}
			l.clear();
			return l2;
		} else {
			return l;
		}
	}

	/*
	 * public Object getValueAsSimpleObject(String key, Class objclass) { Map
	 * map = this.getValueAsMap(key); try { Object obj = objclass.newInstance();
	 * ObjectUtil.populate(obj, map); return obj; } catch (Exception ex) { throw
	 * new com.beetle.framework.AppRuntimeException( "�Դ˶������������⣬��֧��",
	 * ex); } }
	 */
	/**
	 * 获取简单值对象（对象属性为java基础类型，属性不能为自定义的对象或Map、List）
	 *
	 * @deprecated
	 * @param key
	 *            --名称（返回时输入名称）
	 * @return 值对象
	 */
	public Object getValueAsSimpleObject(String key) {
		Object o = this.get(key);
		if (o == null) {
			return null;
		}
		if (o instanceof Map) {
			Map map = this.getValueAsMap(key);
			try {
				String cn = (String) map.get(key);
				if (cn == null) {
					throw new AppRuntimeException("非标准Map-Object映射数据，不支持"
							+ map.toString() + "]");
				}
				Object obj = Class.forName(cn).newInstance();
				map.remove(key);
				ObjectUtil.populate(obj, map);
				return obj;
			} catch (Exception ex) {
				throw new AppRuntimeException("对此对象解析出现问题，不支持", ex);
			}
		} else {
			return o;
		}
	}

	/**
	 * 设置对象，如果采取http协议，不保证此对象会序列化成功，传递。 (根据此对象的复杂度而已)
	 *
	 * @param key
	 * @param Obj
	 */
	public void setValueWithObject(String key, Object Obj) {
		this.put(key, Obj);
	}

	/**
	 * 传输自定义的可序列化的对象
	 *
	 * @param key
	 * @param userDefinedObject
	 *            --必须可序列化，否则为null
	 */
	public void setValueWithUserDefinedObject(String key, Object userDefinedObject) {
		if (userDefinedObject == null) {
			this.put(key, null);
		} else {
			byte[] bytes = OtherUtil.objToBytes(userDefinedObject);
			if (bytes == null) {
				this.put(key, null);
			} else {
				this.put(key, bytes);
			}
		}
	}

	/**
	 * 获取传输的自定义对象
	 *
	 * @param key
	 * @return
	 */
	public Object getValueAsUserDefinedObject(String key) {
		Object o = this.get(key);
		if (o == null) {
			return null;
		} else {
			byte[] bytes = (byte[]) o;
			Object o2 = OtherUtil.bytesToObj(bytes);
			o = null;
			return o2;
		}
	}

	/**
	 * 设置简单对象（对象属性为java基础类型，属性不能为自定义的对象或Map、List）
	 *
	 * @deprecated
	 * @param 名称
	 * @param 值对象
	 */
	public void setValueWithSimpleObject(String key, Object simpleObj) {
		Class c = simpleObj.getClass();
		String tip = c.getName();
		if (tip.startsWith("java.")) {
			this.put(key, simpleObj);
			return;
		}
		try {
			Map map = ObjectUtil.describe(simpleObj);
			map.put(key, simpleObj.getClass().getName());// �洢��������Ա����
			this.setValueWithMap(key, map);
		} catch (Exception ex) {
			ex.printStackTrace();
			throw new AppRuntimeException("对此对象解析出现问题，不支持", ex);
		}
	}

	/**
	 * 设置内含简单值对象的列表
	 *
	 * @deprecated
	 * @param key
	 * @param simpleObjList
	 */
	public void setValueWithSimpleObjectList(String key, List simpleObjList) {
		if (simpleObjList.get(0).getClass().getName().startsWith("java.")) {
			this.put(key, simpleObjList);
			return;
		}
		List l = new ArrayList(simpleObjList.size());
		Iterator it = simpleObjList.iterator();
		while (it.hasNext()) {
			Object obj = it.next();
			try {
				Map map = ObjectUtil.describe(obj);
				map.put(key, obj.getClass().getName());// �洢��������Ա����
				l.add(map);
			} catch (Exception ex) {
				l.clear();
				simpleObjList.clear();
				ex.printStackTrace();
				throw new AppRuntimeException("�对此对象解析出现问题，不支持", ex);
			}
		}
		simpleObjList.clear();
		this.put(key, l);
	}

	public void setValueWithString(String key, String value) {
		this.put(key, value);
	}

	public void setValueWithInteger(String key, Integer value) {
		this.put(key, value);
	}

	public void setValueWithLong(String key, Long value) {
		this.put(key, value);
	}

	public void setValueWithFloat(String key, Float value) {
		this.put(key, value);
	}

	public void setValueWithDouble(String key, Double value) {
		this.put(key, value);
	}

	public void setValueWithBoolean(String key, Boolean value) {
		this.put(key, value);
	}

	public void setValueWithCharacter(String key, Character value) {
		this.put(key, value);
	}

	public void setValueWithDate(String key, Date value) {
		this.put(key, value);
	}

	/**
	 * 设置内含java基本类型数据的列表
	 *
	 * @param key
	 * @param value
	 */
	public void setValueWithList(String key, List value) {
		this.put(key, value);
	}

	/**
	 * 设置内含java基本类型数据的Map
	 *
	 * @param key
	 * @param value
	 */
	public void setValueWithMap(String key, Map value) {
		this.put(key, value);
	}

	public void setValueWithShort(String key, Short value) {
		this.put(key, value);
	}

	public void setValueWithByte(String key, Byte value) {
		this.put(key, value);
	}

	public String getValueAsString(String key) {
		return (String) this.get(key);
	}

	public Integer getValueAsInteger(String key) {
		return (Integer) this.get(key);
	}

	public Long getValueAsLong(String key) {
		return (Long) this.get(key);
	}

	public Float getValueAsFloat(String key) {
		return (Float) this.get(key);
	}

	public Double getValueAsDouble(String key) {
		return (Double) this.get(key);
	}

	public Boolean getValueAsBoolean(String key) {
		return (Boolean) this.get(key);
	}

	public Character getValueAsCharacter(String key) {
		return (Character) this.get(key);
	}

	public Date getValueAsDate(String key) {
		return (Date) this.get(key);
	}

	public List getValueAsList(String key) {
		return (List) this.get(key);
	}

	public Map getValueAsMap(String key) {
		return (Map) this.get(key);
	}

	public Short getValueAsShort(String key) {
		return (Short) this.get(key);
	}

	public Byte getValueAsByte(String key) {
		return (Byte) this.get(key);
	}

	public Object getValueAsObject(String key) {
		return this.get(key);
	}

	/**
	 * put
	 *
	 * @deprecated
	 * @return Object
	 */
	public Object put(Object arg0, Object arg1) {
		return super.put(arg0, arg1);
	}

	/**
	 * get
	 *
	 * @deprecated
	 * @return Object
	 */
	public Object get(Object arg0) {
		return super.get(arg0);
	}
}

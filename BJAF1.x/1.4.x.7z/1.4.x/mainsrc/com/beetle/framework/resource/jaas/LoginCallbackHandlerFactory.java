/*
 * BJAF - Beetle J2EE Application Framework
 * 甲壳虫J2EE企业应用开发框架
 * 版权所有2003-2015 余浩东 (www.beetlesoft.net)
 * 
 * 这是一个免费开源的软件，您必须在《甲壳虫J2EE应用框架软件授权协议》
 *< http://www.beetlesoft.net/j2ee/download/beetle_license.txt/>
 *   或《GNU Lesser General Public License v3.0》
 *<http://www.gnu.org/licenses/lgpl-3.0.txt/>下合法使用、修改或重新发布。
 *
 * 感谢您使用、推广本框架，若有建议或问题，欢迎您和我联系。
 * 邮件： <yuhaodong@gmail.com/>.
 */
package com.beetle.framework.resource.jaas;

import java.security.PrivilegedAction;

import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;

import com.beetle.framework.AppRuntimeException;
import com.beetle.framework.resource.SysConfigReader;
import weblogic.security.Security;

public class LoginCallbackHandlerFactory {
	public static CallbackHandler create(String tagname, String user,
			String password, String url) {
		CallbackHandler handler = null;
		String pdc = SysConfigReader.getContainValue(tagname,
				"CONTAINER_PRODUCT");
		if (pdc.equalsIgnoreCase("weblogic")) {
			handler = new WebLogicLoginCallbackHandler(user, password, url);
		} else if (pdc.equalsIgnoreCase("jboss")) {
			handler = new JBossLoginCallbackHandler(user, password, url);
		} else if (pdc.equalsIgnoreCase("websphere")) {
			handler = new WebSphereLoginCallbackHandler(user, password, url);
		} else {
			throw new AppRuntimeException("sorry,not supported " + pdc
					+ " yet!");
		}
		return handler;
	}

	public static Object subjectDoAs(String tagname, Subject sbj,
			PrivilegedAction paction) {
		Object obj = null;
		String pdc = SysConfigReader.getContainValue(tagname,
				"CONTAINER_PRODUCT");
		if (pdc.equalsIgnoreCase("weblogic")) {
			obj = Security.runAs(sbj, paction);
		} else if (pdc.equalsIgnoreCase("jboss")) {
			obj = Subject.doAs(sbj, paction);
			System.out.println("jboss not yet!");
		} else if (pdc.equalsIgnoreCase("websphere")) {
			obj = Subject.doAs(sbj, paction);
			System.out.println("websphere not yet!");
		} else {
			obj = Subject.doAs(sbj, paction);
		}
		return obj;
	}
}
